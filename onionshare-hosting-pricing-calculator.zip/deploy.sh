#!/usr/bin/env bash
# ==============================================================================
# OnionShieldOasis — 1-Command Automated Production Deployment
# Tor v3 Hidden Service + Caddy Reverse Proxy + Systemd Auto-Boot on Linux
# ==============================================================================
set -euo pipefail

RED='\033[0;31m'
GREEN='\033[0;32m'
AMBER='\033[0;33m'
BLUE='\033[0;34m'
NC='\033[0m' # No Color

echo -e "${AMBER}"
cat << "EOF"
  ___        _             ____  _     _      _     _  ___            _     
 / _ \ _ __ (_) ___  _ __ / ___|| |__ (_) ___| | __| |/ _ \  __ _ ___(_)___ 
| | | | '_ \| |/ _ \| '_ \\___ \| '_ \| |/ _ \ |/ _` | | | |/ _` / __| / __|
| |_| | | | | | (_) | | | |___) | | | | |  __/ | (_| | |_| | (_| \__ \ \__ \
 \___/|_| |_|_|\___/|_| |_|____/|_| |_|_|\___|_|\__,_|\___/ \__,_|___/_|___/
                                                                             
             ⚡ 1-COMMAND FULL AUTOMATED SYSTEMD DEPLOYMENT ⚡
EOF
echo -e "${NC}"

# Check for root / sudo
if [ "$EUID" -ne 0 ]; then
  echo -e "${RED}[ERROR] Please run this script with sudo or as root:${NC}"
  echo "  sudo bash $0"
  exit 1
fi

APP_DIR="/opt/onionshield"
APP_USER="onionshield"
TOR_SERVICE_DIR="/var/lib/tor/onionshield_service"
PORT_HTTP="8080"

echo -e "${BLUE}[1/7] Updating package manager & installing dependencies (Tor, Caddy, Node.js, Git)...${NC}"

# Detect Debian/Ubuntu
if command -v apt-get >/dev/null 2>&1; then
  export DEBIAN_FRONTEND=noninteractive
  apt-get update -y
  apt-get install -y curl gpg apt-transport-https debian-archive-keyring debian-keyring tor git sqlite3 libsqlite3-dev

  # Install Node.js if missing
  if ! command -v node >/dev/null 2>&1; then
    echo -e "${AMBER}--> Installing Node.js LTS (NodeSource)...${NC}"
    curl -fsSL https://deb.nodesource.com/setup_20.x | bash -
    apt-get install -y nodejs
  fi

  # Ensure serve is installed globally for instant offline boot
  npm install -g serve 2>/dev/null || true

  # Install Caddy if missing
  if ! command -v caddy >/dev/null 2>&1; then
    echo -e "${AMBER}--> Installing Caddy Web Server...${NC}"
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/gpg.key' | gpg --dearmor -o /usr/share/keyrings/caddy-stable-archive-keyring.gpg --yes
    curl -1sLf 'https://dl.cloudsmith.io/public/caddy/stable/debian.deb.txt' | tee /etc/apt/sources.list.d/caddy-stable.list
    apt-get update -y
    apt-get install -y caddy
  fi
else
  echo -e "${AMBER}[WARN] Non-apt system detected. Ensure 'tor', 'caddy', 'git', and 'node' are installed.${NC}"
fi

echo -e "${GREEN}[✔] Core packages installed:${NC} Node $(node -v), Tor $(tor --version | head -n1), Caddy $(caddy version | head -n1), SQLite $(sqlite3 --version | cut -d' ' -f1)"

echo -e "${BLUE}[2/7] Setting up dedicated system user '${APP_USER}' and directory '${APP_DIR}'...${NC}"
if ! id -u "$APP_USER" >/dev/null 2>&1; then
  useradd -r -s /bin/false -d "$APP_DIR" "$APP_USER"
  echo -e "${GREEN}[✔] Created isolated system user '${APP_USER}'${NC}"
else
  echo -e "${GREEN}[✔] System user '${APP_USER}' already exists${NC}"
fi

mkdir -p "$APP_DIR"

echo -e "${BLUE}[3/7] Copying code & building production release...${NC}"
CURRENT_DIR="$(cd "$(dirname "${BASH_SOURCE[0]}")" && pwd)"

# If running from inside the repo directory
if [ -f "$CURRENT_DIR/package.json" ]; then
  cp -r "$CURRENT_DIR"/* "$APP_DIR"/ 2>/dev/null || true
  cp -r "$CURRENT_DIR"/.[!.]* "$APP_DIR"/ 2>/dev/null || true
fi

cd "$APP_DIR"
chown -R "$APP_USER":"$APP_USER" "$APP_DIR"

# Run build as the application user
sudo -u "$APP_USER" npm install --production=false
sudo -u "$APP_USER" npm run build

if [ ! -d "$APP_DIR/dist" ]; then
  echo -e "${RED}[ERROR] Build failed: dist directory does not exist!${NC}"
  exit 1
fi
echo -e "${GREEN}[✔] Production distribution compiled to ${APP_DIR}/dist${NC}"

echo -e "${BLUE}[4/7] Configuring Caddy (/etc/caddy/Caddyfile)...${NC}"
mkdir -p /etc/caddy
cat > /etc/caddy/Caddyfile << 'EOF'
# /etc/caddy/Caddyfile
# OnionShieldOasis — Tor-Optimized Caddyfile (Unlimited Uploads, Static Vault & Long Timeouts)
{
    auto_https off
    admin off
}

:8080 {
    bind 127.0.0.1

    # Serve the OnionShieldOasis compiled web UI
    root * /opt/onionshield/dist
    file_server

    # SPA Fallback for client-side routing
    try_files {path} /index.html

    # Unlimited body stream for big Tor drops
    request_body {
        max_size 0
    }

    # Extended timeouts for high-latency Tor circuits
    timeouts {
        read_body 7200s
        read_header 60s
        write 7200s
        idle 300s
    }

    # Security headers
    header {
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "no-referrer"
        Server "OnionVault"
    }
}
EOF
echo -e "${GREEN}[✔] Caddyfile configured at /etc/caddy/Caddyfile${NC}"

echo -e "${BLUE}[5/7] Configuring Tor v3 Hidden Service (/etc/tor/torrc)...${NC}"
mkdir -p "$TOR_SERVICE_DIR"
TOR_USER="debian-tor"
if ! id -u debian-tor >/dev/null 2>&1; then
  if id -u tor >/dev/null 2>&1; then
    TOR_USER="tor"
  else
    TOR_USER="root"
  fi
fi
chown -R "$TOR_USER":"$TOR_USER" "$TOR_SERVICE_DIR"
chmod 700 "$TOR_SERVICE_DIR"

if ! grep -q "onionshield_service" /etc/tor/torrc 2>/dev/null; then
  cat >> /etc/tor/torrc << EOF

# OnionShieldOasis Tor v3 Hidden Service
HiddenServiceDir $TOR_SERVICE_DIR/
HiddenServicePort 80 127.0.0.1:$PORT_HTTP
HiddenServiceVersion 3
EOF
  echo -e "${GREEN}[✔] Added HiddenService entry to /etc/tor/torrc${NC}"
else
  echo -e "${GREEN}[✔] HiddenService entry already present in /etc/tor/torrc${NC}"
fi

echo -e "${BLUE}[6/7] Registering and Enabling Systemd Services for Auto-Boot...${NC}"

SERVE_BIN="$(command -v serve || echo "")"
if [ -n "$SERVE_BIN" ]; then
  EXEC_CMD="$SERVE_BIN -s dist -l 3000 --no-clipboard"
else
  NPX_BIN="$(command -v npx || echo /usr/bin/npx)"
  EXEC_CMD="$NPX_BIN --yes serve -s dist -l 3000 --no-clipboard"
fi

# Standalone preview runner service
cat > /etc/systemd/system/onionshield.service << EOF
[Unit]
Description=OnionShield Oasis Storefront Runner
After=network.target caddy.service tor.service
Wants=caddy.service tor.service

[Service]
Type=simple
User=$APP_USER
Group=$APP_USER
WorkingDirectory=$APP_DIR
ExecStart=$EXEC_CMD
Restart=always
RestartSec=5
Environment=NODE_ENV=production
Environment=PORT=3000

# Hardening
PrivateTmp=true
ProtectSystem=full
ProtectHome=true
NoNewPrivileges=true

StandardOutput=journal
StandardError=journal
SyslogIdentifier=onionshield

[Install]
WantedBy=multi-user.target
EOF

# Reload and enable all services
systemctl daemon-reload
systemctl enable caddy
systemctl restart caddy
systemctl enable tor
systemctl restart tor

# Also enable the standalone systemd runner
systemctl enable onionshield 2>/dev/null || true
systemctl restart onionshield 2>/dev/null || true

echo -e "${GREEN}[✔] Systemd services enabled and running! Everything starts automatically on boot.${NC}"

echo -e "${BLUE}[7/7] Verifying services and retrieving .onion address...${NC}"
ONION_ADDRESS=""
for i in {1..15}; do
  if [ -f "$TOR_SERVICE_DIR/hostname" ]; then
    ONION_ADDRESS="$(cat "$TOR_SERVICE_DIR/hostname")"
    break
  fi
  sleep 1
done

echo -e "\n=============================================================================="
echo -e "${GREEN}🎉 OnionShieldOasis DEPLOYMENT COMPLETE & RUNNING IN SYSTEMD!${GREEN}"
echo -e "=============================================================================="

if [ -n "$ONION_ADDRESS" ]; then
  echo -e "🧅 ${AMBER}Your Tor v3 .Onion Address:${NC} ${GREEN}http://${ONION_ADDRESS}${NC}"
else
  echo -e "🧅 ${AMBER}Tor is generating your .onion address... Run:${NC}"
  echo "   sudo cat $TOR_SERVICE_DIR/hostname"
fi

echo -e "\n📊 ${BLUE}Service Status Commands:${NC}"
echo "   systemctl status caddy       # Caddy reverse proxy"
echo "   systemctl status tor         # Tor hidden service daemon"
echo "   systemctl status onionshield # Systemd app manager"
echo "   journalctl -u caddy -f       # Live access logs"
echo -e "\n🔄 ${BLUE}Auto-Boot Guarantee:${NC}"
echo "   All services are enabled via 'systemctl enable'. If the server or PC"
echo "   is rebooted, Tor, Caddy, and OnionShield will start automatically."
echo "==============================================================================\n"
