import React from 'react';
import { Currency, ServerConfig } from '../types';
import { calculatePrice, formatCurrency } from '../utils/pricingCalculator';
import { Globe, Lock, Clock, Info, CheckCircle2, AlertTriangle, ArrowRight, ShieldCheck, Zap } from 'lucide-react';

interface QuickAnswerCardsProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
  pricingMode: 'unit_cost' | 'retail_floor';
  setPricingMode: (mode: 'unit_cost' | 'retail_floor') => void;
  onSelectScenarioForDetail?: (sizeGB: number, months: number, tier: 'public' | 'private') => void;
}

export const QuickAnswerCards: React.FC<QuickAnswerCardsProps> = ({
  selectedCurrency,
  serverConfig,
  pricingMode,
  setPricingMode,
  onSelectScenarioForDetail,
}) => {
  // Calculate dynamic results based on active server configuration
  const result1mPublic = calculatePrice(1, 1, 'public', serverConfig);
  const result1mPrivate = calculatePrice(1, 1, 'private', serverConfig);
  const result2mPublic = calculatePrice(1, 2, 'public', serverConfig);
  const result2mPrivate = calculatePrice(1, 2, 'private', serverConfig);

  const getActivePrice = (res: typeof result1mPublic) => {
    return pricingMode === 'retail_floor' ? res.retailPriceWithFloorUSD : res.recommendedPriceUSD;
  };

  const cards = [
    {
      id: 'card-1m-public',
      title: '1 GB · 1 Month Retention',
      tier: 'public' as const,
      badge: 'Public Onion Link',
      badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
      icon: Globe,
      iconColor: 'text-cyan-400',
      result: result1mPublic,
      priceUSD: getActivePrice(result1mPublic),
      marketRangeUSD: pricingMode === 'retail_floor' ? [3.50, 4.00] as [number, number] : [0.45, 0.85] as [number, number],
      duration: '30 Days',
      retentionDetails: 'Automated 30-day lifecycle with standard secure deletion',
      accessModel: 'Standard .onion URL + optional session password',
      resourceBurden: 'Single ephemeral session with 30-day auto-wipe',
      popularTag: false,
      recommendedXmrApprox: formatCurrency(getActivePrice(result1mPublic), 'XMR'),
      recommendedBtcApprox: formatCurrency(getActivePrice(result1mPublic), 'BTC'),
    },
    {
      id: 'card-1m-private',
      title: '1 GB · 1 Month Retention',
      tier: 'private' as const,
      badge: 'v3 Client-Auth Stealth',
      badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      icon: Lock,
      iconColor: 'text-emerald-400',
      result: result1mPrivate,
      priceUSD: getActivePrice(result1mPrivate),
      marketRangeUSD: pricingMode === 'retail_floor' ? [5.00, 5.50] as [number, number] : [1.35, 2.50] as [number, number],
      duration: '30 Days',
      retentionDetails: '30-day cryptographic key & isolated memory reservation',
      accessModel: 'x25519 descriptor encryption + stealth client keypairs',
      resourceBurden: 'Isolated daemon memory pool (~95MB) & 1:1 egress',
      popularTag: true,
      tagText: 'Recommended',
      recommendedXmrApprox: formatCurrency(getActivePrice(result1mPrivate), 'XMR'),
      recommendedBtcApprox: formatCurrency(getActivePrice(result1mPrivate), 'BTC'),
    },
    {
      id: 'card-2m-public',
      title: '1 GB · 2 Months Retention',
      tier: 'public' as const,
      badge: 'Public Onion Link (60d)',
      badgeColor: 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30',
      icon: Globe,
      iconColor: 'text-cyan-400',
      result: result2mPublic,
      priceUSD: getActivePrice(result2mPublic),
      marketRangeUSD: pricingMode === 'retail_floor' ? [5.00, 5.50] as [number, number] : [0.80, 1.50] as [number, number],
      duration: '60 Days',
      retentionDetails: '60-day persistent HSDir descriptor re-publishing',
      accessModel: 'Standard .onion URL with extended Tor directory uptime',
      resourceBurden: 'Extended 60-day availability for asynchronous download',
      popularTag: false,
      recommendedXmrApprox: formatCurrency(getActivePrice(result2mPublic), 'XMR'),
      recommendedBtcApprox: formatCurrency(getActivePrice(result2mPublic), 'BTC'),
    },
    {
      id: 'card-2m-private',
      title: '1 GB · 2 Months Retention',
      tier: 'private' as const,
      badge: 'v3 Client-Auth (60d)',
      badgeColor: 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30',
      icon: Lock,
      iconColor: 'text-emerald-400',
      result: result2mPrivate,
      priceUSD: getActivePrice(result2mPrivate),
      marketRangeUSD: pricingMode === 'retail_floor' ? [7.00, 7.50] as [number, number] : [2.40, 4.40] as [number, number],
      duration: '60 Days',
      retentionDetails: '60-day dedicated ephemeral socket + LUKS disk space',
      accessModel: 'Highest security; persistent encrypted hidden service keys',
      resourceBurden: 'Long-term RAM reservation & maximum privacy guarantee',
      popularTag: true,
      tagText: 'Whistleblower Tier',
      recommendedXmrApprox: formatCurrency(getActivePrice(result2mPrivate), 'XMR'),
      recommendedBtcApprox: formatCurrency(getActivePrice(result2mPrivate), 'BTC'),
    },
  ];

  return (
    <section className="space-y-4">
      {/* Top Banner Summarizing Direct Rates */}
      <div className="bg-gradient-to-r from-zinc-900 via-zinc-900/90 to-zinc-950 border border-zinc-800 rounded-xl p-4 sm:p-5">
        <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
          <div className="space-y-1">
            <div className="flex items-center gap-2">
              <span className="inline-flex items-center px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30">
                Single File Drop (Session) Pricing
              </span>
              <span className="text-xs text-zinc-400 font-mono">1 GB Payload · Zero-Account Checkout</span>
            </div>
            <h2 className="text-lg sm:text-xl font-bold text-zinc-100 tracking-tight">
              Single Drop Rates: <span className="text-cyan-400">€3.50 – €7.00 per Session</span>
            </h2>
            <p className="text-xs sm:text-sm text-zinc-400 max-w-3xl">
              Strictly charged <strong>per single file drop session</strong> (no accounts, no subscriptions). Includes automated Tor v3 daemon provisioning, crypto fee buffer, and NIST SP 800-88 cryptographic shredding.
            </p>
          </div>

          {/* Pricing Model Switcher */}
          <div className="flex flex-col sm:flex-row items-start sm:items-center gap-2">
            <div className="bg-zinc-950 border border-zinc-800 p-1 rounded-xl flex items-center text-xs font-mono">
              <button
                type="button"
                id="mode-retail-floor-btn"
                onClick={() => setPricingMode('retail_floor')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  pricingMode === 'retail_floor'
                    ? 'bg-cyan-500 text-zinc-950 font-bold shadow'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Single Drop Rates (€3.50 - €7.00)
              </button>
              <button
                type="button"
                id="mode-unit-cost-btn"
                onClick={() => setPricingMode('unit_cost')}
                className={`px-3 py-1.5 rounded-lg transition-all ${
                  pricingMode === 'unit_cost'
                    ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Internal Server Unit Cost
              </button>
            </div>
          </div>
        </div>
      </div>

      {/* 4 Direct Target Cards Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 xl:grid-cols-4 gap-3.5 sm:gap-4">
        {cards.map((card, idx) => {
          const Icon = card.icon;
          const months = idx < 2 ? 1 : 2;
          const isPrivate = card.tier === 'private';

          return (
            <div
              key={card.id}
              id={card.id}
              className={`relative rounded-xl border transition-all duration-200 flex flex-col justify-between ${
                isPrivate
                  ? 'bg-zinc-900/70 border-emerald-900/40 hover:border-emerald-500/50 hover:shadow-lg hover:shadow-emerald-950/20'
                  : 'bg-zinc-900/50 border-zinc-800/80 hover:border-cyan-500/40 hover:shadow-lg hover:shadow-cyan-950/10'
              } p-4 sm:p-4.5`}
            >
              {/* Optional Top Tag */}
              {card.popularTag && (
                <div className="absolute -top-2.5 right-3 px-2 py-0.5 rounded-full text-[10px] font-mono font-bold bg-emerald-500 text-zinc-950 shadow-md">
                  {card.tagText}
                </div>
              )}

              <div>
                {/* Header info */}
                <div className="flex items-center justify-between gap-2 mb-2.5">
                  <span className={`inline-flex items-center gap-1 px-2 py-0.5 rounded text-[11px] font-mono font-medium border ${card.badgeColor}`}>
                    <Icon className="w-3 h-3" />
                    {card.badge}
                  </span>
                  <span className="text-[11px] font-mono text-zinc-400 flex items-center gap-1">
                    <Clock className="w-3 h-3 text-zinc-500" />
                    {card.duration}
                  </span>
                </div>

                <h3 className="text-sm font-semibold text-zinc-200 mb-1">
                  {card.title}
                </h3>

                {/* Primary Price Metric */}
                <div className="my-3 py-2.5 px-3 rounded-lg bg-zinc-950/70 border border-zinc-800/60">
                  <div className="flex items-baseline justify-between">
                    <div>
                      <span className="text-xs text-zinc-500 block font-mono">
                        {pricingMode === 'retail_floor' ? 'Retail Floor (1-Off Drop)' : 'Recommended Unit Rate'}
                      </span>
                      <span className={`text-2xl font-bold font-mono tracking-tight ${isPrivate ? 'text-emerald-400' : 'text-cyan-400'}`}>
                        {formatCurrency(card.priceUSD, selectedCurrency)}
                      </span>
                    </div>
                    <div className="text-right">
                      <span className="text-[10px] text-zinc-500 uppercase font-mono block">Market Range</span>
                      <span className="text-xs font-mono text-zinc-300">
                        {formatCurrency(card.marketRangeUSD[0], selectedCurrency)} – {formatCurrency(card.marketRangeUSD[1], selectedCurrency)}
                      </span>
                    </div>
                  </div>

                  {/* Alternative Crypto rates */}
                  <div className="mt-2 pt-2 border-t border-zinc-800/60 flex items-center justify-between text-[11px] font-mono text-zinc-400">
                    <span>XMR: <strong className="text-zinc-200">{card.recommendedXmrApprox}</strong></span>
                    <span>BTC: <strong className="text-zinc-200">{card.recommendedBtcApprox}</strong></span>
                  </div>
                </div>

                {/* Economic Specifications list */}
                <div className="space-y-1.5 text-xs text-zinc-400 mb-4">
                  <div className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400 flex-shrink-0 mt-0.5" />
                    <span className="leading-snug">{card.accessModel}</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <CheckCircle2 className="w-3.5 h-3.5 text-zinc-400 flex-shrink-0 mt-0.5" />
                    <span className="leading-snug text-zinc-300">{card.retentionDetails}</span>
                  </div>
                  <div className="flex items-start gap-1.5">
                    <Info className="w-3.5 h-3.5 text-zinc-500 flex-shrink-0 mt-0.5" />
                    <span className="text-[11px] text-zinc-400 leading-snug">{card.resourceBurden}</span>
                  </div>
                </div>
              </div>

              {/* Action: Select for detailed breakdown */}
              {onSelectScenarioForDetail && (
                <button
                  type="button"
                  id={`inspect-${card.id}`}
                  onClick={() => onSelectScenarioForDetail(1, months, card.tier)}
                  className="w-full py-1.5 px-3 rounded-lg text-xs font-mono font-medium border border-zinc-700/80 bg-zinc-800/60 hover:bg-zinc-800 hover:text-zinc-100 text-zinc-300 flex items-center justify-center gap-1.5 transition-colors"
                >
                  <span>Inspect Breakdown</span>
                  <ArrowRight className="w-3 h-3 text-zinc-400" />
                </button>
              )}
            </div>
          );
        })}
      </div>
    </section>
  );
};
