import React, { useState } from 'react';
import { Currency, ServerConfig, AccessTier } from '../types';
import { calculatePrice, formatCurrency, formatUnitRate } from '../utils/pricingCalculator';
import { 
  Sliders, 
  Layers, 
  HardDrive, 
  Clock, 
  Globe, 
  Lock, 
  DollarSign, 
  Percent, 
  HelpCircle, 
  Sparkles,
  TrendingUp,
  Cpu,
  RefreshCw
} from 'lucide-react';

interface CalculatorProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
  onUpdateServerConfig: (newConfig: Partial<ServerConfig>) => void;
  storageGB: number;
  setStorageGB: (gb: number) => void;
  durationMonths: number;
  setDurationMonths: (months: number) => void;
  accessTier: AccessTier;
  setAccessTier: (tier: AccessTier) => void;
}

export const Calculator: React.FC<CalculatorProps> = ({
  selectedCurrency,
  serverConfig,
  onUpdateServerConfig,
  storageGB,
  setStorageGB,
  durationMonths,
  setDurationMonths,
  accessTier,
  setAccessTier,
}) => {
  const [showAdvanced, setShowAdvanced] = useState(false);

  // Calculate current custom quotation
  const result = calculatePrice(storageGB, durationMonths, accessTier, serverConfig);
  
  // Also calculate comparison for the opposite tier
  const oppositeTier: AccessTier = accessTier === 'public' ? 'private' : 'public';
  const oppositeResult = calculatePrice(storageGB, durationMonths, oppositeTier, serverConfig);

  const storagePresets = [1, 2, 5, 10, 25, 50, 100];
  const durationPresets = [1, 2, 3, 6, 12];

  return (
    <div className="bg-zinc-900/60 border border-zinc-800 rounded-xl p-4 sm:p-6 space-y-6">
      
      {/* Header */}
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-4 border-b border-zinc-800/80">
        <div>
          <div className="flex items-center gap-2">
            <Sliders className="w-4 h-4 text-emerald-400" />
            <h3 className="text-base sm:text-lg font-bold text-zinc-100 font-mono">
              Custom Storage & Retention Estimator
            </h3>
          </div>
          <p className="text-xs text-zinc-400 mt-0.5">
            Test custom client orders, scale from 1 GB up to bulk quotas, and adjust operator margins.
          </p>
        </div>

        <button
          type="button"
          id="toggle-advanced-infra-btn"
          onClick={() => setShowAdvanced(!showAdvanced)}
          className="text-xs font-mono px-3 py-1.5 rounded-lg border border-zinc-700 bg-zinc-800/80 hover:bg-zinc-800 text-zinc-300 flex items-center gap-1.5 self-start sm:self-center transition-colors"
        >
          <Cpu className="w-3.5 h-3.5 text-zinc-400" />
          <span>{showAdvanced ? 'Hide Server Tuning' : 'Tune Server Economics'}</span>
        </button>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-12 gap-6">
        
        {/* Left Side: Controls & Sliders (7 cols) */}
        <div className="lg:col-span-7 space-y-5">
          
          {/* 1. Storage Size Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="storage-size-slider" className="text-xs font-semibold text-zinc-300 font-mono flex items-center gap-1.5">
                <HardDrive className="w-3.5 h-3.5 text-emerald-400" />
                Storage Capacity:
              </label>
              <span className="text-sm font-bold font-mono text-emerald-400 bg-zinc-950 px-2.5 py-0.5 rounded border border-zinc-800">
                {storageGB} GB
              </span>
            </div>

            <input
              id="storage-size-slider"
              type="range"
              min="1"
              max="100"
              step="1"
              value={storageGB}
              onChange={(e) => setStorageGB(Number(e.target.value))}
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
            />

            <div className="flex flex-wrap gap-1.5 pt-1">
              {storagePresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  id={`preset-storage-${preset}gb`}
                  onClick={() => setStorageGB(preset)}
                  className={`px-2.5 py-1 text-[11px] font-mono rounded-md border transition-all ${
                    storageGB === preset
                      ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 font-bold'
                      : 'bg-zinc-950/60 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:bg-zinc-800'
                  }`}
                >
                  {preset} GB
                </button>
              ))}
            </div>
          </div>

          {/* 2. Retention Duration Selection */}
          <div className="space-y-2">
            <div className="flex items-center justify-between">
              <label htmlFor="retention-term-slider" className="text-xs font-semibold text-zinc-300 font-mono flex items-center gap-1.5">
                <Clock className="w-3.5 h-3.5 text-cyan-400" />
                Retention Term:
              </label>
              <span className="text-sm font-bold font-mono text-cyan-400 bg-zinc-950 px-2.5 py-0.5 rounded border border-zinc-800">
                {durationMonths} {durationMonths === 1 ? 'Month (30 Days)' : durationMonths === 2 ? 'Months (60 Days)' : `${durationMonths} Months`}
              </span>
            </div>

            <input
              id="retention-term-slider"
              type="range"
              min="1"
              max="12"
              step="1"
              value={durationMonths}
              onChange={(e) => setDurationMonths(Number(e.target.value))}
              className="w-full h-2 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-500"
            />

            <div className="flex flex-wrap gap-1.5 pt-1">
              {durationPresets.map((preset) => (
                <button
                  key={preset}
                  type="button"
                  id={`preset-duration-${preset}m`}
                  onClick={() => setDurationMonths(preset)}
                  className={`px-2.5 py-1 text-[11px] font-mono rounded-md border transition-all ${
                    durationMonths === preset
                      ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500/50 font-bold'
                      : 'bg-zinc-950/60 text-zinc-400 border-zinc-800 hover:text-zinc-200 hover:bg-zinc-800'
                  }`}
                >
                  {preset === 1 ? '1 Month (Target)' : preset === 2 ? '2 Months (Target)' : `${preset} Months`}
                </button>
              ))}
            </div>
          </div>

          {/* 3. Access Mode (Public vs Private) */}
          <div className="space-y-2">
            <label className="text-xs font-semibold text-zinc-300 font-mono block">
              Onion Service Mode:
            </label>
            <div className="grid grid-cols-2 gap-3">
              
              {/* Public option */}
              <button
                type="button"
                id="select-tier-public-btn"
                onClick={() => setAccessTier('public')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  accessTier === 'public'
                    ? 'bg-cyan-950/30 border-cyan-500/60 ring-1 ring-cyan-500/30'
                    : 'bg-zinc-950/40 border-zinc-800/80 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Globe className={`w-4 h-4 ${accessTier === 'public' ? 'text-cyan-400' : 'text-zinc-500'}`} />
                  <span className="text-xs font-bold font-mono text-zinc-200">Public Link</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  Standard onion address with optional password. Subject to scraper traffic.
                </p>
              </button>

              {/* Private option */}
              <button
                type="button"
                id="select-tier-private-btn"
                onClick={() => setAccessTier('private')}
                className={`p-3 rounded-xl border text-left transition-all ${
                  accessTier === 'private'
                    ? 'bg-emerald-950/30 border-emerald-500/60 ring-1 ring-emerald-500/30'
                    : 'bg-zinc-950/40 border-zinc-800/80 hover:border-zinc-700'
                }`}
              >
                <div className="flex items-center gap-2 mb-1">
                  <Lock className={`w-4 h-4 ${accessTier === 'private' ? 'text-emerald-400' : 'text-zinc-500'}`} />
                  <span className="text-xs font-bold font-mono text-zinc-200">Private (Client-Auth)</span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  v3 x25519 stealth keypair. Zero descriptor indexing + isolated daemon.
                </p>
              </button>

            </div>
          </div>

          {/* Advanced Server Infrastructure Tuning (Collapsible) */}
          {showAdvanced && (
            <div className="pt-4 border-t border-zinc-800/80 space-y-4 bg-zinc-950/50 p-3.5 rounded-xl border border-zinc-800">
              <div className="flex items-center justify-between">
                <span className="text-xs font-mono font-bold text-zinc-300">Underlying Node Parameters</span>
                <span className="text-[10px] font-mono text-zinc-500">Live Formula Inputs</span>
              </div>

              <div className="grid grid-cols-1 sm:grid-cols-2 gap-3.5">
                {/* Target Profit Margin */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                    <label htmlFor="margin-slider">Target Profit Margin:</label>
                    <span className="text-emerald-400 font-bold">{serverConfig.profitMarginPercent}%</span>
                  </div>
                  <input
                    id="margin-slider"
                    type="range"
                    min="30"
                    max="300"
                    step="10"
                    value={serverConfig.profitMarginPercent}
                    onChange={(e) => onUpdateServerConfig({ profitMarginPercent: Number(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-emerald-500"
                  />
                </div>

                {/* VPS Monthly Cost */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                    <label htmlFor="vps-cost-slider">VPS Host Cost / Mo:</label>
                    <span className="text-zinc-200 font-bold">${serverConfig.vpsMonthlyCostUSD}</span>
                  </div>
                  <input
                    id="vps-cost-slider"
                    type="range"
                    min="5"
                    max="100"
                    step="1"
                    value={serverConfig.vpsMonthlyCostUSD}
                    onChange={(e) => onUpdateServerConfig({ vpsMonthlyCostUSD: Number(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-zinc-400"
                  />
                </div>

                {/* Total Storage Pool */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                    <label htmlFor="vps-pool-slider">Total Node Disk Capacity:</label>
                    <span className="text-zinc-200 font-bold">{serverConfig.totalStorageGB} GB</span>
                  </div>
                  <input
                    id="vps-pool-slider"
                    type="range"
                    min="100"
                    max="2000"
                    step="50"
                    value={serverConfig.totalStorageGB}
                    onChange={(e) => onUpdateServerConfig({ totalStorageGB: Number(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-zinc-400"
                  />
                </div>

                {/* Crypto Swapping / Payment Friction */}
                <div className="space-y-1">
                  <div className="flex justify-between text-[11px] font-mono text-zinc-400">
                    <label htmlFor="crypto-friction-slider">Crypto Friction / Swap Fee:</label>
                    <span className="text-amber-400 font-bold">{serverConfig.paymentFeePercent}%</span>
                  </div>
                  <input
                    id="crypto-friction-slider"
                    type="range"
                    min="1"
                    max="15"
                    step="1"
                    value={serverConfig.paymentFeePercent}
                    onChange={(e) => onUpdateServerConfig({ paymentFeePercent: Number(e.target.value) })}
                    className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-amber-500"
                  />
                </div>
              </div>
            </div>
          )}

        </div>

        {/* Right Side: Live Price Output & Quote Summary Card (5 cols) */}
        <div className="lg:col-span-5 flex flex-col justify-between space-y-4 bg-zinc-950/80 border border-zinc-800 rounded-xl p-4 sm:p-5">
          
          <div>
            <div className="flex items-center justify-between mb-3">
              <span className="text-xs font-mono uppercase tracking-wider text-zinc-400">
                Calculated Quote
              </span>
              <span className={`text-[11px] font-mono px-2 py-0.5 rounded border ${
                accessTier === 'private' ? 'bg-emerald-500/10 text-emerald-400 border-emerald-500/30' : 'bg-cyan-500/10 text-cyan-400 border-cyan-500/30'
              }`}>
                {accessTier === 'private' ? 'Private Client-Auth' : 'Public Link'}
              </span>
            </div>

            {/* Total Recommended Price Display */}
            <div className="py-3 px-3.5 bg-zinc-900/90 border border-zinc-800 rounded-xl mb-4">
              <span className="text-xs text-zinc-400 font-mono block">Single Drop Session Price</span>
              <div className="flex items-baseline gap-2 mt-1">
                <span className="text-3xl font-extrabold font-mono text-cyan-300">
                  {formatCurrency(result.retailPriceWithFloorUSD, selectedCurrency)}
                </span>
                <span className="text-xs font-mono text-zinc-400">
                  per single file drop ({storageGB} GB, {durationMonths} {durationMonths === 1 ? 'month' : 'months'})
                </span>
              </div>

              {/* Unit Rate normalized */}
              <div className="mt-2.5 pt-2 border-t border-zinc-800/80 flex items-center justify-between text-xs font-mono">
                <span className="text-zinc-400">Underlying Server Cost:</span>
                <span className="text-emerald-400 font-semibold">
                  {formatCurrency(result.totalCostUSD, selectedCurrency)}
                </span>
              </div>
            </div>

            {/* Financial Unit Economics breakdown summary */}
            <div className="space-y-2 text-xs font-mono mb-4">
              <div className="flex items-center justify-between text-zinc-400">
                <span>Raw VPS Disk & Compute Cost:</span>
                <span className="text-zinc-200">{formatCurrency(result.totalCostUSD, selectedCurrency)}</span>
              </div>
              <div className="flex items-center justify-between text-zinc-400">
                <span>Crypto Network & Swap Fee:</span>
                <span className="text-amber-400">~{formatCurrency(0.50, selectedCurrency)}</span>
              </div>
              <div className="flex items-center justify-between text-zinc-400">
                <span>Your Net Margin:</span>
                <span className="text-emerald-400 font-semibold">
                  +{formatCurrency(Math.max(0, result.retailPriceWithFloorUSD - result.totalCostUSD - 0.50), selectedCurrency)}
                </span>
              </div>
            </div>
          </div>

          {/* Quick Comparison with Alternate Tier */}
          <div className="pt-3 border-t border-zinc-800/80 text-xs font-mono bg-zinc-900/50 p-3 rounded-lg">
            <div className="flex items-center justify-between text-zinc-400 mb-1">
              <span>Alternative ({oppositeTier}):</span>
              <button
                type="button"
                id="switch-to-opposite-tier-btn"
                onClick={() => setAccessTier(oppositeTier)}
                className="text-cyan-400 hover:underline inline-flex items-center gap-1"
              >
                <span>Switch to {oppositeTier}</span>
                <RefreshCw className="w-3 h-3" />
              </button>
            </div>
            <div className="flex items-center justify-between font-bold text-zinc-200">
              <span className="capitalize">{oppositeTier} Single Drop:</span>
              <span>{formatCurrency(oppositeResult.retailPriceWithFloorUSD, selectedCurrency)}</span>
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
