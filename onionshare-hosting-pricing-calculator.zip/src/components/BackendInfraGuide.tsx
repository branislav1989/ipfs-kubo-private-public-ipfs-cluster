import React, { useState } from 'react';
import { 
  Database, 
  Server, 
  Cpu, 
  HardDrive, 
  CheckCircle2, 
  AlertTriangle, 
  Flame, 
  Copy, 
  Check, 
  Sparkles, 
  Terminal, 
  HelpCircle,
  Zap,
  ShieldAlert,
  Coins,
  Activity,
  Gauge
} from 'lucide-react';

export const BackendInfraGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'i3_4gb_spec' | 'verdict' | 'sqlite_guide' | 'btc_vs_xmr' | 'code_setup'>('i3_4gb_spec');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="bg-zinc-900/80 border-2 border-purple-500/40 rounded-2xl p-4 sm:p-6 lg:p-7 space-y-6 shadow-xl shadow-purple-950/20 relative overflow-hidden">
      
      {/* Background ambient glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-72 h-72 bg-purple-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 pb-5 border-b border-zinc-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5" /> Hardware Fit: Intel i3 + 4GB RAM Server
            </span>
            <span className="text-xs text-zinc-400 font-mono">Ultra-Lightweight Node Stack</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-100 tracking-tight">
            i3 + 4GB RAM Server: <span className="text-purple-400">Zero-Blockchain Lightweight Alternatives</span>
          </h2>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            Running BTCPay Server / Bitcoin Core will <strong>crash or freeze an i3 + 4GB RAM machine</strong>. Here are the 3 best lightweight payment solutions that consume only <strong>15MB – 50MB RAM</strong> and <strong>0 GB blockchain disk space</strong>!
          </p>
        </div>

        {/* Tab Buttons */}
        <div className="flex flex-wrap bg-zinc-950 border border-zinc-800 rounded-xl p-1 text-xs font-mono self-start lg:self-center gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('i3_4gb_spec')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'i3_4gb_spec'
                ? 'bg-amber-500 text-zinc-950 font-bold shadow'
                : 'text-amber-400 hover:text-amber-200'
            }`}
          >
            <Gauge className="w-3.5 h-3.5" /> i3 + 4GB Stack (Best)
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('verdict')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'verdict'
                ? 'bg-purple-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            The Verdict
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('sqlite_guide')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'sqlite_guide'
                ? 'bg-purple-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            SQLite Setup
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('btc_vs_xmr')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'btc_vs_xmr'
                ? 'bg-purple-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            BTC vs Monero
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('code_setup')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'code_setup'
                ? 'bg-purple-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Code & Configs
          </button>
        </div>
      </div>

      {/* TAB 0: i3 + 4GB RAM HARDWARE OPTIMIZATION */}
      {activeTab === 'i3_4gb_spec' && (
        <div className="space-y-6">
          
          {/* Why BTCPay will crash 4GB RAM */}
          <div className="bg-red-950/20 border border-red-500/30 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center gap-2 text-red-400 font-mono text-sm font-bold">
              <AlertTriangle className="w-5 h-5 text-red-400 flex-shrink-0" />
              Why BTCPay Server / bitcoind Will Kill Your 4GB RAM i3 Server:
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              BTCPay Server runs on Docker with 4 heavy containers: <code className="text-red-300">bitcoind</code> (~1.5GB RAM), <code className="text-red-300">BTCPayServer (.NET)</code> (~500MB RAM), <code className="text-red-300">PostgreSQL</code> (~300MB RAM), and <code className="text-red-300">NBXplorer</code> (~350MB RAM). Combined with Linux (~400MB) and Tor (~100MB), it requires <strong>~3.8 GB RAM</strong>.
            </p>
            <div className="p-2.5 bg-red-950/40 rounded-lg border border-red-900/50 text-[11px] font-mono text-red-300">
              🚨 <strong>Result:</strong> Your i3 CPU will peg at 100% for 24+ hours syncing, and the Linux Out-Of-Memory (OOM) killer will crash OnionShare daemons and freeze the system.
            </div>
          </div>

          {/* The 3 Ultra-Lightweight Solutions */}
          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            
            {/* Option 1: Monero Wallet RPC */}
            <div className="bg-zinc-950 border-2 border-emerald-500/40 rounded-xl p-4 space-y-3 relative flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                    #1 Ranked for Tor
                  </span>
                  <Coins className="w-4 h-4 text-emerald-400" />
                </div>

                <h3 className="text-sm font-bold font-mono text-zinc-100">
                  Monero Wallet RPC (`monero-wallet-rpc`)
                </h3>

                <p className="text-xs text-zinc-400 leading-snug">
                  Connects to a remote Tor XMR node. Generates subaddresses on the fly without running a local blockchain.
                </p>

                <div className="space-y-1 text-[11px] font-mono pt-2 border-t border-zinc-800 text-zinc-300">
                  <div className="flex justify-between">
                    <span className="text-zinc-400">RAM Usage:</span>
                    <strong className="text-emerald-400">~35 – 50 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Disk Space:</span>
                    <strong className="text-emerald-400">0 GB Blockchain (20MB cache)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">i3 CPU Load:</span>
                    <strong className="text-emerald-400">&lt; 0.5% (Cold)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Darknet Anonymity:</span>
                    <strong className="text-emerald-300">10/10 (RingCT + Stealth)</strong>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <span className="text-[10px] font-mono text-emerald-300/80 bg-emerald-950/40 p-1.5 rounded block text-center border border-emerald-900/40">
                  ✅ Recommended for your 1-off drops
                </span>
              </div>
            </div>

            {/* Option 2: Python Address Watcher + Tor Mempool API */}
            <div className="bg-zinc-950 border border-cyan-500/40 rounded-xl p-4 space-y-3 relative flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-cyan-400 bg-cyan-500/10 px-2 py-0.5 rounded border border-cyan-500/30">
                    Lightest Bitcoin Method
                  </span>
                  <Zap className="w-4 h-4 text-cyan-400" />
                </div>

                <h3 className="text-sm font-bold font-mono text-zinc-100">
                  Python Address Watcher (No Daemon)
                </h3>

                <p className="text-xs text-zinc-400 leading-snug">
                  Monitors single-use cold wallet addresses (<code className="text-cyan-300">bc1q...</code>). Python checks payment status via the Tor mempool API with zero keys stored on server.
                </p>

                <div className="space-y-1 text-[11px] font-mono pt-2 border-t border-zinc-800 text-zinc-300">
                  <div className="flex justify-between">
                    <span className="text-zinc-400">RAM Usage:</span>
                    <strong className="text-cyan-400">~15 – 25 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Disk Space:</span>
                    <strong className="text-cyan-400">0 GB (Zero disk!)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">i3 CPU Load:</span>
                    <strong className="text-cyan-400">0.0% (Zero idle load)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Private Keys on VPS:</span>
                    <strong className="text-emerald-400">ZERO (100% Cold)</strong>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <span className="text-[10px] font-mono text-cyan-300/80 bg-cyan-950/40 p-1.5 rounded block text-center border border-cyan-900/40">
                  ⚡ Best if you want Bitcoin on 4GB RAM
                </span>
              </div>
            </div>

            {/* Option 3: Electrum Daemon */}
            <div className="bg-zinc-950 border border-purple-500/40 rounded-xl p-4 space-y-3 relative flex flex-col justify-between">
              <div className="space-y-2">
                <div className="flex items-center justify-between">
                  <span className="text-[11px] font-mono font-bold text-purple-400 bg-purple-500/10 px-2 py-0.5 rounded border border-purple-500/30">
                    Standalone Daemon
                  </span>
                  <Terminal className="w-4 h-4 text-purple-400" />
                </div>

                <h3 className="text-sm font-bold font-mono text-zinc-100">
                  Electrum Watch-Only Daemon
                </h3>

                <p className="text-xs text-zinc-400 leading-snug">
                  Runs <code className="text-purple-300">electrum daemon</code> in watch-only mode, connecting directly to decentralized Electrum servers over Tor.
                </p>

                <div className="space-y-1 text-[11px] font-mono pt-2 border-t border-zinc-800 text-zinc-300">
                  <div className="flex justify-between">
                    <span className="text-zinc-400">RAM Usage:</span>
                    <strong className="text-purple-400">~50 – 70 MB</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Disk Space:</span>
                    <strong className="text-purple-400">~10 MB (0 GB Blockchain)</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">i3 CPU Load:</span>
                    <strong className="text-purple-400">&lt; 1%</strong>
                  </div>
                  <div className="flex justify-between">
                    <span className="text-zinc-400">Speed:</span>
                    <strong className="text-purple-300">Instant WebSocket updates</strong>
                  </div>
                </div>
              </div>

              <div className="pt-2">
                <span className="text-[10px] font-mono text-purple-300/80 bg-purple-950/40 p-1.5 rounded block text-center border border-purple-900/40">
                  🛡️ Full JSON-RPC automated API
                </span>
              </div>
            </div>

          </div>

          {/* RAM Budget Breakdown on 4GB Server */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 sm:p-5 space-y-4">
            <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider flex items-center justify-between">
              <span>RAM Allocation on your 4GB Server (Lightweight Stack)</span>
              <span className="text-emerald-400 text-[11px] font-semibold">Total Used: ~540 MB / 4,000 MB (3.46 GB Free!)</span>
            </h4>

            {/* Visual RAM Bar */}
            <div className="w-full h-4 bg-zinc-800 rounded-full overflow-hidden flex">
              <div className="bg-blue-500 h-full" style={{ width: '6.2%' }} title="Debian/Ubuntu OS Base (250MB)" />
              <div className="bg-purple-500 h-full" style={{ width: '2.0%' }} title="Tor Daemon (80MB)" />
              <div className="bg-emerald-500 h-full" style={{ width: '1.2%' }} title="Monero RPC / BTC Watcher (50MB)" />
              <div className="bg-cyan-500 h-full" style={{ width: '1.5%' }} title="Python Backend (60MB)" />
              <div className="bg-amber-500 h-full" style={{ width: '2.5%' }} title="OnionShare Daemons (100MB)" />
              <div className="bg-emerald-900/40 h-full flex-1" title="Free Available RAM (3,460MB)" />
            </div>

            <div className="grid grid-cols-2 sm:grid-cols-5 gap-2 text-[11px] font-mono pt-1">
              <div className="flex items-center gap-1.5 text-zinc-300">
                <span className="w-2.5 h-2.5 rounded-full bg-blue-500 flex-shrink-0" />
                <span>OS: ~250MB</span>
              </div>
              <div className="flex items-center gap-1.5 text-zinc-300">
                <span className="w-2.5 h-2.5 rounded-full bg-purple-500 flex-shrink-0" />
                <span>Tor: ~80MB</span>
              </div>
              <div className="flex items-center gap-1.5 text-zinc-300">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-500 flex-shrink-0" />
                <span>XMR / BTC Watcher: ~50MB</span>
              </div>
              <div className="flex items-center gap-1.5 text-zinc-300">
                <span className="w-2.5 h-2.5 rounded-full bg-cyan-500 flex-shrink-0" />
                <span>Python API: ~60MB</span>
              </div>
              <div className="flex items-center gap-1.5 text-emerald-400 font-bold">
                <span className="w-2.5 h-2.5 rounded-full bg-emerald-400 flex-shrink-0" />
                <span>FREE: ~3,460MB</span>
              </div>
            </div>

            <div className="p-3 bg-zinc-900/80 rounded-lg border border-zinc-800 text-xs text-zinc-300 leading-relaxed">
              💡 <strong>Summary for your i3 processor:</strong> With this lightweight stack, your i3 CPU will sit at <strong>under 2% usage</strong>, your 4GB RAM will have <strong>over 85% free headroom</strong>, and you never have to download a single block of blockchain data to your hard drive!
            </div>
          </div>

        </div>
      )}

      {/* TAB 1: THE VERDICT (SUMMARY BREAKDOWN) */}
      {activeTab === 'verdict' && (
        <div className="space-y-6">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Component 1: SQLite */}
            <div className="bg-zinc-950/80 border border-emerald-500/30 rounded-xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                    <CheckCircle2 className="w-4 h-4" />
                  </span>
                  <h3 className="text-sm font-bold font-mono text-zinc-100">
                    1. SQLite Database
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  100% Correct & Recommended
                </span>
              </div>

              <div className="space-y-2 text-xs text-zinc-300">
                <p>
                  <strong>Why ChatGPT is 100% right on SQLite:</strong>
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-zinc-400 pl-1">
                  <li>
                    <span className="text-zinc-200">Zero Server Overhead:</span> Uses single-file (`storage.db`) with <strong>0 MB idle RAM</strong>. No heavyweight PostgreSQL or MySQL daemons consuming 300MB+ RAM.
                  </li>
                  <li>
                    <span className="text-zinc-200">Ephemeral RAM Disk Compatible:</span> You can mount SQLite in <code className="text-purple-300">/dev/shm</code> (RAM tmpfs) so drop logs and payment IDs are wiped clean if the VPS is seized or rebooted.
                  </li>
                  <li>
                    <span className="text-zinc-200">Perfect for Session Lifecycle:</span> Tracks drop token, expiry timestamp, OnionShare PID, and crypto subaddress.
                  </li>
                </ul>
              </div>
            </div>

            {/* Component 2: Bitcoin Server (2 Month Blockchain Pruned Node) */}
            <div className="bg-zinc-950/80 border border-amber-500/30 rounded-xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                    <AlertTriangle className="w-4 h-4" />
                  </span>
                  <h3 className="text-sm font-bold font-mono text-zinc-100">
                    2. "BTC Server (2-Mo Blockchain)"
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  Valid, But Often Overkill
                </span>
              </div>

              <div className="space-y-2 text-xs text-zinc-300">
                <p>
                  <strong>What ChatGPT is referring to:</strong>
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-zinc-400 pl-1">
                  <li>
                    <span className="text-zinc-200">Bitcoin Core Pruned Node:</span> A full Bitcoin node is <strong>~650 GB</strong>. In pruned mode (<code className="text-amber-300">prune=550</code> or 2-month window ~10GB), it only retains recent blocks to verify 0-conf / 1-conf transactions.
                  </li>
                  <li>
                    <span className="text-zinc-200">The Problem:</span> A pruned BTCPay Server still requires <strong>1.5 GB to 2.5 GB RAM</strong> and initial block download (IBD) takes 12–24 hours of high CPU.
                  </li>
                  <li>
                    <span className="text-emerald-400 font-semibold">Lighter Alternative:</span> Use <strong>Electrum Daemon / Address Watcher (0 GB disk, 40MB RAM)</strong> or <strong>Monero Wallet RPC</strong> (infinitely more private for Tor!).
                  </li>
                </ul>
              </div>
            </div>

          </div>

          {/* Architecture Comparison Summary Table */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 overflow-x-auto">
            <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Cpu className="w-3.5 h-3.5 text-purple-400" />
              Stack Comparison: Heavyweight vs Lightweight vs Monero (Best)
            </h4>

            <table className="w-full text-xs font-mono text-left">
              <thead>
                <tr className="border-b border-zinc-800 text-zinc-400 text-[11px]">
                  <th className="pb-2">Payment Backend</th>
                  <th className="pb-2">RAM Footprint</th>
                  <th className="pb-2">Disk Used</th>
                  <th className="pb-2">Privacy Level</th>
                  <th className="pb-2">Recommendation</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                <tr>
                  <td className="py-2.5 font-bold text-amber-400">BTCPay + Pruned bitcoind (ChatGPT Suggestion)</td>
                  <td className="py-2.5 text-zinc-300">~1,500 – 2,000 MB</td>
                  <td className="py-2.5 text-amber-400">~10 – 15 GB</td>
                  <td className="py-2.5 text-zinc-400">Good (Non-custodial, self-hosted)</td>
                  <td className="py-2.5 text-xs text-amber-300">Heavier; needs bigger VPS</td>
                </tr>
                <tr>
                  <td className="py-2.5 font-bold text-cyan-400">Electrum Daemon + Watch-Only Addresses</td>
                  <td className="py-2.5 text-zinc-300">~50 – 80 MB</td>
                  <td className="py-2.5 text-cyan-400">~50 MB (0 GB blockchain!)</td>
                  <td className="py-2.5 text-zinc-400">High (Polls Electrum servers over Tor)</td>
                  <td className="py-2.5 text-xs text-cyan-300">Super lightweight for BTC</td>
                </tr>
                <tr>
                  <td className="py-2.5 font-bold text-emerald-400">Monero Wallet RPC (`monero-wallet-rpc`)</td>
                  <td className="py-2.5 text-zinc-300">~40 – 60 MB</td>
                  <td className="py-2.5 text-emerald-400">~30 MB (Remote node over Tor)</td>
                  <td className="py-2.5 text-emerald-300 font-bold">Maximum (RingCT + Stealth Addresses)</td>
                  <td className="py-2.5 text-xs text-emerald-400 font-semibold">Best for Darknet Single Drops</td>
                </tr>
              </tbody>
            </table>
          </div>

        </div>
      )}

      {/* TAB 2: SQLITE SETUP GUIDE */}
      {activeTab === 'sqlite_guide' && (
        <div className="space-y-4">
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
            <h3 className="text-sm font-bold font-mono text-zinc-100 flex items-center gap-2">
              <Database className="w-4 h-4 text-emerald-400" />
              Minimal SQLite Schema for 1-Off Session Drops
            </h3>
            <p className="text-xs text-zinc-400">
              For a single-drop session service, you only need one single table (<code className="text-purple-300">drops</code>) to manage payments, expiration timers, and auto-shredding:
            </p>

            <div className="relative bg-zinc-900 border border-zinc-800 rounded-lg p-3 text-xs font-mono text-zinc-300 overflow-x-auto">
              <button
                type="button"
                onClick={() => copyToClipboard(`CREATE TABLE IF NOT EXISTS drops (
    id TEXT PRIMARY KEY,             -- Unique UUID / session slug
    tier TEXT NOT NULL,              -- 'public' or 'private'
    duration_months INTEGER NOT NULL,-- 1 or 2 months
    price_eur REAL NOT NULL,         -- e.g. 3.50, 5.00, 7.00
    crypto_currency TEXT NOT NULL,   -- 'XMR' or 'BTC'
    crypto_address TEXT NOT NULL,    -- Subaddress / Invoice QR
    amount_expected REAL NOT NULL,   -- e.g. 0.022 XMR
    payment_status TEXT DEFAULT 'pending', -- 'pending', 'paid', 'expired'
    txid TEXT,                       -- Blockchain confirmation TX
    onion_slug TEXT,                 -- e.g. 'xyz123...onion'
    client_auth_key TEXT,            -- Optional x25519 stealth key
    onionshare_pid INTEGER,          -- Linux process ID of daemon
    file_path TEXT NOT NULL,         -- Path in encrypted LUKS volume
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,   -- Automated auto-shred trigger date
    is_shredded INTEGER DEFAULT 0    -- 1 if wiped with NIST SP 800-88
);`, 'sqlite_schema')}
                className="absolute top-2.5 right-2.5 p-1.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 transition-colors flex items-center gap-1 text-[11px]"
              >
                {copiedKey === 'sqlite_schema' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                <span>{copiedKey === 'sqlite_schema' ? 'Copied' : 'Copy SQL'}</span>
              </button>
              <pre className="text-[11px] text-emerald-400/90 leading-relaxed font-mono">
{`CREATE TABLE IF NOT EXISTS drops (
    id TEXT PRIMARY KEY,             -- Unique UUID / session slug
    tier TEXT NOT NULL,              -- 'public' or 'private'
    duration_months INTEGER NOT NULL,-- 1 or 2 months
    price_eur REAL NOT NULL,         -- 3.50, 5.00, or 7.00
    crypto_currency TEXT NOT NULL,   -- 'XMR' or 'BTC'
    crypto_address TEXT NOT NULL,    -- Subaddress / Invoice QR
    amount_expected REAL NOT NULL,   -- e.g. 0.022 XMR
    payment_status TEXT DEFAULT 'pending', -- 'pending', 'paid', 'expired'
    txid TEXT,                       -- Blockchain confirmation TX
    onion_slug TEXT,                 -- e.g. 'xyz123...onion'
    client_auth_key TEXT,            -- Optional x25519 stealth key
    onionshare_pid INTEGER,          -- Linux process ID of daemon
    file_path TEXT NOT NULL,         -- Path in encrypted LUKS volume
    created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    expires_at TIMESTAMP NOT NULL,   -- Auto-shred trigger date (30d/60d)
    is_shredded INTEGER DEFAULT 0    -- 1 if wiped with NIST SP 800-88
);`}
              </pre>
            </div>
          </div>

          {/* Privacy Security Tip: In-Memory / tmpfs SQLite */}
          <div className="bg-purple-950/30 border border-purple-500/30 rounded-xl p-4 space-y-2">
            <h4 className="text-xs font-bold font-mono text-purple-300 flex items-center gap-1.5">
              <Flame className="w-4 h-4 text-purple-400" /> Zero-Logs Paranoia Tip: Mount SQLite in RAM (tmpfs)
            </h4>
            <p className="text-[11px] text-zinc-300 leading-relaxed">
              If you want zero forensics residue on disk, place your SQLite file in <code className="text-purple-300 font-mono">/dev/shm/drops.db</code> (Linux RAM disk). If the server loses power or gets rebooted, the database vanishes instantly from physical memory.
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: BTC PRUNING VS MONERO (THE DEEP DIVE) */}
      {activeTab === 'btc_vs_xmr' && (
        <div className="space-y-4">
          
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Pruned Bitcoin Server Explained */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Coins className="w-4 h-4 text-amber-400" />
                <h3 className="text-sm font-bold font-mono text-zinc-100">
                  How 2-Month Bitcoin Pruning Works
                </h3>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                When you run Bitcoin Core with <code className="text-amber-300 font-mono">prune=550</code> (or <code className="text-amber-300 font-mono">prune=10000</code> for ~2 months of blocks):
              </p>
              <ul className="text-xs text-zinc-300 space-y-1.5 list-disc list-inside pl-1">
                <li>
                  It still downloads and verifies the entire 650 GB blockchain from genesis, but <strong>immediately deletes old raw block files</strong> after validating them.
                </li>
                <li>
                  It keeps only the last 2 months of block headers and UTXO set on disk (~5 GB to 10 GB total).
                </li>
                <li>
                  <strong>Pros:</strong> 100% sovereign, independent verification of Bitcoin payments.
                </li>
                <li>
                  <strong>Cons:</strong> Takes 1–2 days to sync initially, burns high CPU during initial block download, and consumes 1.5GB+ RAM.
                </li>
              </ul>
            </div>

            {/* Why Monero is Superior for Single Drops */}
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
              <div className="flex items-center gap-2">
                <Sparkles className="w-4 h-4 text-emerald-400" />
                <h3 className="text-sm font-bold font-mono text-zinc-100">
                  Why Monero (XMR) is 10x Easier & Cheaper
                </h3>
              </div>
              <p className="text-xs text-zinc-400 leading-relaxed">
                For an anonymous Tor file drop service, Monero is the gold standard:
              </p>
              <ul className="text-xs text-zinc-300 space-y-1.5 list-disc list-inside pl-1">
                <li>
                  <strong>Zero Blockchain on Disk:</strong> Run <code className="text-emerald-300 font-mono">monero-wallet-rpc</code> connected to an external trusted remote node over Tor (e.g. <code className="text-zinc-400">node.xmr.to:18081</code>).
                </li>
                <li>
                  <strong>Instant Startup:</strong> Syncs in under 3 seconds. <strong>0 GB disk space required</strong> and uses only <strong>40 MB RAM</strong>!
                </li>
                <li>
                  <strong>True Stealth Subaddresses:</strong> Creates an infinite number of unique payment addresses (<code className="text-zinc-400">8...</code>) that cannot be linked together on the public blockchain.
                </li>
                <li>
                  <strong>Tiny Fees:</strong> Monero transaction fees are under <strong>€0.01</strong> (vs €1.00–€3.00 for on-chain Bitcoin).
                </li>
              </ul>
            </div>

          </div>

          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-2">
            <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider">
              If You Want Bitcoin: Use Watch-Only Addresses (Zero Blockchain Disk Space)
            </h4>
            <p className="text-xs text-zinc-400 leading-relaxed">
              Instead of running a heavy 10GB Bitcoin pruned node, your server checks payment for single-use cold wallet receiving addresses. No private keys or master keys ever touch the server, querying public nodes through Tor SOCKS5 proxy (<code className="text-cyan-300 font-mono">127.0.0.1:9050</code>).
            </p>
          </div>

        </div>
      )}

      {/* TAB 4: CODE & CONFIGS */}
      {activeTab === 'code_setup' && (
        <div className="space-y-4">
          
          {/* Python Address watcher snippet */}
          <div className="bg-zinc-950 border border-cyan-500/40 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-cyan-400 flex items-center gap-1.5">
                <Zap className="w-3.5 h-3.5" /> Python Bitcoin Watcher (15MB RAM · 0 GB Disk · 0% CPU)
              </span>
              <button
                type="button"
                onClick={() => copyToClipboard(`import socks, socket, requests

# Route all requests over local Tor SOCKS5 proxy
socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
socket.socket = socks.socksocket

def check_payment_via_tor_mempool(address: str):
    # Query mempool.space .onion mirror via Tor
    url = f"http://mempoolhqx4isw62xs7abwphsq7acwwlgnvh2edeun32nlc6x4d2z26yd.onion/api/address/{address}"
    res = requests.get(url, timeout=10)
    data = res.json()
    funded = data.get('chain_stats', {}).get('funded_txo_sum', 0)
    mempool_funded = data.get('mempool_stats', {}).get('funded_txo_sum', 0)
    return (funded + mempool_funded) / 100_000_000`, 'py_watcher')}
                className="p-1 px-2 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300 hover:text-zinc-100 flex items-center gap-1"
              >
                {copiedKey === 'py_watcher' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'py_watcher' ? 'Copied' : 'Copy Python Watcher'}
              </button>
            </div>

            <pre className="p-3 bg-zinc-900 rounded-lg text-[11px] font-mono text-cyan-300/90 overflow-x-auto">
{`# Ultra-lightweight Bitcoin Payment Detector (15 MB RAM)
# 1. Checks payments over Tor via mempool.space .onion mirror
# 2. Zero private keys, zero master keys, zero blockchain disk space
import requests, socks, socket

socks.set_default_proxy(socks.SOCKS5, "127.0.0.1", 9050)
socket.socket = socks.socksocket

def check_payment(btc_address):
    onion_url = f"http://mempoolhqx4isw62xs7abwphsq7acwwlgnvh2edeun32nlc6x4d2z26yd.onion/api/address/{btc_address}"
    data = requests.get(onion_url, timeout=10).json()
    total_satoshis = data['chain_stats']['funded_txo_sum'] + data['mempool_stats']['funded_txo_sum']
    return total_satoshis > 0`}
            </pre>
          </div>

          {/* Monero wallet RPC snippet */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-2">
            <div className="flex items-center justify-between">
              <span className="text-xs font-bold font-mono text-emerald-400 flex items-center gap-1.5">
                <Terminal className="w-3.5 h-3.5" /> Monero Wallet RPC (35MB RAM · 0 GB Disk)
              </span>
              <button
                type="button"
                onClick={() => copyToClipboard(`monero-wallet-rpc \\
  --wallet-file /secure/drops_wallet.keys \\
  --password-file /secure/wallet_pass.txt \\
  --rpc-bind-port 18082 \\
  --rpc-bind-ip 127.0.0.1 \\
  --disable-rpc-login \\
  --daemon-address node.community.xmr.to:18081 \\
  --proxy 127.0.0.1:9050`, 'xmr_cmd')}
                className="p-1 px-2 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300 hover:text-zinc-100 flex items-center gap-1"
              >
                {copiedKey === 'xmr_cmd' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                {copiedKey === 'xmr_cmd' ? 'Copied' : 'Copy'}
              </button>
            </div>

            <pre className="p-3 bg-zinc-900 rounded-lg text-[11px] font-mono text-emerald-400/90 overflow-x-auto">
{`monero-wallet-rpc \\
  --wallet-file /secure/drops_wallet.keys \\
  --password-file /secure/wallet_pass.txt \\
  --rpc-bind-port 18082 \\
  --rpc-bind-ip 127.0.0.1 \\
  --daemon-address node.community.xmr.to:18081 \\
  --proxy 127.0.0.1:9050`}
            </pre>
          </div>

        </div>
      )}

    </div>
  );
};
