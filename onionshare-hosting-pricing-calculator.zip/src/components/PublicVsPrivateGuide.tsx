import React from 'react';
import { Shield, Lock, Globe, AlertTriangle, CheckCircle2, Key, EyeOff, Server, HardDrive } from 'lucide-react';

export const PublicVsPrivateGuide: React.FC = () => {
  return (
    <div className="bg-zinc-900/40 border border-zinc-800 rounded-xl p-4 sm:p-6 space-y-6">
      
      <div>
        <div className="flex items-center gap-2">
          <Key className="w-4 h-4 text-emerald-400" />
          <h3 className="text-base sm:text-lg font-bold text-zinc-100 font-mono">
            Why Private (Client-Auth) Costs 2.5× to 3× More than Public
          </h3>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Understanding the deep architectural differences between standard public OnionShare links and private stealth hidden services.
        </p>
      </div>

      {/* Comparison Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-5">
        
        {/* Public OnionShare Service */}
        <div className="bg-zinc-950/70 border border-cyan-900/30 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Globe className="w-4 h-4 text-cyan-400" />
              <h4 className="text-sm font-bold text-zinc-100 font-mono">Public OnionShare Link</h4>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-cyan-500/10 text-cyan-300 border border-cyan-500/20">
              Lower Cost / Higher Traffic
            </span>
          </div>

          <div className="space-y-3 text-xs text-zinc-300">
            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Descriptor Publication:</strong> Published to public Tor HSDirs (Hidden Service Directories). Anyone with the .onion URL can attempt connection.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Crawler & Scraper Exposure:</strong> Darknet search engines (Ahmia, Haystak, Tor67) continually crawl onion links, multiplying egress bandwidth usage by 3x–8x.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Access Control:</strong> Protected only by a random slug or HTTP Basic Auth password. The Tor introduction circuit itself is unauthenticated.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-cyan-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Shared Daemon Density:</strong> Can run higher multi-tenancy on low-spec VPS because sockets share standard Tor routing queues.
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400">
            <strong className="text-cyan-400">Best for:</strong> Whistleblower public drops, open software distributions, community pastebins.
          </div>
        </div>

        {/* Private Client-Auth OnionShare Service */}
        <div className="bg-zinc-950/70 border border-emerald-900/30 rounded-xl p-4 space-y-4">
          <div className="flex items-center justify-between pb-2 border-b border-zinc-800">
            <div className="flex items-center gap-2">
              <Lock className="w-4 h-4 text-emerald-400" />
              <h4 className="text-sm font-bold text-zinc-100 font-mono">Private (v3 Client-Auth Stealth)</h4>
            </div>
            <span className="text-[11px] font-mono px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-300 border border-emerald-500/20">
              Premium / Maximum Isolation
            </span>
          </div>

          <div className="space-y-3 text-xs text-zinc-300">
            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Stealth Descriptor Encryption:</strong> Uses <code className="bg-zinc-900 px-1 py-0.5 rounded text-emerald-400 text-[11px]">auth:ed25519</code> x25519 keypairs. HSDir relays cannot even decrypt the service descriptor without the client private key.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Zero Crawler Leakage:</strong> Invisible to search bots and scrapers. Only designated keyholders can initialize the 6-hop Tor rendezvous handshake.
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Dedicated Process & RAM Overhead:</strong> Requires an isolated OnionShare daemon with its own <code className="bg-zinc-900 px-1 py-0.5 rounded text-zinc-300 text-[11px]">authorized_clients/</code> configuration (~95MB RAM reserved continuously).
              </div>
            </div>

            <div className="flex items-start gap-2">
              <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 mt-1.5 flex-shrink-0" />
              <div>
                <strong className="text-zinc-100">Strict Cryptographic Isolation:</strong> Higher operational cost because the host must manage keypair provisioning and strict tenant segregation.
              </div>
            </div>
          </div>

          <div className="pt-2 border-t border-zinc-800 text-[11px] font-mono text-zinc-400">
            <strong className="text-emerald-400">Best for:</strong> High-value investigative journalism, confidential corporate archives, zero-trust backup transfers.
          </div>
        </div>

      </div>

      {/* Retention Term Factors (1 Month vs 2 Month) */}
      <div className="bg-zinc-950/50 border border-zinc-800 rounded-xl p-4 space-y-3">
        <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider flex items-center gap-1.5">
          <HardDrive className="w-3.5 h-3.5 text-zinc-400" />
          How Retention Duration (1 vs 2 Months) Impacts Your Hosting Costs
        </h4>

        <div className="grid grid-cols-1 sm:grid-cols-3 gap-3 text-xs text-zinc-400">
          <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/80">
            <strong className="text-zinc-200 block mb-1 font-mono">1. Disk Capacity Lock</strong>
            <span>Holding 1 GB for 60 days locks that physical block from being resold. A 10-15% discount for 2 months keeps customer retention high while covering raw disk rent.</span>
          </div>

          <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/80">
            <strong className="text-zinc-200 block mb-1 font-mono">2. Onion Descriptor Refresh</strong>
            <span>Tor v3 service descriptors expire periodically (~24h) and must be constantly re-signed and uploaded to changing HSDir nodes by the background daemon.</span>
          </div>

          <div className="bg-zinc-900/60 p-3 rounded-lg border border-zinc-800/80">
            <strong className="text-zinc-200 block mb-1 font-mono">3. Automated Zero-Trace Purge</strong>
            <span>When retention ends, a secure wipe job (<code className="text-zinc-300">shred -u -z -n 3</code>) must cleanly overwrite inodes and discard the hidden service ephemeral private keys.</span>
          </div>
        </div>
      </div>

    </div>
  );
};
