import React, { useState } from 'react';
import { Currency, ServerConfig } from '../types';
import { calculatePrice, formatCurrency } from '../utils/pricingCalculator';
import { 
  Scale, 
  HelpCircle, 
  CheckCircle2, 
  AlertTriangle, 
  Sparkles, 
  Coins, 
  ArrowRight, 
  ShieldCheck, 
  Flame, 
  Info,
  Layers,
  Award
} from 'lucide-react';
import { MARKET_BENCHMARKS } from '../data/benchmarks';

interface PricingRealityCheckProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
}

export const PricingRealityCheck: React.FC<PricingRealityCheckProps> = ({
  selectedCurrency,
  serverConfig,
}) => {
  const [activeTab, setActiveTab] = useState<'explanation' | 'strategy_recommender' | 'market_table'>('explanation');
  const [selectedOrderType, setSelectedOrderType] = useState<'single_drop' | 'bulk_wallet' | 'subscription'>('single_drop');

  const res1mPub = calculatePrice(1, 1, 'public', serverConfig);
  const res1mPriv = calculatePrice(1, 1, 'private', serverConfig);
  const res2mPub = calculatePrice(1, 2, 'public', serverConfig);
  const res2mPriv = calculatePrice(1, 2, 'private', serverConfig);

  return (
    <div className="bg-zinc-900/70 border-2 border-emerald-500/40 rounded-2xl p-4 sm:p-6 lg:p-7 space-y-6 shadow-xl shadow-emerald-950/20 relative overflow-hidden">
      
      {/* Background glow accent */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-64 h-64 bg-emerald-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Top Banner: Who is Telling the Truth? */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 pb-5 border-b border-zinc-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <Scale className="w-3.5 h-3.5" /> Pricing Reality Check
            </span>
            <span className="text-xs text-zinc-400 font-mono">ChatGPT (€5/€7) vs Unit Cost (€0.60/€1.80)</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-100 tracking-tight">
            Who is Telling the Truth? <span className="text-emerald-400">Both Are, But for Different Business Models</span>
          </h2>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            ChatGPT gave you a <strong>Retail One-Off "Per-Drop" Floor Price</strong> (factoring in crypto transaction fees and single-ticket risk), while our calculator shows the <strong>True Underlying Marginal Server Cost</strong>. Here is the exact breakdown so you don't overcharge or lose money.
          </p>
        </div>

        {/* View Switcher Tabs */}
        <div className="flex bg-zinc-950 border border-zinc-800 rounded-xl p-1 text-xs font-mono self-start lg:self-center">
          <button
            type="button"
            id="tab-explanation-btn"
            onClick={() => setActiveTab('explanation')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'explanation'
                ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Why They Differ
          </button>
          <button
            type="button"
            id="tab-strategy-btn"
            onClick={() => setActiveTab('strategy_recommender')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'strategy_recommender'
                ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Best Strategy
          </button>
          <button
            type="button"
            id="tab-market-btn"
            onClick={() => setActiveTab('market_table')}
            className={`px-3 py-1.5 rounded-lg transition-all ${
              activeTab === 'market_table'
                ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            Market Competitors
          </button>
        </div>
      </div>

      {/* TAB 1: WHY THEY DIFFER (3 Key Pillars) */}
      {activeTab === 'explanation' && (
        <div className="space-y-6">
          
          {/* Side-by-side comparison boxes */}
          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
            
            {/* Box A: The €5 / €7 ChatGPT Retail Model */}
            <div className="bg-zinc-950/80 border border-amber-500/30 rounded-xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-amber-500/20 text-amber-400">
                    <Coins className="w-4 h-4" />
                  </span>
                  <h3 className="text-sm font-bold font-mono text-zinc-100">
                    ChatGPT's Model: Retail "Per-Drop" Floor
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-amber-400 bg-amber-500/10 px-2 py-0.5 rounded border border-amber-500/30">
                  €5.00 (1 Mo) · €7.00 (2 Mo)
                </span>
              </div>

              <div className="space-y-2 text-xs text-zinc-300">
                <p>
                  <strong>Why it quotes €5:</strong> If a customer wants to upload just <strong>one single 1GB file</strong> and pay with Monero (XMR) or Bitcoin (BTC):
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-zinc-400 pl-1">
                  <li>
                    <span className="text-zinc-200">Crypto Transaction Fees:</span> Processing a €0.50 payment costs €0.50–€1.50 in blockchain mining and swap fees. A €5 minimum checkout makes the transaction viable.
                  </li>
                  <li>
                    <span className="text-zinc-200">One-Off Setup Labor & Risk:</span> Generating an isolated Tor hidden service for one file involves node overhead and abuse risk.
                  </li>
                  <li>
                    <span className="text-amber-400 font-semibold">The Catch:</span> If a customer wants 10GB, charging €50 (€5/GB) would make you <strong>wildly uncompetitive and overpriced</strong>.
                  </li>
                </ul>
              </div>

              <div className="pt-2 border-t border-zinc-800/80 text-[11px] font-mono text-zinc-400">
                <strong>Verdict:</strong> Correct for a <em>single one-time anonymous drop</em>, but wrong as a scalable per-GB unit rate.
              </div>
            </div>

            {/* Box B: Our €0.60 / €1.80 Unit Economics Model */}
            <div className="bg-zinc-950/80 border border-emerald-500/30 rounded-xl p-4 sm:p-5 space-y-3">
              <div className="flex items-center justify-between">
                <div className="flex items-center gap-2">
                  <span className="p-1.5 rounded-lg bg-emerald-500/20 text-emerald-400">
                    <Sparkles className="w-4 h-4" />
                  </span>
                  <h3 className="text-sm font-bold font-mono text-zinc-100">
                    Our Model: True Marginal Unit Cost
                  </h3>
                </div>
                <span className="text-xs font-mono font-bold text-emerald-400 bg-emerald-500/10 px-2 py-0.5 rounded border border-emerald-500/30">
                  €0.55 – €1.65 (1 Mo) · €0.95 – €2.90 (2 Mo)
                </span>
              </div>

              <div className="space-y-2 text-xs text-zinc-300">
                <p>
                  <strong>Why it quotes €0.60 – €1.80:</strong> This is the <strong>actual physical cost to your server</strong> plus a healthy 120% profit margin:
                </p>
                <ul className="list-disc list-inside space-y-1.5 text-zinc-400 pl-1">
                  <li>
                    <span className="text-zinc-200">Raw Disk Amortization:</span> On a €25/mo 500GB VPS, 1GB disk space costs you only <strong>€0.05/mo</strong>.
                  </li>
                  <li>
                    <span className="text-zinc-200">Tor Daemon & Bandwidth:</span> Adding Tor 6-hop egress and OnionShare Python daemon RAM adds ~<strong>€0.15/mo</strong>.
                  </li>
                  <li>
                    <span className="text-emerald-400 font-semibold">Total Host Cost:</span> ~<strong>€0.25/mo</strong>. Selling at €0.60 (Public) or €1.80 (Private) yields healthy, sustainable profits without price-gouging.
                  </li>
                </ul>
              </div>

              <div className="pt-2 border-t border-zinc-800/80 text-[11px] font-mono text-zinc-400">
                <strong>Verdict:</strong> Correct for <em>scalable GB pricing, bulk orders, and wallet credit subscriptions</em>.
              </div>
            </div>

          </div>

          {/* Direct Comparison Matrix across 1GB, 5GB, 10GB */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 overflow-hidden">
            <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider mb-3 flex items-center gap-1.5">
              <Layers className="w-3.5 h-3.5 text-emerald-400" />
              Scale Comparison: Flat €5/GB (ChatGPT) vs Scaled Unit Model (Ours)
            </h4>

            <div className="overflow-x-auto">
              <table className="w-full text-xs font-mono text-left">
                <thead>
                  <tr className="border-b border-zinc-800 text-zinc-400 text-[11px]">
                    <th className="pb-2">Storage Quota</th>
                    <th className="pb-2">Retention</th>
                    <th className="pb-2 text-amber-400">ChatGPT Flat €5/GB Model</th>
                    <th className="pb-2 text-emerald-400">Our Unit-Cost Model (Public)</th>
                    <th className="pb-2 text-emerald-400">Our Unit-Cost Model (Private)</th>
                    <th className="pb-2 text-zinc-300">Customer Reaction</th>
                  </tr>
                </thead>
                <tbody className="divide-y divide-zinc-800/60 text-zinc-300">
                  <tr>
                    <td className="py-2.5 font-bold text-zinc-100">1 GB</td>
                    <td className="py-2.5 text-zinc-400">1 Month</td>
                    <td className="py-2.5 text-amber-400 font-semibold">€5.00</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">{formatCurrency(res1mPub.recommendedPriceUSD, 'EUR')}</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">{formatCurrency(res1mPriv.recommendedPriceUSD, 'EUR')}</td>
                    <td className="py-2.5 text-[11px] text-zinc-400">Acceptable for 1-time drop; crypto fee eats €1-2.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-zinc-100">1 GB</td>
                    <td className="py-2.5 text-zinc-400">2 Months</td>
                    <td className="py-2.5 text-amber-400 font-semibold">€7.00</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">{formatCurrency(res2mPub.recommendedPriceUSD, 'EUR')}</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">{formatCurrency(res2mPriv.recommendedPriceUSD, 'EUR')}</td>
                    <td className="py-2.5 text-[11px] text-zinc-400">Standard for 60-day single drop.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-zinc-100">5 GB</td>
                    <td className="py-2.5 text-zinc-400">1 Month</td>
                    <td className="py-2.5 text-amber-400 font-semibold">€25.00 <span className="text-[10px] text-red-400">(Too High)</span></td>
                    <td className="py-2.5 text-emerald-400 font-semibold">€2.75</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">€8.25</td>
                    <td className="py-2.5 text-[11px] text-emerald-300">Great value; covers entire node cost.</td>
                  </tr>
                  <tr>
                    <td className="py-2.5 font-bold text-zinc-100">10 GB</td>
                    <td className="py-2.5 text-zinc-400">1 Month</td>
                    <td className="py-2.5 text-amber-400 font-semibold">€50.00 <span className="text-[10px] text-red-400">(Excessive)</span></td>
                    <td className="py-2.5 text-emerald-400 font-semibold">€5.50</td>
                    <td className="py-2.5 text-emerald-400 font-semibold">€16.50</td>
                    <td className="py-2.5 text-[11px] text-emerald-300">Competitive with top Tor services.</td>
                  </tr>
                </tbody>
              </table>
            </div>
          </div>

        </div>
      )}

      {/* TAB 2: BEST STRATEGY (The Winning Hybrid Model) */}
      {activeTab === 'strategy_recommender' && (
        <div className="space-y-5">
          
          <div className="bg-emerald-950/40 border border-emerald-500/40 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center gap-2 text-emerald-400">
              <Award className="w-5 h-5" />
              <h3 className="text-base font-bold font-mono">
                The Winning Formula: The "Minimum Deposit + Unit Rate" Hybrid
              </h3>
            </div>
            <p className="text-xs text-zinc-300 leading-relaxed">
              How to avoid being <em>way too expensive</em> like ChatGPT's €50/10GB model while ensuring you never lose money on small 1GB crypto transactions:
            </p>

            <div className="grid grid-cols-1 md:grid-cols-3 gap-3 pt-2">
              <div className="bg-zinc-950/80 p-3.5 rounded-lg border border-zinc-800 space-y-1">
                <span className="text-xs font-bold font-mono text-emerald-400 block">1. Minimum Top-Up Floor</span>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  Set a <strong>€3.00 to €5.00 minimum deposit</strong> (e.g. via Monero XMR or BTC Lightning). This eliminates the €1-2 payment processing loss.
                </p>
              </div>

              <div className="bg-zinc-950/80 p-3.5 rounded-lg border border-zinc-800 space-y-1">
                <span className="text-xs font-bold font-mono text-cyan-400 block">2. Low Per-GB Deduction</span>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  Deduct balance at <strong>€0.60/GB·mo for Public</strong> and <strong>€1.80/GB·mo for Private</strong>. Customers feel they get huge value for their €5.
                </p>
              </div>

              <div className="bg-zinc-950/80 p-3.5 rounded-lg border border-zinc-800 space-y-1">
                <span className="text-xs font-bold font-mono text-purple-400 block">3. One-Off Drop Pricing (Option A)</span>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  For users paying per-session: <strong>€3.50 (1 Mo Pub)</strong>, <strong>€5.00 (1 Mo Priv / 2 Mo Pub)</strong>, and <strong>€7.00 (2 Mo Priv)</strong>.
                </p>
              </div>
            </div>
          </div>

          {/* Pricing Config Recommendations */}
          <div className="bg-zinc-950 p-4 rounded-xl border border-zinc-800 space-y-3">
            <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider">
              Exact Single File Drop Menu Rates (Option A)
            </h4>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono">
              <div className="p-3 rounded-lg bg-zinc-900 border border-cyan-900/50 space-y-1.5">
                <span className="text-cyan-400 font-bold block">1-Month Retention (30 Days)</span>
                <ul className="text-zinc-300 space-y-1 text-[11px]">
                  <li>• 1 GB Public Link: <strong className="text-cyan-300">€3.50</strong> (~0.022 XMR)</li>
                  <li>• 1 GB Private (Client-Auth): <strong className="text-emerald-400">€5.00</strong> (~0.031 XMR)</li>
                </ul>
              </div>

              <div className="p-3 rounded-lg bg-zinc-900 border border-emerald-900/50 space-y-1.5">
                <span className="text-emerald-400 font-bold block">2-Month Retention (60 Days)</span>
                <ul className="text-zinc-300 space-y-1 text-[11px]">
                  <li>• 1 GB Public Link: <strong className="text-cyan-300">€5.00</strong> (~0.031 XMR)</li>
                  <li>• 1 GB Private (Client-Auth): <strong className="text-emerald-400">€7.00</strong> (~0.043 XMR)</li>
                </ul>
              </div>
            </div>
          </div>

        </div>
      )}

      {/* TAB 3: MARKET COMPETITORS */}
      {activeTab === 'market_table' && (
        <div className="space-y-4">
          <p className="text-xs text-zinc-400">
            Real market benchmark rates for anonymous file storage, darknet drops, and bulletproof servers:
          </p>

          <div className="grid grid-cols-1 gap-2.5">
            {MARKET_BENCHMARKS.map((item, idx) => (
              <div
                key={idx}
                className="bg-zinc-950 border border-zinc-800/90 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3"
              >
                <div className="space-y-1">
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-bold font-mono text-zinc-200">
                      {item.provider}
                    </span>
                    <span className={`text-[10px] font-mono px-2 py-0.5 rounded border ${item.badgeColor}`}>
                      {item.category}
                    </span>
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-snug">
                    {item.notes}
                  </p>
                </div>

                <div className="text-left sm:text-right flex-shrink-0">
                  <span className="text-xs font-mono font-bold text-zinc-100 block">
                    {item.rateUSD}
                  </span>
                  <span className="text-[10px] font-mono text-zinc-500">
                    {item.model}
                  </span>
                </div>
              </div>
            ))}
          </div>
        </div>
      )}

    </div>
  );
};
