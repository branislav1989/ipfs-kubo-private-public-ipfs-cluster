import React from 'react';
import { Currency, Language } from '../types';
import { Shield, Radio, HardDrive, Globe, Download } from 'lucide-react';
import shieldLogo from '../assets/images/onionshield_logo_1789578620576.jpg';
import { TRANSLATIONS } from '../data/translations';

interface HeaderProps {
  selectedCurrency: Currency;
  onCurrencyChange: (currency: Currency) => void;
  activePresetKey: string;
  onPresetChange: (presetKey: string) => void;
  currentLang: Language;
  onLanguageChange: (lang: Language) => void;
}

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'en', label: 'EN', flag: '🇺🇸' },
  { code: 'ru', label: 'RU', flag: '🇷🇺' },
  { code: 'de', label: 'DE', flag: '🇩🇪' },
  { code: 'zh', label: 'ZH', flag: '🇨🇳' },
  { code: 'fr', label: 'FR', flag: '🇫🇷' },
  { code: 'es', label: 'ES', flag: '🇪🇸' },
  { code: 'pt', label: 'PT', flag: '🇵🇹' },
];

export const Header: React.FC<HeaderProps> = ({
  selectedCurrency,
  onCurrencyChange,
  activePresetKey,
  onPresetChange,
  currentLang,
  onLanguageChange,
}) => {
  const t = TRANSLATIONS[currentLang];

  return (
    <header className="border-b border-zinc-800/80 bg-zinc-950/80 backdrop-blur-md sticky top-0 z-40">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5 sm:py-4">
        <div className="flex flex-col md:flex-row md:items-center md:justify-between gap-4">
          
          {/* Brand & Identity */}
          <div className="flex items-center space-x-3.5">
            <div className="w-11 h-11 rounded-xl bg-zinc-900 border border-emerald-500/40 p-1 flex items-center justify-center shadow-lg shadow-emerald-950/50 relative overflow-hidden group flex-shrink-0">
              <img
                src={shieldLogo}
                alt="OnionShieldOasis Shield Logo"
                className="w-full h-full object-cover rounded-lg"
                referrerPolicy="no-referrer"
              />
              <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
                <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
                <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
              </span>
            </div>
            <div>
              <div className="flex items-center space-x-2">
                <h1 className="text-lg sm:text-xl font-black text-zinc-100 tracking-tight font-mono">
                  OnionShield<span className="text-emerald-400">Oasis</span>
                </h1>
                <span className="px-2 py-0.5 text-[11px] font-mono font-medium rounded-full bg-zinc-800/90 text-emerald-400 border border-emerald-500/30 hidden sm:inline-flex items-center gap-1">
                  <Radio className="w-3 h-3 text-emerald-400" /> {t.torVaultBadge}
                </span>
                <span className="px-1.5 py-0.5 text-[10px] font-mono font-bold rounded bg-amber-500/10 text-amber-300 border border-amber-500/30 hidden md:inline-flex items-center gap-1">
                  obfs4 Ready
                </span>
              </div>
              <p className="text-xs text-zinc-400 mt-0.5">
                {t.headerSubtitle}
              </p>
            </div>
          </div>

          {/* Controls Bar: Language Selector, Currency, Infra Preset */}
          <div className="flex flex-wrap items-center gap-2 sm:gap-2.5">
            
            {/* Language Switcher (EN, RU, DE, ZH, FR, ES, PT) */}
            <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-lg p-0.5 overflow-x-auto max-w-full" title="Select Language">
              <div className="px-2 py-1 text-zinc-400 flex items-center gap-1 text-xs">
                <Globe className="w-3.5 h-3.5 text-emerald-400" />
              </div>
              {LANGUAGES.map((item) => {
                const isSelected = currentLang === item.code;
                return (
                  <button
                    key={item.code}
                    id={`lang-btn-${item.code}`}
                    type="button"
                    onClick={() => onLanguageChange(item.code)}
                    className={`px-2 py-1 text-xs font-mono font-bold rounded-md transition-all flex items-center gap-1 ${
                      isSelected
                        ? 'bg-emerald-500 text-zinc-950 shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                    }`}
                  >
                    <span>{item.flag}</span>
                    <span>{item.label}</span>
                  </button>
                );
              })}
            </div>

            {/* Currency Selector */}
            <div className="flex items-center bg-zinc-900 border border-zinc-800 rounded-lg p-0.5">
              {(['USD', 'EUR', 'XMR', 'BTC'] as Currency[]).map((curr) => {
                const isSelected = selectedCurrency === curr;
                return (
                  <button
                    key={curr}
                    id={`currency-btn-${curr.toLowerCase()}`}
                    type="button"
                    onClick={() => onCurrencyChange(curr)}
                    className={`px-2.5 py-1 text-xs font-mono font-semibold rounded-md transition-all ${
                      isSelected
                        ? 'bg-amber-400 text-zinc-950 shadow-sm'
                        : 'text-zinc-400 hover:text-zinc-200 hover:bg-zinc-800/60'
                    }`}
                  >
                    {curr}
                  </button>
                );
              })}
            </div>

            {/* Quick Preset Selector */}
            <div className="flex items-center gap-1.5 bg-zinc-900/90 border border-zinc-800/80 rounded-lg px-2 py-1 text-xs text-zinc-300">
              <HardDrive className="w-3.5 h-3.5 text-zinc-400" />
              <label htmlFor="infra-preset-select" className="text-zinc-500 font-mono text-[11px] hidden sm:inline">Infra:</label>
              <select
                id="infra-preset-select"
                aria-label="Select Infrastructure Profile"
                value={activePresetKey}
                onChange={(e) => onPresetChange(e.target.value)}
                className="bg-transparent text-xs font-mono text-zinc-200 focus:outline-none cursor-pointer pr-1"
              >
                <option value="offshore_bulletproof" className="bg-zinc-900 text-zinc-200">Offshore VPS ($28/mo, 500GB)</option>
                <option value="budget_vps" className="bg-zinc-900 text-zinc-200">Budget Tor Node ($12/mo, 250GB)</option>
                <option value="dedicated_luks" className="bg-zinc-900 text-zinc-200">Dedicated LUKS ($65/mo, 1TB)</option>
              </select>
            </div>

            {/* 1-Click Direct ZIP Download (No SSH, No GitHub required) */}
            <a
              href="/onionshield-deploy.zip"
              download="onionshield-deploy.zip"
              title="Download entire project ZIP to your PC (Zero SSH / Zero GitHub required)"
              className="px-3 py-1.5 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 font-mono font-bold text-xs rounded-lg transition-all shadow flex items-center gap-1.5"
            >
              <Download className="w-3.5 h-3.5" />
              <span>Direct ZIP</span>
            </a>

          </div>

        </div>
      </div>
    </header>
  );
};
