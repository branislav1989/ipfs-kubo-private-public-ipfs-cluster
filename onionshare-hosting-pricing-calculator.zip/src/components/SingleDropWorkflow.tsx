import React, { useState } from 'react';
import { Currency, ServerConfig } from '../types';
import { calculatePrice, formatCurrency } from '../utils/pricingCalculator';
import { 
  FileUp, 
  Clock, 
  ShieldCheck, 
  Coins, 
  Trash2, 
  Key, 
  ArrowRight, 
  Flame, 
  CheckCircle2, 
  Zap, 
  Server, 
  DollarSign,
  TrendingUp,
  Cpu
} from 'lucide-react';

interface SingleDropWorkflowProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
}

export const SingleDropWorkflow: React.FC<SingleDropWorkflowProps> = ({
  selectedCurrency,
  serverConfig,
}) => {
  const [selectedDuration, setSelectedDuration] = useState<1 | 2>(1);
  const [selectedTier, setSelectedTier] = useState<'public' | 'private'>('private');
  const [monthlyDropVolume, setMonthlyDropVolume] = useState<number>(100);

  // Calculate pricing for the current selected drop
  const result = calculatePrice(1, selectedDuration, selectedTier, serverConfig);
  const singleDropPriceUSD = result.retailPriceWithFloorUSD;

  // Single-drop cost breakdown
  const estimatedCryptoTxFeeUSD = 0.50; // XMR transaction fee buffer
  const rawHostingCostUSD = result.totalCostUSD;
  const netProfitPerDropUSD = Math.max(0, singleDropPriceUSD - estimatedCryptoTxFeeUSD - rawHostingCostUSD);
  const netMarginPercent = ((netProfitPerDropUSD / singleDropPriceUSD) * 100).toFixed(0);

  // Monthly revenue projections
  const monthlyGrossRevenue = singleDropPriceUSD * monthlyDropVolume;
  const monthlyHostCost = serverConfig.monthlyServerCostUSD;
  const monthlyCryptoFees = estimatedCryptoTxFeeUSD * monthlyDropVolume;
  const monthlyNetIncome = Math.max(0, monthlyGrossRevenue - monthlyCryptoFees - monthlyHostCost);

  return (
    <div className="bg-zinc-900/80 border-2 border-cyan-500/40 rounded-2xl p-4 sm:p-6 lg:p-7 space-y-6 shadow-xl shadow-cyan-950/20 relative overflow-hidden">
      
      {/* Background ambient glow */}
      <div className="absolute -bottom-10 -right-10 w-72 h-72 bg-cyan-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-5 border-b border-zinc-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-cyan-500/20 text-cyan-300 border border-cyan-500/30 flex items-center gap-1.5">
              <Zap className="w-3.5 h-3.5" /> Option A: Single File Drop Architecture
            </span>
            <span className="text-xs text-zinc-400 font-mono">Per-Session · Zero Account · 100% Ephemeral</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-100 tracking-tight">
            Single 1GB Drop Session: <span className="text-cyan-400">Economics & Technical Flow</span>
          </h2>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            Since your business model is <strong>per single file drop session</strong> (no accounts, no wallet balances), here is the exact step-by-step transaction flow, crypto checkout calculation, and profit margins for 1GB drops.
          </p>
        </div>

        {/* Quick Menu Rates */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3 text-xs font-mono flex-shrink-0">
          <span className="text-zinc-500 block mb-1 text-[11px] uppercase tracking-wider font-semibold">Single File Drop Menu:</span>
          <div className="grid grid-cols-2 gap-x-4 gap-y-1 text-zinc-200">
            <div>1GB / 1 Mo (Pub): <strong className="text-cyan-400">€3.50</strong></div>
            <div>1GB / 1 Mo (Priv): <strong className="text-emerald-400">€5.00</strong></div>
            <div>1GB / 2 Mo (Pub): <strong className="text-cyan-400">€5.00</strong></div>
            <div>1GB / 2 Mo (Priv): <strong className="text-emerald-400">€7.00</strong></div>
          </div>
        </div>
      </div>

      {/* Step-by-Step Single-Drop Lifecycle */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3">
        
        {/* Step 1 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>STEP 01</span>
            <FileUp className="w-4 h-4 text-cyan-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">Upload 1GB & Select Tier</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            Anonymous user uploads up to 1GB file. Chooses 30 or 60 days retention and Public (.onion link) or Stealth Private (x25519 key).
          </p>
        </div>

        {/* Step 2 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>STEP 02</span>
            <Coins className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">Single Crypto Invoice</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            System displays a unique Monero (XMR) subaddress or BTC Lightning QR code for <strong>€3.50 – €7.00</strong>. 0-conf payment lock.
          </p>
        </div>

        {/* Step 3 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>STEP 03</span>
            <Cpu className="w-4 h-4 text-emerald-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">OnionShare Instance Spins Up</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            Daemon allocates isolated memory space, binds ephemeral v3 keypairs, and publishes descriptors to Tor HSDir relays.
          </p>
        </div>

        {/* Step 4 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>STEP 04</span>
            <Flame className="w-4 h-4 text-red-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">Auto-Shred & Burn</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            Once downloaded (burn on download) or when the 30/60 days timer expires, Linux LUKS block is overwritten with cryptographic zeros.
          </p>
        </div>

      </div>

      {/* Interactive Single-Drop Profit Breakdown */}
      <div className="grid grid-cols-1 lg:grid-cols-12 gap-5 pt-2">
        
        {/* Drop Configuration Controls */}
        <div className="lg:col-span-5 bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-4">
          <h3 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider flex items-center gap-2">
            <DollarSign className="w-4 h-4 text-cyan-400" /> Single Drop Profit Simulator
          </h3>

          {/* Retention Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono text-zinc-400">Retention Period (1 GB payload):</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSelectedDuration(1)}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold border transition-all ${
                  selectedDuration === 1
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                1 Month (30 Days)
              </button>
              <button
                type="button"
                onClick={() => setSelectedDuration(2)}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold border transition-all ${
                  selectedDuration === 2
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                2 Months (60 Days)
              </button>
            </div>
          </div>

          {/* Security Tier Selector */}
          <div className="space-y-1.5">
            <label className="text-[11px] font-mono text-zinc-400">Access & Security Mode:</label>
            <div className="grid grid-cols-2 gap-2">
              <button
                type="button"
                onClick={() => setSelectedTier('public')}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold border transition-all ${
                  selectedTier === 'public'
                    ? 'bg-cyan-500/20 text-cyan-300 border-cyan-500'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Public .onion Link
              </button>
              <button
                type="button"
                onClick={() => setSelectedTier('private')}
                className={`py-2 px-3 rounded-lg text-xs font-mono font-bold border transition-all ${
                  selectedTier === 'private'
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500'
                    : 'bg-zinc-900 border-zinc-800 text-zinc-400 hover:text-zinc-200'
                }`}
              >
                Private Stealth (Client-Auth)
              </button>
            </div>
          </div>

          {/* Volume Slider */}
          <div className="space-y-1.5 pt-1">
            <div className="flex justify-between text-[11px] font-mono">
              <span className="text-zinc-400">Estimated Monthly Drops Sold:</span>
              <span className="text-cyan-400 font-bold">{monthlyDropVolume} drops/mo</span>
            </div>
            <input
              type="range"
              min={10}
              max={500}
              step={10}
              value={monthlyDropVolume}
              onChange={(e) => setMonthlyDropVolume(Number(e.target.value))}
              className="w-full h-1.5 bg-zinc-800 rounded-lg appearance-none cursor-pointer accent-cyan-400"
            />
            <div className="flex justify-between text-[10px] font-mono text-zinc-500">
              <span>10 drops</span>
              <span>250 drops</span>
              <span>500 drops</span>
            </div>
          </div>

        </div>

        {/* Financial Outcome Cards */}
        <div className="lg:col-span-7 grid grid-cols-1 sm:grid-cols-2 gap-3.5">
          
          {/* Card A: Per-Drop Economics */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-zinc-400 uppercase tracking-wider block">
                Per Single 1GB Drop
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold font-mono text-emerald-400">
                  {formatCurrency(singleDropPriceUSD, selectedCurrency)}
                </span>
                <span className="text-xs font-mono text-zinc-400">
                  charge to user
                </span>
              </div>

              <div className="space-y-1 text-xs font-mono border-t border-zinc-800/80 pt-2 text-zinc-300">
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">Estimated Crypto TX Fee:</span>
                  <span className="text-amber-400 font-semibold">-{formatCurrency(estimatedCryptoTxFeeUSD, selectedCurrency)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">Raw Node Storage Cost:</span>
                  <span className="text-amber-400 font-semibold">-{formatCurrency(rawHostingCostUSD, selectedCurrency)}</span>
                </div>
              </div>
            </div>

            <div className="pt-3 border-t border-zinc-800 flex items-center justify-between">
              <div>
                <span className="text-[11px] font-mono text-zinc-400 block">Your Net Profit Per Drop:</span>
                <span className="text-lg font-bold font-mono text-emerald-300">
                  +{formatCurrency(netProfitPerDropUSD, selectedCurrency)}
                </span>
              </div>
              <span className="text-xs font-mono font-bold px-2 py-1 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/30">
                {netMarginPercent}% Margin
              </span>
            </div>
          </div>

          {/* Card B: Monthly Scaled Node Revenue */}
          <div className="bg-zinc-950 border border-cyan-900/50 rounded-xl p-4 space-y-3 flex flex-col justify-between">
            <div className="space-y-2">
              <span className="text-xs font-mono font-bold text-cyan-400 uppercase tracking-wider block flex items-center gap-1.5">
                <TrendingUp className="w-3.5 h-3.5" /> Scaled Monthly Income
              </span>
              <div className="flex items-baseline gap-2">
                <span className="text-3xl font-extrabold font-mono text-cyan-300">
                  {formatCurrency(monthlyNetIncome, selectedCurrency)}
                </span>
                <span className="text-xs font-mono text-zinc-400">/ month net</span>
              </div>

              <div className="space-y-1 text-xs font-mono border-t border-zinc-800/80 pt-2 text-zinc-300">
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">Gross Sales ({monthlyDropVolume} drops):</span>
                  <span className="text-zinc-200">{formatCurrency(monthlyGrossRevenue, selectedCurrency)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">Total Server VPS Cost:</span>
                  <span className="text-red-400">-{formatCurrency(monthlyHostCost, selectedCurrency)}</span>
                </div>
                <div className="flex justify-between text-[11px]">
                  <span className="text-zinc-400">Total Crypto Processing Fees:</span>
                  <span className="text-red-400">-{formatCurrency(monthlyCryptoFees, selectedCurrency)}</span>
                </div>
              </div>
            </div>

            <div className="pt-2 text-[11px] font-mono text-zinc-400 bg-zinc-900/80 p-2 rounded-lg border border-zinc-800">
              💡 Even with just <strong>15–20 drops per month</strong>, your entire bulletproof server cost is 100% paid off.
            </div>
          </div>

        </div>

      </div>

    </div>
  );
};
