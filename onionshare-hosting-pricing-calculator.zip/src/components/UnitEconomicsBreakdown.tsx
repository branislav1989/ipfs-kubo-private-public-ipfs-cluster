import React from 'react';
import { Currency, ServerConfig, AccessTier } from '../types';
import { calculatePrice, formatCurrency } from '../utils/pricingCalculator';
import { 
  PieChart, 
  HardDrive, 
  Wifi, 
  Cpu, 
  Coins, 
  TrendingUp, 
  ShieldAlert, 
  Check, 
  HelpCircle 
} from 'lucide-react';

interface UnitEconomicsBreakdownProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
  storageGB: number;
  durationMonths: number;
  accessTier: AccessTier;
}

export const UnitEconomicsBreakdown: React.FC<UnitEconomicsBreakdownProps> = ({
  selectedCurrency,
  serverConfig,
  storageGB,
  durationMonths,
  accessTier,
}) => {
  const result = calculatePrice(storageGB, durationMonths, accessTier, serverConfig);
  const total = result.recommendedPriceUSD;

  const costItems = [
    {
      id: 'item-storage',
      name: 'Raw NVMe/SSD Storage',
      amountUSD: result.baseStorageCostUSD,
      percent: Math.round((result.baseStorageCostUSD / total) * 100),
      color: 'bg-blue-500',
      textColor: 'text-blue-400',
      icon: HardDrive,
      desc: `Raw disk space amortized over ${durationMonths} month(s) on ${serverConfig.totalStorageGB}GB pool.`,
    },
    {
      id: 'item-bandwidth',
      name: 'Tor Circuit Egress Bandwidth',
      amountUSD: result.bandwidthCostUSD,
      percent: Math.round((result.bandwidthCostUSD / total) * 100),
      color: 'bg-cyan-500',
      textColor: 'text-cyan-400',
      icon: Wifi,
      desc: `${accessTier === 'public' ? 'Higher multiplier (3x-8x) due to crawler discovery' : 'Low 1:1 download volume with zero crawler egress'}.`,
    },
    {
      id: 'item-compute',
      name: 'Hidden Service Daemon & RAM',
      amountUSD: result.daemonComputeCostUSD,
      percent: Math.round((result.daemonComputeCostUSD / total) * 100),
      color: 'bg-purple-500',
      textColor: 'text-purple-400',
      icon: Cpu,
      desc: `Ephemeral OnionShare socket & process RAM allocation (${accessTier === 'private' ? '~95MB private stealth pool' : '~40MB shared pool'}).`,
    },
    {
      id: 'item-crypto',
      name: 'Crypto Transaction & Swap Buffer',
      amountUSD: result.cryptoFrictionCostUSD,
      percent: Math.round((result.cryptoFrictionCostUSD / total) * 100),
      color: 'bg-amber-500',
      textColor: 'text-amber-400',
      icon: Coins,
      desc: `${serverConfig.paymentFeePercent}% buffer covering Monero/Bitcoin network mining fee and exchange volatility.`,
    },
    {
      id: 'item-profit',
      name: 'Operator Gross Profit Margin',
      amountUSD: result.profitUSD,
      percent: Math.round((result.profitUSD / total) * 100),
      color: 'bg-emerald-500',
      textColor: 'text-emerald-400',
      icon: TrendingUp,
      desc: `Net earnings for node maintenance, security patching, and uptime guarantee.`,
    },
  ];

  return (
    <div className="bg-zinc-900/50 border border-zinc-800 rounded-xl p-4 sm:p-6 space-y-5">
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-2 pb-3 border-b border-zinc-800/80">
        <div>
          <h3 className="text-base font-bold text-zinc-100 font-mono flex items-center gap-2">
            <PieChart className="w-4 h-4 text-emerald-400" />
            Unit Economics & Cost Distribution Breakdown
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Where every cent of your {formatCurrency(total, selectedCurrency)} quotation goes.
          </p>
        </div>
        <span className="text-xs font-mono text-zinc-400 bg-zinc-950 px-2.5 py-1 rounded border border-zinc-800 self-start sm:self-center">
          Active: <strong className="text-zinc-200 capitalize">{accessTier}</strong> ({storageGB} GB / {durationMonths} Mo)
        </span>
      </div>

      {/* Visual Stacked Progress Bar */}
      <div className="space-y-2">
        <div className="h-3.5 w-full bg-zinc-950 rounded-full overflow-hidden flex border border-zinc-800 p-0.5 gap-0.5">
          {costItems.map((item) => {
            const widthPct = Math.max(item.percent, 3);
            return (
              <div
                key={item.id}
                style={{ width: `${widthPct}%` }}
                title={`${item.name}: ${item.percent}%`}
                className={`h-full rounded-sm ${item.color} opacity-90 transition-all`}
              />
            );
          })}
        </div>

        {/* Legend */}
        <div className="flex flex-wrap gap-x-4 gap-y-2 pt-1 text-[11px] font-mono text-zinc-400">
          {costItems.map((item) => (
            <div key={item.id} className="flex items-center gap-1.5">
              <span className={`w-2.5 h-2.5 rounded-full ${item.color}`} />
              <span>{item.name}</span>
              <strong className="text-zinc-200">({item.percent}%)</strong>
            </div>
          ))}
        </div>
      </div>

      {/* Detailed Line Items Grid */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
        {costItems.map((item) => {
          const Icon = item.icon;
          return (
            <div
              key={item.id}
              className="bg-zinc-950/60 border border-zinc-800/80 rounded-xl p-3.5 flex flex-col justify-between"
            >
              <div>
                <div className="flex items-center justify-between gap-2 mb-1.5">
                  <div className="flex items-center gap-1.5">
                    <Icon className={`w-3.5 h-3.5 ${item.textColor}`} />
                    <span className="text-xs font-semibold text-zinc-200 font-mono">
                      {item.name}
                    </span>
                  </div>
                  <span className="text-[11px] font-mono font-bold text-zinc-300">
                    {formatCurrency(item.amountUSD, selectedCurrency)}
                  </span>
                </div>
                <p className="text-[11px] text-zinc-400 leading-snug">
                  {item.desc}
                </p>
              </div>

              <div className="mt-3 pt-2 border-t border-zinc-800/60 flex items-center justify-between text-[10px] font-mono text-zinc-500">
                <span>Share of Revenue:</span>
                <span className={`font-bold ${item.textColor}`}>{item.percent}%</span>
              </div>
            </div>
          );
        })}
      </div>

    </div>
  );
};
