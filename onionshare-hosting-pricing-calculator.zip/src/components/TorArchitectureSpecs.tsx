import React, { useState } from 'react';
import { Terminal, Copy, Check, Shield, Code2, Server, Cpu, HardDrive } from 'lucide-react';

export const TorArchitectureSpecs: React.FC = () => {
  const [copiedId, setCopiedId] = useState<string | null>(null);

  const copyToClipboard = (id: string, text: string) => {
    navigator.clipboard.writeText(text);
    setCopiedId(id);
    setTimeout(() => setCopiedId(null), 2000);
  };

  const snippets = [
    {
      id: 'cmd-public',
      title: 'Host 1GB Public OnionShare Share (Headless CLI)',
      desc: 'Starts a public OnionShare receiving node with auto-stop and persistent .onion service.',
      code: `onionshare-cli --receive \\
  --public \\
  --data-dir /var/lib/onionshare/shares/public_01 \\
  --config /etc/onionshare/public_node.json`,
    },
    {
      id: 'cmd-private',
      title: 'Host 1GB Private (v3 Client-Auth Stealth) Share',
      desc: 'Creates a private stealth hidden service requiring authorized client public key pairs.',
      code: `onionshare-cli --receive \\
  --client-auth \\
  --data-dir /var/lib/onionshare/shares/private_01 \\
  --config /etc/onionshare/stealth_node.json`,
    },
    {
      id: 'cmd-shred',
      title: 'Automated Retention Expiry & Cryptographic Shred Cron',
      desc: 'Systemd or cron job executing NIST SP 800-88 cryptographic overwrite upon retention expiration.',
      code: `# Run daily at 00:00 to purge shares older than 30 or 60 days
find /var/lib/onionshare/shares/ -type f -mtime +30 -exec shred -u -z -n 3 {} \\;
find /var/lib/onionshare/shares/ -type d -empty -delete`,
    },
  ];

  return (
    <div className="bg-zinc-900/40 border border-zinc-800 rounded-xl p-4 sm:p-6 space-y-5">
      
      <div>
        <div className="flex items-center gap-2">
          <Terminal className="w-4 h-4 text-emerald-400" />
          <h3 className="text-base sm:text-lg font-bold text-zinc-100 font-mono">
            Tor OS & OnionShare Node Hosting Architecture
          </h3>
        </div>
        <p className="text-xs text-zinc-400 mt-1">
          Technical specifications for running a stable OnionShare storage node in Linux / Tails / Whonix / Debian.
        </p>
      </div>

      <div className="grid grid-cols-1 gap-4">
        {snippets.map((snip) => (
          <div key={snip.id} className="bg-zinc-950 border border-zinc-800/90 rounded-xl overflow-hidden">
            <div className="flex items-center justify-between px-3.5 py-2 bg-zinc-900/80 border-b border-zinc-800">
              <div>
                <span className="text-xs font-bold text-zinc-200 font-mono block">
                  {snip.title}
                </span>
                <span className="text-[11px] text-zinc-400">{snip.desc}</span>
              </div>
              <button
                type="button"
                id={`copy-${snip.id}`}
                onClick={() => copyToClipboard(snip.id, snip.code)}
                className="p-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-300 text-xs font-mono flex items-center gap-1 transition-colors flex-shrink-0"
                title="Copy command"
              >
                {copiedId === snip.id ? (
                  <>
                    <Check className="w-3.5 h-3.5 text-emerald-400" />
                    <span className="text-emerald-400 text-[10px]">Copied</span>
                  </>
                ) : (
                  <>
                    <Copy className="w-3.5 h-3.5 text-zinc-400" />
                    <span className="text-[10px]">Copy</span>
                  </>
                )}
              </button>
            </div>
            <pre className="p-3 text-xs font-mono text-emerald-400/95 overflow-x-auto selection:bg-emerald-900/40">
              <code>{snip.code}</code>
            </pre>
          </div>
        ))}
      </div>

      {/* Hosting Best Practices */}
      <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 text-xs font-mono pt-2">
        <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-lg space-y-1">
          <strong className="text-emerald-400 block font-semibold flex items-center gap-1.5">
            <Shield className="w-3.5 h-3.5" /> 1. RAM Disk & LUKS Swap Protection
          </strong>
          <p className="text-zinc-400 text-[11px] leading-relaxed">
            Mount <code className="text-zinc-200">/tmp</code> and upload staging areas as tmpfs (RAM disk) with swap encrypted under a volatile kernel key (<code className="text-zinc-200">cryptsetup</code>) to prevent data remanence across reboots.
          </p>
        </div>

        <div className="p-3 bg-zinc-950/60 border border-zinc-800 rounded-lg space-y-1">
          <strong className="text-cyan-400 block font-semibold flex items-center gap-1.5">
            <Server className="w-3.5 h-3.5" /> 2. Tor Connection Padding & SOCKS5
          </strong>
          <p className="text-zinc-400 text-[11px] leading-relaxed">
            Enable <code className="text-zinc-200">ConnectionPadding 1</code> and <code className="text-zinc-200">ReducedConnectionPadding 0</code> in <code className="text-zinc-200">torrc</code> to mitigate traffic analysis and packet sizing attacks against active OnionShare hidden services.
          </p>
        </div>
      </div>

    </div>
  );
};
