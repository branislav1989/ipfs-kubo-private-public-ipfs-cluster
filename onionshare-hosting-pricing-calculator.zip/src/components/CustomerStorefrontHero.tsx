import React, { useState } from 'react';
import { Currency, Language } from '../types';
import shieldLogo from '../assets/images/onionshield_logo_1789578620576.jpg';
import { TRANSLATIONS } from '../data/translations';
import { 
  Globe, 
  Lock, 
  Clock, 
  CheckCircle2, 
  ArrowRight, 
  FileUp, 
  Coins, 
  Copy, 
  Check, 
  ShieldCheck, 
  Flame, 
  Zap, 
  QrCode,
  Sparkles,
  AlertTriangle,
  RotateCcw,
  Cpu,
  Trash2,
  HardDrive,
  Sliders,
  Eye,
  EyeOff,
  Key,
  Archive,
  Radio,
  FileKey
} from 'lucide-react';
import { QRCodeSVG } from 'qrcode.react';

interface CustomerStorefrontHeroProps {
  selectedCurrency: Currency;
  currentLang: Language;
  onLanguageChange?: (lang: Language) => void;
  onSelectPlan?: (planId: string) => void;
}

interface PricingPlan {
  id: string;
  name: string;
  ratePerGbEUR: number;
  durationDays: 30 | 60;
  tier: 'public' | 'private';
  tag?: string;
  badgeColor: string;
  headline: string;
  description: string;
  features: string[];
  recommendedAddress: string;
  satsPerGbApprox: number;
}

const LANGUAGES: { code: Language; label: string; flag: string }[] = [
  { code: 'en', label: 'English', flag: '🇺🇸' },
  { code: 'ru', label: 'Русский', flag: '🇷🇺' },
  { code: 'de', label: 'Deutsch', flag: '🇩🇪' },
  { code: 'zh', label: '中文', flag: '🇨🇳' },
  { code: 'fr', label: 'Français', flag: '🇫🇷' },
  { code: 'es', label: 'Español', flag: '🇪🇸' },
  { code: 'pt', label: 'Português', flag: '🇵🇹' },
];

export const CustomerStorefrontHero: React.FC<CustomerStorefrontHeroProps> = ({
  selectedCurrency,
  currentLang,
  onLanguageChange,
}) => {
  const t = TRANSLATIONS[currentLang] || TRANSLATIONS.en;

  // Explicit User Choices for Retention & Privacy
  const [retentionDays, setRetentionDays] = useState<30 | 60>(30);
  const [privacyTier, setPrivacyTier] = useState<'public' | 'private'>('private');
  
  const [fileSizeGB, setFileSizeGB] = useState<number>(2.5);
  const [fileName, setFileName] = useState<string>('database_backup_archive.tar.gz');
  const [generatedBtcFilename, setGeneratedBtcFilename] = useState<string>('');
  const [customerHash, setCustomerHash] = useState<string>('a8f3b9c7e12d4085e94b2fa603517c2f89d31e9c2b7408f615372ae6b490f19c');
  const [uploadStep, setUploadStep] = useState<'idle' | 'uploading' | 'uploaded_awaiting_payment' | 'simulated_paid'>('idle');
  const [uploadProgress, setUploadProgress] = useState<number>(0);
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const handleGenerateBtcFilename = () => {
    const chars = '023456789acdefghjklmnpqrstuvwxyz';
    let addr = 'bc1q';
    for (let i = 0; i < 34; i++) {
      addr += chars.charAt(Math.floor(Math.random() * chars.length));
    }
    const sampleName = `${addr}.7z`;
    setGeneratedBtcFilename(sampleName);
    copyToClipboard(sampleName, 'sample_btc_name');
  };

  // The 4 Core Simple Plans (Rates Per 1 GB - No Max 1GB Cap!)
  const plans: PricingPlan[] = [
    {
      id: 'plan-1m-public',
      name: `${t.retention30d} · ${t.privacyPublic}`,
      ratePerGbEUR: 3.50,
      durationDays: 30,
      tier: 'public',
      badgeColor: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
      headline: t.privacyPublic,
      description: t.privacyPublicDesc,
      features: [
        'Any upload size (no 1 GB limit)',
        `${t.retention30d} (${t.daysDuration}) Tor v3`,
        t.privacyPublicDesc,
        t.ramSafetyDesc,
      ],
      recommendedAddress: 'bc1qjlh4320l4uz22wmpa53sr3vj2l0xeltqtgau4t',
      satsPerGbApprox: 5400,
    },
    {
      id: 'plan-1m-private',
      name: `${t.retention30d} · ${t.privacyPrivate}`,
      ratePerGbEUR: 5.00,
      durationDays: 30,
      tier: 'private',
      tag: t.mostPopular,
      badgeColor: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
      headline: t.privacyPrivate,
      description: t.privacyPrivateDesc,
      features: [
        'Any upload size (no 1 GB limit)',
        `${t.retention30d} (${t.daysDuration}) stealth Tor v3`,
        t.privacyPrivateDesc,
        t.ramSafetyDesc,
      ],
      recommendedAddress: 'bc1qhwwdjz7zettcc60ldmpcsfd5crmcyrtdvdw6ka',
      satsPerGbApprox: 7700,
    },
    {
      id: 'plan-2m-public',
      name: `${t.retention60d} · ${t.privacyPublic}`,
      ratePerGbEUR: 5.00,
      durationDays: 60,
      tier: 'public',
      badgeColor: 'bg-cyan-500/10 text-cyan-300 border-cyan-500/30',
      headline: `${t.privacyPublic} (60d)`,
      description: t.retention60dDesc,
      features: [
        'Any upload size (no 1 GB limit)',
        `${t.retention60d} (${t.daysDuration}) Tor v3`,
        t.privacyPublicDesc,
        t.ramSafetyDesc,
      ],
      recommendedAddress: 'bc1qruj7fjyl6yl6ceaytjj9er2247jec24a7jkqua',
      satsPerGbApprox: 7700,
    },
    {
      id: 'plan-2m-private',
      name: `${t.retention60d} · ${t.privacyPrivate}`,
      ratePerGbEUR: 7.00,
      durationDays: 60,
      tier: 'private',
      tag: t.maxPrivacy,
      badgeColor: 'bg-emerald-500/10 text-emerald-300 border-emerald-500/30',
      headline: `${t.privacyPrivate} (60d)`,
      description: t.privacyPrivateDesc,
      features: [
        'Any upload size (no 1 GB limit)',
        `${t.retention60d} (${t.daysDuration}) stealth Tor v3`,
        t.privacyPrivateDesc,
        t.ramSafetyDesc,
      ],
      recommendedAddress: 'bc1q4kd53hygxft7fa8faphtdzcpk2ja8789mqdg24',
      satsPerGbApprox: 10800,
    },
  ];

  // Active plan derived directly from retentionDays and privacyTier
  const activePlan = plans.find((p) => p.durationDays === retentionDays && p.tier === privacyTier) || plans[1];

  // Dynamic invoice calculations based on ACTUAL uploaded size
  const totalDueEUR = Math.max(1.0, Number((fileSizeGB * activePlan.ratePerGbEUR).toFixed(2)));
  const totalDueSats = Math.max(1500, Math.round(fileSizeGB * activePlan.satsPerGbApprox));
  const totalDueBTC = (totalDueSats / 100_000_000).toFixed(8);

  const startSimulatedUpload = () => {
    setUploadStep('uploading');
    setUploadProgress(15);
    const interval = setInterval(() => {
      setUploadProgress((prev) => {
        if (prev >= 100) {
          clearInterval(interval);
          setUploadStep('uploaded_awaiting_payment');
          return 100;
        }
        return prev + 25;
      });
    }, 200);
  };

  const handleRealFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    if (e.target.files && e.target.files[0]) {
      const file = e.target.files[0];
      setFileName(file.name);
      const calculatedGb = Math.max(0.1, Number((file.size / (1024 * 1024 * 1024)).toFixed(2)));
      setFileSizeGB(calculatedGb);
      startSimulatedUpload();
    }
  };

  const handleSelectPlanFromTop = (plan: PricingPlan) => {
    setRetentionDays(plan.durationDays);
    setPrivacyTier(plan.tier);
  };

  return (
    <section id="storefront-hero" className="space-y-6">
      
      {/* Top Welcome Title & Brand Header */}
      <div className="text-center space-y-3 py-3">
        <div className="flex items-center justify-center gap-3">
          <div className="w-12 h-12 rounded-2xl bg-zinc-900 border border-emerald-500/40 p-1 flex items-center justify-center shadow-lg shadow-emerald-950/50 relative overflow-hidden">
            <img
              src={shieldLogo}
              alt="OnionShieldOasis Shield Logo"
              className="w-full h-full object-cover rounded-xl"
              referrerPolicy="no-referrer"
            />
            <span className="absolute -top-0.5 -right-0.5 flex h-2.5 w-2.5">
              <span className="animate-ping absolute inline-flex h-full w-full rounded-full bg-emerald-400 opacity-75"></span>
              <span className="relative inline-flex rounded-full h-2.5 w-2.5 bg-emerald-500"></span>
            </span>
          </div>
          <div className="text-left">
            <span className="text-xs font-mono font-bold text-emerald-400 tracking-wider uppercase block">
              {t.tagline}
            </span>
            <h1 className="text-2xl sm:text-3xl lg:text-4xl font-black text-zinc-100 tracking-tight font-mono">
              OnionShield<span className="text-emerald-400">Oasis</span>
            </h1>
          </div>
        </div>

        <div className="flex flex-wrap items-center justify-center gap-2">
          <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-amber-500/10 border border-amber-500/30 text-amber-300 text-xs font-mono font-bold tracking-wide">
            <Coins className="w-4 h-4 text-amber-400" />
            <span>{t.heroBadge}</span>
          </div>

          <div className="inline-flex items-center gap-1.5 px-3 py-1 rounded-full bg-emerald-500/10 border border-emerald-500/30 text-emerald-300 text-xs font-mono font-bold">
            <Radio className="w-3.5 h-3.5 text-emerald-400" />
            <span>obfs4 Bridges Enabled</span>
          </div>
        </div>

        {/* Quick Language Selector inside Storefront */}
        {onLanguageChange && (
          <div className="flex flex-wrap items-center justify-center gap-1.5 pt-1">
            <span className="text-xs font-mono text-zinc-500 flex items-center gap-1 mr-1">
              <Globe className="w-3.5 h-3.5 text-zinc-400" /> Language:
            </span>
            {LANGUAGES.map((lang) => (
              <button
                key={lang.code}
                type="button"
                onClick={() => onLanguageChange(lang.code)}
                className={`px-2 py-0.5 rounded text-[11px] font-mono font-bold transition-all flex items-center gap-1 border ${
                  currentLang === lang.code
                    ? 'bg-emerald-500/20 text-emerald-300 border-emerald-500/50 shadow-sm'
                    : 'bg-zinc-900 text-zinc-400 border-zinc-800 hover:text-zinc-200'
                }`}
              >
                <span>{lang.flag}</span>
                <span>{lang.label}</span>
              </button>
            ))}
          </div>
        )}

        <p className="text-sm sm:text-base text-zinc-300 max-w-3xl mx-auto leading-relaxed">
          {t.heroSubheadline}
        </p>
      </div>

      {/* THE 4 PRICING PLANS IN BIG BOLD FONTS */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
        {plans.map((plan) => {
          const isSelected = activePlan.id === plan.id;
          const isPrivate = plan.tier === 'private';

          return (
            <div
              key={plan.id}
              onClick={() => handleSelectPlanFromTop(plan)}
              className={`cursor-pointer relative rounded-2xl p-5 sm:p-6 transition-all duration-200 flex flex-col justify-between border-2 ${
                isSelected
                  ? isPrivate
                    ? 'bg-zinc-900 border-emerald-400 shadow-xl shadow-emerald-950/40 ring-2 ring-emerald-500/20'
                    : 'bg-zinc-900 border-amber-400 shadow-xl shadow-amber-950/40 ring-2 ring-amber-500/20'
                  : 'bg-zinc-950/90 border-zinc-800/90 hover:border-zinc-700 hover:bg-zinc-900/60'
              }`}
            >
              {/* Optional Top Tag */}
              {plan.tag && (
                <div className={`absolute -top-3 left-1/2 -translate-x-1/2 px-3 py-0.5 rounded-full text-[10px] font-mono font-extrabold tracking-wider shadow-md ${
                  isPrivate ? 'bg-emerald-400 text-zinc-950' : 'bg-amber-400 text-zinc-950'
                }`}>
                  {plan.tag}
                </div>
              )}

              <div className="space-y-4">
                {/* Header tier badge & duration */}
                <div className="flex items-center justify-between gap-2">
                  <span className={`px-2.5 py-0.5 rounded-full text-[11px] font-mono font-bold border flex items-center gap-1 ${plan.badgeColor}`}>
                    {isPrivate ? <Lock className="w-3 h-3" /> : <Globe className="w-3 h-3" />}
                    {plan.headline}
                  </span>
                  <span className="text-xs font-mono text-zinc-400 flex items-center gap-1">
                    <Clock className="w-3.5 h-3.5 text-zinc-500" />
                    {plan.durationDays} {t.daysDuration}
                  </span>
                </div>

                {/* BIG BOLD PRICE PER 1 GB */}
                <div className="py-2 border-y border-zinc-800/80 my-2">
                  <div className="flex items-baseline gap-1.5">
                    <span className={`text-4xl sm:text-5xl font-black font-mono tracking-tight ${
                      isPrivate ? 'text-emerald-400' : 'text-amber-400'
                    }`}>
                      €{plan.ratePerGbEUR.toFixed(2)}
                    </span>
                    <span className="text-sm text-zinc-300 font-mono font-bold">{t.per1Gb}</span>
                  </div>

                  {/* Bitcoin Satoshis per GB in bold underneath */}
                  <div className="mt-1.5 flex items-center gap-1.5 text-xs font-mono text-amber-300">
                    <Coins className="w-3.5 h-3.5 text-amber-400 flex-shrink-0" />
                    <span>~{plan.satsPerGbApprox.toLocaleString()} {t.satsPerGb}</span>
                  </div>
                </div>

                {/* Plan Title & Explanation */}
                <div className="space-y-1.5">
                  <h3 className="text-base font-bold text-zinc-100 font-mono">
                    {plan.headline}
                  </h3>
                  <p className="text-xs text-zinc-400 leading-relaxed">
                    {plan.description}
                  </p>
                </div>

                {/* Bullet Points */}
                <ul className="space-y-1.5 pt-2 text-xs font-mono text-zinc-300">
                  {plan.features.map((feat, fIdx) => (
                    <li key={fIdx} className="flex items-start gap-1.5">
                      <CheckCircle2 className={`w-3.5 h-3.5 flex-shrink-0 mt-0.5 ${
                        isPrivate ? 'text-emerald-400' : 'text-amber-400'
                      }`} />
                      <span className="leading-snug">{feat}</span>
                    </li>
                  ))}
                </ul>
              </div>

              {/* Select Button */}
              <button
                type="button"
                className={`mt-6 w-full py-2.5 px-4 rounded-xl text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
                  isSelected
                    ? isPrivate
                      ? 'bg-emerald-500 text-zinc-950 shadow-md shadow-emerald-500/20'
                      : 'bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/20'
                    : 'bg-zinc-800 text-zinc-300 hover:bg-zinc-700 hover:text-zinc-100'
                }`}
              >
                <span>{isSelected ? t.activePlan : t.selectPlan}</span>
                <ArrowRight className="w-3.5 h-3.5" />
              </button>

            </div>
          );
        })}
      </div>

      {/* INTERACTIVE DROP & INVOICE WORKFLOW */}
      <div className="bg-zinc-900 border-2 border-zinc-800 rounded-2xl p-5 sm:p-7 space-y-6 shadow-2xl">
        
        {/* Step Indicator Header */}
        <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 border-b border-zinc-800 pb-4">
          <div>
            <span className="text-[11px] font-mono text-amber-400 font-bold uppercase tracking-wider block">
              {t.step2Header}
            </span>
            <h2 className="text-lg sm:text-xl font-bold text-zinc-100 mt-0.5">
              {t.step2Title}: <span className="text-amber-400 font-mono">{activePlan.name} ({activePlan.headline})</span>
            </h2>
            <p className="text-xs text-zinc-400 mt-0.5">
              Current Rate: <strong className="text-zinc-200 font-mono">€{activePlan.ratePerGbEUR.toFixed(2)} {t.per1Gb}</strong> (~{activePlan.satsPerGbApprox.toLocaleString()} {t.satsPerGb})
            </p>
          </div>

          <div className="flex items-center gap-2 bg-zinc-950 border border-zinc-800 px-3 py-2 rounded-xl font-mono text-xs">
            <Cpu className="w-4 h-4 text-emerald-400 flex-shrink-0" />
            <span className="text-zinc-400">{t.ramSafetyBadge}:</span>
            <span className="text-emerald-300 font-bold">{t.ramSafetyDesc}</span>
          </div>
        </div>

        {/* PROMINENT CONFIGURATION CONTROLS (RETENTION & PRIVACY SELECTORS) */}
        <div className="p-4 sm:p-5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-4 font-mono">
          <div className="flex items-center gap-2 pb-2 border-b border-zinc-800/80">
            <Sliders className="w-4 h-4 text-amber-400" />
            <span className="text-xs text-zinc-200 font-bold uppercase tracking-wider">
              {t.settingsTitle}
            </span>
          </div>

          <div className="grid grid-cols-1 sm:grid-cols-2 gap-4">
            
            {/* 1. RETENTION SELECTION (30 DAYS vs 60 DAYS) */}
            <div className="space-y-2">
              <label className="text-xs text-zinc-400 font-bold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Clock className="w-3.5 h-3.5 text-amber-400" />
                  {t.retentionTitle}
                </span>
                <span className="text-amber-300 text-[11px] font-normal">
                  {retentionDays === 30 ? t.retention30d : t.retention60d}
                </span>
              </label>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="select-retention-30d"
                  onClick={() => setRetentionDays(30)}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 ${
                    retentionDays === 30
                      ? 'bg-amber-400 text-zinc-950 border-amber-300 shadow-md shadow-amber-400/20'
                      : 'bg-zinc-900/90 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-sm">{t.retention30d}</span>
                  <span className={`text-[10px] font-normal ${retentionDays === 30 ? 'text-zinc-900 font-semibold' : 'text-zinc-400'}`}>
                    {t.retention30dDesc}
                  </span>
                </button>

                <button
                  type="button"
                  id="select-retention-60d"
                  onClick={() => setRetentionDays(60)}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 ${
                    retentionDays === 60
                      ? 'bg-amber-400 text-zinc-950 border-amber-300 shadow-md shadow-amber-400/20'
                      : 'bg-zinc-900/90 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <span className="text-sm">{t.retention60d}</span>
                  <span className={`text-[10px] font-normal ${retentionDays === 60 ? 'text-zinc-900 font-semibold' : 'text-zinc-400'}`}>
                    {t.retention60dDesc}
                  </span>
                </button>
              </div>
            </div>

            {/* 2. PRIVACY TIER SELECTION (PUBLIC vs STEALTH PRIVATE) */}
            <div className="space-y-2">
              <label className="text-xs text-zinc-400 font-bold flex items-center justify-between">
                <span className="flex items-center gap-1.5">
                  <Lock className="w-3.5 h-3.5 text-emerald-400" />
                  {t.privacyTitle}
                </span>
                <span className="text-emerald-400 text-[11px] font-normal">
                  {privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}
                </span>
              </label>

              <div className="grid grid-cols-2 gap-2">
                <button
                  type="button"
                  id="select-privacy-public"
                  onClick={() => setPrivacyTier('public')}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 ${
                    privacyTier === 'public'
                      ? 'bg-cyan-400 text-zinc-950 border-cyan-300 shadow-md shadow-cyan-400/20'
                      : 'bg-zinc-900/90 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    <Globe className="w-3.5 h-3.5" />
                    <span className="text-sm">{t.privacyPublic}</span>
                  </div>
                  <span className={`text-[10px] font-normal ${privacyTier === 'public' ? 'text-zinc-950 font-semibold' : 'text-zinc-400'}`}>
                    {t.privacyPublicDesc}
                  </span>
                </button>

                <button
                  type="button"
                  id="select-privacy-private"
                  onClick={() => setPrivacyTier('private')}
                  className={`py-2.5 px-3 rounded-xl border text-xs font-bold transition-all flex flex-col items-center justify-center gap-1 ${
                    privacyTier === 'private'
                      ? 'bg-emerald-400 text-zinc-950 border-emerald-300 shadow-md shadow-emerald-400/20'
                      : 'bg-zinc-900/90 text-zinc-300 border-zinc-800 hover:border-zinc-700'
                  }`}
                >
                  <div className="flex items-center gap-1">
                    <Lock className="w-3.5 h-3.5" />
                    <span className="text-sm">{t.privacyPrivate}</span>
                  </div>
                  <span className={`text-[10px] font-normal ${privacyTier === 'private' ? 'text-zinc-950 font-semibold' : 'text-zinc-400'}`}>
                    {t.privacyPrivateDesc}
                  </span>
                </button>
              </div>
            </div>

          </div>

          {/* Quick Summary Strip */}
          <div className="pt-2 border-t border-zinc-800/80 flex flex-wrap items-center justify-between text-xs text-zinc-400 gap-2">
            <span className="flex items-center gap-1.5">
              <span className="w-2 h-2 rounded-full bg-emerald-400"></span>
              {t.activeSelectionSummary}: <strong className="text-zinc-100">{retentionDays} {t.daysDuration}</strong> &middot; <strong className="text-zinc-100">{privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}</strong>
            </span>
            <span className="text-amber-300 font-bold">
              Rate: €{activePlan.ratePerGbEUR.toFixed(2)} {t.per1Gb} (~{activePlan.satsPerGbApprox.toLocaleString()} {t.satsPerGb})
            </span>
          </div>
        </div>

        {/* STEP A: IDLE / SELECT FILE SIZE OR DROP REAL FILE */}
        {uploadStep === 'idle' && (
          <div className="space-y-5 font-mono">
            
            {/* Quick Size Preset Bar */}
            <div className="p-4 bg-zinc-950 border border-zinc-800 rounded-xl space-y-3">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
                <span className="text-xs text-zinc-300 font-bold flex items-center gap-1.5">
                  <HardDrive className="w-4 h-4 text-amber-400" />
                  {t.fileSizeTitle}
                </span>
                <span className="text-xs text-amber-300 font-bold">
                  Total: {fileSizeGB} GB = €{totalDueEUR.toFixed(2)} (~{totalDueSats.toLocaleString()} sats)
                </span>
              </div>

              {/* Preset Buttons */}
              <div className="flex flex-wrap items-center gap-2">
                {[
                  { label: '500 MB', gb: 0.5 },
                  { label: '1.0 GB', gb: 1.0 },
                  { label: '2.5 GB', gb: 2.5 },
                  { label: '5.0 GB', gb: 5.0 },
                  { label: '10.0 GB', gb: 10.0 },
                  { label: '25.0 GB', gb: 25.0 },
                ].map((item) => (
                  <button
                    key={item.label}
                    type="button"
                    onClick={() => setFileSizeGB(item.gb)}
                    className={`px-3 py-1.5 rounded-lg text-xs font-bold transition-all ${
                      fileSizeGB === item.gb
                        ? 'bg-amber-400 text-zinc-950 shadow'
                        : 'bg-zinc-900 text-zinc-400 hover:text-zinc-200 border border-zinc-800'
                    }`}
                  >
                    {item.label}
                  </button>
                ))}

                {/* Custom GB input */}
                <div className="flex items-center gap-1.5 ml-auto">
                  <span className="text-xs text-zinc-500">{t.customSize}:</span>
                  <input
                    type="number"
                    min="0.1"
                    step="0.1"
                    value={fileSizeGB}
                    onChange={(e) => setFileSizeGB(Math.max(0.1, parseFloat(e.target.value) || 0.1))}
                    className="w-20 bg-zinc-900 border border-zinc-700 rounded px-2 py-1 text-xs text-amber-300 font-bold focus:outline-none focus:border-amber-400"
                  />
                  <span className="text-xs text-zinc-400">GB</span>
                </div>
              </div>
            </div>

            {/* Drag and drop upload box */}
            <div className="relative border-2 border-dashed border-zinc-700 hover:border-amber-400/80 bg-zinc-950/60 hover:bg-zinc-950 p-8 sm:p-10 rounded-xl text-center transition-all space-y-3 group">
              <input
                type="file"
                id="file-upload-input"
                onChange={handleRealFileUpload}
                className="absolute inset-0 w-full h-full opacity-0 cursor-pointer"
              />
              <div className="w-12 h-12 rounded-full bg-amber-500/10 border border-amber-500/20 text-amber-400 flex items-center justify-center mx-auto group-hover:scale-110 transition-transform">
                <FileUp className="w-6 h-6" />
              </div>
              <div className="space-y-1">
                <h3 className="text-sm sm:text-base font-bold text-zinc-200">
                  {t.dropZoneTitle}
                </h3>
                <p className="text-xs text-zinc-400">
                  {t.dropZoneDesc}: <strong className="text-amber-300">{retentionDays} {t.daysDuration}</strong> &middot; <strong className="text-emerald-300">{privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}</strong> &middot; Size: <strong className="text-zinc-200">{fileSizeGB} GB</strong>
                </p>
              </div>

              <div className="pt-2 flex items-center justify-center gap-3">
                <button
                  type="button"
                  onClick={startSimulatedUpload}
                  className="px-5 py-2.5 rounded-xl bg-amber-400 hover:bg-amber-300 text-zinc-950 font-bold text-xs shadow-lg shadow-amber-400/20 flex items-center gap-2"
                >
                  <FileUp className="w-4 h-4" />
                  <span>{t.uploadBtnText} (€{totalDueEUR.toFixed(2)})</span>
                </button>
              </div>
            </div>

            {/* EXPLICIT MENTION: 7-ZIP PASSPHRASE LOCK & BITCOIN ADDRESS FILENAME RECOMMENDATION */}
            <div className="p-4 sm:p-5 bg-zinc-950 border border-zinc-800/90 rounded-xl space-y-3.5 text-xs font-mono">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-2.5">
                <div className="flex items-center gap-2 text-zinc-200 font-bold">
                  <Archive className="w-4 h-4 text-amber-400" />
                  <span>{t.sevenZipNoticeTitle}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/10 text-emerald-400 border border-emerald-500/30 text-[10px] font-bold self-start sm:self-auto">
                  {t.sevenZipNoticeBadge}
                </span>
              </div>

              <p className="text-zinc-300 leading-relaxed text-xs">
                {t.sevenZipNoticeText}
              </p>

              <div className="grid grid-cols-1 md:grid-cols-2 gap-3 pt-1">
                <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-1.5 text-amber-400 font-bold text-[11px]">
                    <Key className="w-3.5 h-3.5" />
                    <span>1. Passphrase Protection (AES-256):</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-normal">
                    {t.sevenZipPassphraseTip}
                  </p>
                </div>

                <div className="p-3 rounded-lg bg-zinc-900 border border-zinc-800/80 space-y-1">
                  <div className="flex items-center gap-1.5 text-emerald-400 font-bold text-[11px]">
                    <FileKey className="w-3.5 h-3.5" />
                    <span>2. Bitcoin-Style Address Filename:</span>
                  </div>
                  <p className="text-[11px] text-zinc-400 leading-normal">
                    {t.sevenZipFilenameTip}
                  </p>
                </div>
              </div>

              {/* Interactive Helper: Generate Sample BTC Address Filename */}
              <div className="p-3 rounded-lg bg-zinc-900/90 border border-zinc-800 flex flex-col sm:flex-row sm:items-center justify-between gap-2.5">
                <div className="flex items-center gap-2">
                  <span className="text-zinc-400 text-[11px]">Generate sample BTC filename:</span>
                  {generatedBtcFilename ? (
                    <code className="text-amber-300 font-bold text-xs select-all bg-zinc-950 px-2 py-1 rounded border border-zinc-800">
                      {generatedBtcFilename}
                    </code>
                  ) : (
                    <span className="text-zinc-500 text-[11px] italic">e.g. bc1q8x4...7z</span>
                  )}
                </div>

                <div className="flex items-center gap-2">
                  <button
                    type="button"
                    onClick={handleGenerateBtcFilename}
                    className="px-3 py-1 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded text-xs font-bold transition-all"
                  >
                    {generatedBtcFilename ? 'Regenerate' : 'Generate & Copy Sample BTC Filename'}
                  </button>
                  {generatedBtcFilename && (
                    <span className="text-[11px] text-emerald-400 font-bold">
                      {copiedKey === 'sample_btc_name' ? 'Copied!' : ''}
                    </span>
                  )}
                </div>
              </div>

              {/* Clear Non-Mandatory Callout */}
              <div className="p-2.5 rounded-lg bg-amber-500/10 border border-amber-500/30 text-amber-200 text-[11px] leading-relaxed flex items-start gap-2">
                <AlertTriangle className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
                <span>
                  <strong>{t.sevenZipNotMandatory}</strong>
                </span>
              </div>
            </div>

            {/* TOR OBFS4 BRIDGE SUPPORT NOTICE & SETUP GUIDE */}
            <div className="p-4 sm:p-5 bg-zinc-950 border border-emerald-500/30 rounded-xl space-y-3 text-xs font-mono">
              <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-zinc-800 pb-2.5">
                <div className="flex items-center gap-2 text-emerald-300 font-bold">
                  <Radio className="w-4 h-4 text-emerald-400" />
                  <span>{t.obfs4Title}</span>
                </div>
                <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 border border-emerald-500/40 text-[10px] font-bold self-start sm:self-auto">
                  {t.obfs4Badge}
                </span>
              </div>

              <p className="text-zinc-300 leading-relaxed text-xs">
                {t.obfs4Desc}
              </p>

              <div className="p-3 bg-zinc-900 rounded-lg border border-zinc-800 space-y-1 text-[11px] text-zinc-300">
                <span className="text-amber-400 font-bold block">How to connect with obfs4:</span>
                <p className="text-zinc-400 leading-normal">
                  {t.obfs4HowTo}
                </p>
              </div>
            </div>

          </div>
        )}

        {/* STEP B: UPLOADING PROGRESS */}
        {uploadStep === 'uploading' && (
          <div className="p-8 bg-zinc-950 border border-zinc-800 rounded-xl space-y-4 font-mono text-center">
            <div className="flex items-center justify-center gap-3 text-amber-400 font-bold text-sm">
              <Zap className="w-5 h-5 animate-pulse" />
              <span>{t.uploadingText} ({fileSizeGB} GB &middot; {retentionDays} {t.daysDuration} &middot; {privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic})...</span>
            </div>
            <div className="w-full max-w-md mx-auto bg-zinc-900 rounded-full h-3 overflow-hidden border border-zinc-800">
              <div 
                className="bg-amber-400 h-full transition-all duration-200"
                style={{ width: `${uploadProgress}%` }}
              ></div>
            </div>
            <p className="text-xs text-zinc-500">
              {t.uploadingSubtext}
            </p>
          </div>
        )}

        {/* STEP C: UPLOAD FINISHED -> EXACT BITCOIN INVOICE GENERATED */}
        {uploadStep === 'uploaded_awaiting_payment' && (
          <div className="space-y-5">
            
            {/* File info banner */}
            <div className="p-3 bg-emerald-950/40 border border-emerald-500/40 rounded-xl flex flex-col sm:flex-row sm:items-center justify-between text-xs font-mono gap-2">
              <div className="flex items-center gap-2 text-emerald-300">
                <CheckCircle2 className="w-4 h-4 text-emerald-400 flex-shrink-0" />
                <span>
                  {t.invoiceCompleteTitle}: <strong>{fileName}</strong> ({fileSizeGB} GB) &middot; <span className="text-amber-300 font-bold">{retentionDays} {t.daysDuration}</span> &middot; <span className="text-emerald-300 font-bold">{privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}</span>
                </span>
              </div>
              <span className="text-[11px] bg-amber-500/20 text-amber-300 border border-amber-500/40 px-2 py-0.5 rounded font-bold self-start sm:self-auto">
                ⏱️ {t.paymentCountdown}
              </span>
            </div>

            {/* Quick Option Modifier in Invoice View */}
            <div className="p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg flex flex-wrap items-center justify-between gap-2 text-xs font-mono">
              <div className="flex items-center gap-2">
                <span className="text-zinc-400">Change Options Before Paying:</span>
                <button
                  type="button"
                  onClick={() => setRetentionDays(retentionDays === 30 ? 60 : 30)}
                  className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-amber-300 hover:text-amber-200 text-[11px]"
                >
                  Retention: {retentionDays}d &harr; {retentionDays === 30 ? '60d' : '30d'}
                </button>
                <button
                  type="button"
                  onClick={() => setPrivacyTier(privacyTier === 'public' ? 'private' : 'public')}
                  className="px-2 py-0.5 rounded bg-zinc-900 border border-zinc-700 text-emerald-300 hover:text-emerald-200 text-[11px]"
                >
                  Privacy: {privacyTier === 'public' ? t.privacyPublic : t.privacyPrivate} &harr; {privacyTier === 'public' ? t.privacyPrivate : t.privacyPublic}
                </button>
              </div>
              <span className="text-zinc-400 text-[11px]">
                Active rate: <strong className="text-zinc-200">€{activePlan.ratePerGbEUR.toFixed(2)}{t.per1Gb}</strong>
              </span>
            </div>

            {/* Customer Cryptographic Hash & Resilient Buffer Banner */}
            <div className="p-2.5 bg-zinc-950 border border-zinc-800 rounded-lg flex flex-col sm:flex-row sm:items-center justify-between gap-2 text-[11px] font-mono">
              <div className="flex items-center gap-1.5 text-zinc-400">
                <span className="text-emerald-400 font-bold">Customer Hash:</span>
                <code className="text-zinc-200 select-all font-mono break-all">{customerHash.slice(0, 24)}...{customerHash.slice(-8)}</code>
                <button
                  type="button"
                  onClick={() => copyToClipboard(customerHash, 'cust_hash')}
                  className="p-0.5 px-1.5 rounded bg-zinc-800 text-[10px] text-zinc-300 hover:text-white"
                >
                  {copiedKey === 'cust_hash' ? 'Copied' : 'Copy'}
                </button>
              </div>
              <span className="text-emerald-400 flex items-center gap-1">
                <span className="w-1.5 h-1.5 rounded-full bg-emerald-400 animate-pulse"></span>
                Tor Chunk Buffer: Resumable (Isolated RAM)
              </span>
            </div>

            {/* Bitcoin Invoice Block */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-5 bg-zinc-950 border border-zinc-800 p-5 rounded-xl font-mono">
              
              {/* QR Code */}
              <div className="flex flex-col items-center justify-center p-3 bg-white rounded-xl w-fit mx-auto">
                <QRCodeSVG 
                  value={`bitcoin:${activePlan.recommendedAddress}?amount=${totalDueBTC}&label=TorDrop_${fileSizeGB}GB`} 
                  size={150}
                  level="M"
                />
                <span className="text-[10px] text-zinc-800 font-bold mt-1.5">{t.scanWithWallet}</span>
              </div>

              {/* Payment Details */}
              <div className="md:col-span-2 space-y-3 flex flex-col justify-between">
                <div>
                  <div className="flex items-center justify-between text-[10px] text-zinc-400 uppercase tracking-wider font-bold mb-1">
                    <span>Invoice for {fileSizeGB} GB ({fileSizeGB} × €{activePlan.ratePerGbEUR.toFixed(2)}{t.per1Gb}):</span>
                    <span className="text-emerald-400">{activePlan.durationDays} {t.daysDuration} &middot; {privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}</span>
                  </div>
                  
                  <div className="flex items-baseline gap-2">
                    <span className="text-3xl sm:text-4xl font-black text-amber-400">
                      {totalDueSats.toLocaleString()} sats
                    </span>
                    <span className="text-xs text-zinc-400">
                      (~{totalDueBTC} BTC · <strong>€{totalDueEUR.toFixed(2)}</strong>)
                    </span>
                  </div>
                </div>

                <div className="space-y-1.5">
                  <span className="text-[10px] text-zinc-500 uppercase tracking-wider font-bold block">
                    {t.singleUseAddress}
                  </span>
                  <div className="flex items-center gap-2 p-2.5 bg-zinc-900 rounded-lg border border-zinc-800 text-xs">
                    <code className="text-zinc-200 select-all font-mono break-all text-[11px] sm:text-xs">
                      {activePlan.recommendedAddress}
                    </code>
                    <button
                      type="button"
                      onClick={() => copyToClipboard(activePlan.recommendedAddress, 'invoice_addr')}
                      className="p-1.5 px-2.5 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center gap-1 text-xs flex-shrink-0"
                    >
                      {copiedKey === 'invoice_addr' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                      {copiedKey === 'invoice_addr' ? 'Copied' : 'Copy'}
                    </button>
                  </div>
                </div>

                <div className="flex flex-wrap items-center justify-between gap-2 pt-2 border-t border-zinc-800 text-[11px]">
                  <span className="text-zinc-400 flex items-center gap-1.5">
                    <Zap className="w-3.5 h-3.5 text-amber-400 animate-pulse" />
                    {t.daemonListening}
                  </span>
                  <button
                    type="button"
                    onClick={() => setUploadStep('simulated_paid')}
                    className="text-emerald-400 hover:text-emerald-300 underline font-bold"
                  >
                    {t.simulatePayBtn}
                  </button>
                </div>
              </div>

            </div>
          </div>
        )}

        {/* STEP D: PAYMENT RECEIVED -> FILE ACCEPTED & OPEN SESSION AUTOMATICALLY CLOSED (RAM SAVED!) */}
        {uploadStep === 'simulated_paid' && (
          <div className="p-5 sm:p-6 bg-emerald-950/40 border-2 border-emerald-500/60 rounded-xl space-y-4 font-mono">
            
            {/* Success Header */}
            <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2 border-b border-emerald-900/50 pb-3">
              <div className="flex items-center gap-2 text-emerald-300 font-bold text-sm sm:text-base">
                <CheckCircle2 className="w-5 h-5 text-emerald-400 flex-shrink-0" />
                <span>{t.paymentConfirmedTitle} ({totalDueSats.toLocaleString()} sats)</span>
              </div>
              <span className="text-xs bg-emerald-500/20 text-emerald-300 px-2.5 py-1 rounded-full border border-emerald-500/40 font-bold">
                Retention: {activePlan.durationDays} {t.daysDuration} &middot; {privacyTier === 'private' ? t.privacyPrivate : t.privacyPublic}
              </span>
            </div>

            {/* RAM SAVINGS & SESSION CLOSED CONFIRMATION */}
            <div className="p-3.5 bg-zinc-950 border border-zinc-800 rounded-xl space-y-2 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Cpu className="w-4 h-4 text-emerald-400" />
                <span>{t.ramPurgedTitle}</span>
              </div>
              <p className="text-zinc-300 leading-relaxed text-[11px]">
                {t.ramPurgedDesc}
              </p>
            </div>

            {/* Permanent .Onion Link */}
            <div className="p-4 bg-zinc-950 rounded-xl border border-zinc-800 space-y-2 text-xs">
              <span className="text-zinc-400 block text-[11px] font-bold">
                {privacyTier === 'private' ? t.stealthKeyTitle : t.downloadLinkTitle}
              </span>
              <div className="flex flex-col sm:flex-row sm:items-center justify-between p-2.5 bg-zinc-900 rounded-lg text-emerald-300 font-bold text-xs gap-2 break-all">
                <span>
                  {privacyTier === 'private' 
                    ? `http://drop7h2kfa92lx8p3m0ql9v2k7m.onion/stealth/${customerHash.slice(0, 16)}` 
                    : `http://drop7h2kfa92lx8p3m0ql9v2k7m.onion/download/drop_${fileSizeGB}gb`}
                </span>
                <button
                  type="button"
                  onClick={() => copyToClipboard(
                    privacyTier === 'private' 
                      ? `http://drop7h2kfa92lx8p3m0ql9v2k7m.onion/stealth/${customerHash.slice(0, 16)}` 
                      : `http://drop7h2kfa92lx8p3m0ql9v2k7m.onion/download/drop_${fileSizeGB}gb`,
                    'onion_dl_link'
                  )}
                  className="p-1.5 px-3 bg-zinc-800 text-zinc-300 rounded hover:bg-zinc-700 text-xs flex items-center gap-1 self-start sm:self-auto flex-shrink-0"
                >
                  {copiedKey === 'onion_dl_link' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
                  <span>{copiedKey === 'onion_dl_link' ? t.copiedBtn : t.copyBtn}</span>
                </button>
              </div>

              {privacyTier === 'private' && (
                <div className="p-2.5 bg-zinc-900/80 rounded border border-zinc-800 text-zinc-300 text-[11px] space-y-1">
                  <span className="text-amber-300 font-bold block">{t.stealthKeyTitle}</span>
                  <code className="text-zinc-200 break-all select-all font-mono">
                    descriptor:x25519:{customerHash.slice(16, 48)}
                  </code>
                </div>
              )}

              <p className="text-[11px] text-zinc-500">
                {t.autoShredDate} in {retentionDays} {t.daysDuration}.
              </p>
            </div>

            <button
              type="button"
              onClick={() => {
                setUploadStep('idle');
                setUploadProgress(0);
              }}
              className="text-xs text-zinc-400 hover:text-zinc-200 flex items-center gap-1 pt-1"
            >
              <RotateCcw className="w-3.5 h-3.5" /> {t.startAnotherDrop}
            </button>
          </div>
        )}

      </div>

    </section>
  );
};
