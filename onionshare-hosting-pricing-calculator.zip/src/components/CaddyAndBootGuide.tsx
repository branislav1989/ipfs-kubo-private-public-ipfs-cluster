import React, { useState } from 'react';
import { 
  Terminal, 
  Check, 
  Copy, 
  Server, 
  Cpu, 
  HardDrive, 
  ShieldCheck, 
  RotateCcw, 
  Zap, 
  FolderSync, 
  Lock, 
  FileCode, 
  CheckCircle2, 
  Layers,
  ArrowRight,
  Hash,
  RefreshCw,
  Clock
} from 'lucide-react';

export const CaddyAndBootGuide: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'one_command_deploy' | 'caddyfile' | 'systemd_boot' | 'chunk_buffering' | 'customer_hash'>('one_command_deploy');
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  const sampleCustomerHash = "e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855";

  return (
    <div className="bg-zinc-900/90 border-2 border-amber-500/40 rounded-2xl p-4 sm:p-6 lg:p-7 space-y-6 shadow-xl shadow-amber-950/20 relative overflow-hidden">
      
      {/* Background glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-amber-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-start lg:justify-between gap-4 pb-5 border-b border-zinc-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-amber-500/20 text-amber-300 border border-amber-500/30 flex items-center gap-1.5">
              <Server className="w-3.5 h-3.5" /> Production Deployment Stack
            </span>
            <span className="text-xs text-zinc-400 font-mono">Caddy Server · Systemd Auto-Boot · Resilient Buffering</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-100 tracking-tight">
            Caddy Reverse Proxy + <span className="text-amber-400">Systemd Auto-Boot</span> & <span className="text-emerald-400">Customer SHA-256 Hashes</span>
          </h2>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            Configure <strong>Caddy</strong> for unlimited upload streaming, register <strong>Systemd services</strong> so everything restarts automatically if your PC reboots, enable <strong>chunk buffering for dropped Tor connections</strong>, and issue a unique <strong>cryptographic customer hash</strong> for session isolation and RAM cleanup.
          </p>
        </div>

        {/* Tab Navigation */}
        <div className="flex flex-wrap bg-zinc-950 border border-zinc-800 rounded-xl p-1 text-xs font-mono self-start lg:self-center gap-1">
          <button
            type="button"
            onClick={() => setActiveTab('one_command_deploy')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'one_command_deploy'
                ? 'bg-amber-400 text-zinc-950 font-bold shadow'
                : 'text-amber-400 hover:text-amber-200'
            }`}
          >
            <Zap className="w-3.5 h-3.5" /> ⚡ 1-Command Deploy
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('caddyfile')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'caddyfile'
                ? 'bg-amber-400 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FileCode className="w-3.5 h-3.5" /> 1. Caddyfile Config
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('systemd_boot')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'systemd_boot'
                ? 'bg-amber-400 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <RotateCcw className="w-3.5 h-3.5" /> 2. Auto-Boot Systemd
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('chunk_buffering')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'chunk_buffering'
                ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <FolderSync className="w-3.5 h-3.5" /> 3. Tor Drop Resilience
          </button>
          <button
            type="button"
            onClick={() => setActiveTab('customer_hash')}
            className={`px-3 py-1.5 rounded-lg transition-all flex items-center gap-1.5 ${
              activeTab === 'customer_hash'
                ? 'bg-emerald-500 text-zinc-950 font-bold shadow'
                : 'text-zinc-400 hover:text-zinc-200'
            }`}
          >
            <Hash className="w-3.5 h-3.5" /> 4. Customer Hash
          </button>
        </div>
      </div>

      {/* TAB 0: 1-COMMAND AUTOMATED DEPLOYMENT */}
      {activeTab === 'one_command_deploy' && (
        <div className="space-y-5 font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="space-y-0.5">
              <h3 className="text-sm sm:text-base font-bold text-amber-300 flex items-center gap-2">
                <Zap className="w-4 h-4 text-amber-400" />
                Single-Command Fully Automated Linux Deployment
              </h3>
              <p className="text-xs text-zinc-400">
                Executes everything: installs Tor, Caddy, Node.js; compiles production build; registers Systemd auto-boot; sets up .onion v3 hidden service.
              </p>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard('sudo bash deploy.sh', 'one_cmd_run')}
              className="px-3 py-1.5 rounded-lg bg-amber-400 text-zinc-950 font-bold text-xs flex items-center gap-1.5 self-start sm:self-auto hover:bg-amber-300 transition-colors shadow-md shadow-amber-400/20"
            >
              {copiedKey === 'one_cmd_run' ? <Check className="w-3.5 h-3.5 text-zinc-950" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey === 'one_cmd_run' ? 'Copied Command' : 'Copy 1-Liner'}</span>
            </button>
          </div>

          {/* Code block for quick execution */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <span>Option A: Run directly from the project directory</span>
              <span className="text-emerald-400">100% Automated</span>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs">
              <code className="text-amber-300 select-all font-mono break-all font-bold">
                sudo bash deploy.sh
              </code>
              <button
                type="button"
                onClick={() => copyToClipboard('sudo bash deploy.sh', 'deploy_sh')}
                className="p-1 px-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] flex items-center gap-1 flex-shrink-0"
              >
                {copiedKey === 'deploy_sh' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedKey === 'deploy_sh' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* Option B: Git Clone + Deploy in 1 line */}
          <div className="space-y-2">
            <div className="flex items-center justify-between text-[11px] text-zinc-400">
              <span>Option B: Fresh VPS / Server bootstrap (clone & deploy in 1 command)</span>
              <span className="text-zinc-500">Debian / Ubuntu / Raspbian</span>
            </div>
            <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 flex items-center justify-between gap-3 text-xs">
              <code className="text-zinc-200 select-all font-mono break-all text-[11px]">
                sudo apt update && sudo apt install -y git && git clone https://github.com/your-username/onionshield-oasis.git /opt/onionshield && cd /opt/onionshield && sudo bash deploy.sh
              </code>
              <button
                type="button"
                onClick={() => copyToClipboard('sudo apt update && sudo apt install -y git && git clone https://github.com/your-username/onionshield-oasis.git /opt/onionshield && cd /opt/onionshield && sudo bash deploy.sh', 'clone_deploy')}
                className="p-1 px-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-300 rounded text-[11px] flex items-center gap-1 flex-shrink-0"
              >
                {copiedKey === 'clone_deploy' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedKey === 'clone_deploy' ? 'Copied' : 'Copy'}</span>
              </button>
            </div>
          </div>

          {/* What this command does automatically breakdown */}
          <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-3 pt-2">
            <div className="p-3 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-1 text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>1. Dependencies</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Installs Tor daemon, Caddy web server, SQLite3, Node.js LTS, and system libraries via apt.
              </p>
            </div>

            <div className="p-3 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-1 text-xs">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>2. Hardened Systemd</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Creates unprivileged <code className="text-zinc-200">onionshield</code> user and enables auto-restart if the server reboots.
              </p>
            </div>

            <div className="p-3 bg-zinc-950/70 border border-zinc-800 rounded-xl space-y-1 text-xs">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <CheckCircle2 className="w-3.5 h-3.5" />
                <span>3. Tor v3 .Onion Ready</span>
              </div>
              <p className="text-[11px] text-zinc-400 leading-relaxed">
                Generates <code className="text-zinc-200">/var/lib/tor/onionshield_service/hostname</code> and prints your .onion link in terminal.
              </p>
            </div>
          </div>

          {/* Boot reboot verification */}
          <div className="p-3 bg-amber-950/30 border border-amber-500/30 rounded-xl flex items-start gap-2.5 text-xs text-amber-200">
            <RotateCcw className="w-4 h-4 text-amber-400 flex-shrink-0 mt-0.5" />
            <div className="space-y-0.5">
              <span className="font-bold block">Reboot Resilience Guarantee:</span>
              <p className="text-[11px] text-zinc-300 leading-relaxed">
                Because all services are configured with <code className="text-amber-300">systemctl enable</code>, if your PC or server experiences an unexpected power cut, crash, or scheduled reboot, systemd automatically restores Tor, Caddy, and OnionShield Oasis within seconds of booting up.
              </p>
            </div>
          </div>
        </div>
      )}

      {/* TAB 1: CADDYFILE CONFIGURATION */}
      {activeTab === 'caddyfile' && (
        <div className="space-y-4 font-mono">
          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-2">
            <div className="space-y-0.5">
              <h3 className="text-sm sm:text-base font-bold text-zinc-100 flex items-center gap-2">
                <FileCode className="w-4 h-4 text-amber-400" />
                Production Caddyfile (<code className="text-amber-300 text-xs">/etc/caddy/Caddyfile</code>)
              </h3>
              <p className="text-xs text-zinc-400">
                Optimized for Tor Hidden Services: Unlimited upload body, long Tor circuit timeouts, and streaming buffer.
              </p>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(`# /etc/caddy/Caddyfile
# Clean Caddy config for Tor OnionShare & Python Upload Vault
{
    # Disable automatic TLS: Tor already provides end-to-end ed25519 encryption
    auto_https off
    admin off
}

:8080 {
    # Bind to loopback only (only Tor accesses this port)
    bind 127.0.0.1

    # UNLIMITED UPLOAD BODY: No 1MB or 1GB artificial limits!
    request_body {
        max_size 0
    }

    # Extended timeouts for high-latency Tor circuits (up to 2 hours for slow circuits)
    timeouts {
        read_body 7200s
        read_header 60s
        write 7200s
        idle 300s
    }

    # Reverse proxy to your Python backend with buffer streaming
    reverse_proxy 127.0.0.1:5000 {
        # Stream request without accumulating multi-gigabyte files into Caddy RAM
        flush_interval -1
        
        # Keepalive and backend timeout
        transport http {
            read_timeout 7200s
            dial_timeout 30s
            response_header_timeout 7200s
        }
    }

    # Security headers
    header {
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "no-referrer"
        Server "OnionVault"
    }
}`, 'caddyfile')}
              className="px-3 py-1.5 rounded-lg bg-zinc-800 hover:bg-zinc-700 text-zinc-200 text-xs flex items-center gap-1.5 self-start sm:self-auto border border-zinc-700"
            >
              {copiedKey === 'caddyfile' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              <span>{copiedKey === 'caddyfile' ? 'Copied Caddyfile' : 'Copy Caddyfile'}</span>
            </button>
          </div>

          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 overflow-x-auto text-xs text-zinc-200 leading-relaxed">
            <pre className="text-[11px] sm:text-xs text-zinc-300">
{`# /etc/caddy/Caddyfile
# Clean Caddy config for Tor OnionShare & Python Upload Vault
{
    # Disable automatic TLS: Tor already provides end-to-end ed25519 encryption
    auto_https off
    admin off
}

:8080 {
    # Bind to loopback only (only Tor daemon routes traffic here)
    bind 127.0.0.1

    # UNLIMITED UPLOAD BODY: No artificial 1MB or 1GB file limit!
    request_body {
        max_size 0
    }

    # Extended timeouts for high-latency Tor circuits (2 hours for multi-GB uploads)
    timeouts {
        read_body 7200s
        read_header 60s
        write 7200s
        idle 300s
    }

    # Reverse proxy to Python backend (port 5000)
    reverse_proxy 127.0.0.1:5000 {
        # Stream immediately without buffering entire multi-GB file in Caddy RAM
        flush_interval -1
        
        transport http {
            read_timeout 7200s
            dial_timeout 30s
            response_header_timeout 7200s
        }
    }

    # Hardened security headers
    header {
        X-Content-Type-Options "nosniff"
        X-Frame-Options "DENY"
        Referrer-Policy "no-referrer"
        Server "OnionVault"
    }
}`}
            </pre>
          </div>

          {/* Torrc snippet matching Caddy */}
          <div className="p-4 bg-zinc-950/80 border border-zinc-800 rounded-xl space-y-2 text-xs">
            <span className="text-zinc-400 font-bold block text-[11px]">Matching Tor Hidden Service Directive (<code className="text-amber-300">/etc/tor/torrc</code>):</span>
            <div className="p-2.5 bg-zinc-900 rounded border border-zinc-800 text-emerald-300">
              <code>HiddenServiceDir /var/lib/tor/onionshare_service/</code><br />
              <code>HiddenServicePort 80 127.0.0.1:8080</code>
            </div>
            <p className="text-zinc-500 text-[11px]">
              Tor listens on port 80 externally and forwards packets to Caddy on local port 8080. Caddy proxies to Python on port 5000.
            </p>
          </div>
        </div>
      )}

      {/* TAB 2: SYSTEMD AUTO-BOOT SERVICES */}
      {activeTab === 'systemd_boot' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-bold text-zinc-100 flex items-center gap-2">
              <RotateCcw className="w-4 h-4 text-amber-400" />
              Automated Boot Architecture (Survives Server Reboots)
            </h3>
            <p className="text-zinc-400">
              When your PC boots, the systemd dependency chain brings up <strong>Tor &rarr; Caddy &rarr; Python Payment Watcher</strong> automatically.
            </p>
          </div>

          {/* Service Unit File */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-amber-400 font-bold">1. Systemd Service File: <code className="text-zinc-200">/etc/systemd/system/tor-vault.service</code></span>
              <button
                type="button"
                onClick={() => copyToClipboard(`[Unit]
Description=Tor Onion Vault & Bitcoin Payment Watcher
After=network.target tor.service caddy.service
Requires=tor.service caddy.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/tor-vault
ExecStart=/usr/bin/python3 /opt/tor-vault/daemon_payment_watcher.py
Restart=always
RestartSec=5s
StandardOutput=journal
StandardError=journal

# Hardening
ProtectSystem=full
PrivateTmp=true

[Install]
WantedBy=multi-user.target`, 'systemd_unit')}
                className="p-1 px-2 rounded bg-zinc-800 hover:bg-zinc-700 text-zinc-300 flex items-center gap-1 text-[11px]"
              >
                {copiedKey === 'systemd_unit' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
                <span>{copiedKey === 'systemd_unit' ? 'Copied' : 'Copy Service'}</span>
              </button>
            </div>

            <pre className="text-[11px] text-zinc-300 bg-zinc-900 p-3 rounded-lg overflow-x-auto leading-relaxed">
{`[Unit]
Description=Tor Onion Vault & Bitcoin Payment Watcher
After=network.target tor.service caddy.service
Requires=tor.service caddy.service

[Service]
Type=simple
User=root
WorkingDirectory=/opt/tor-vault
ExecStart=/usr/bin/python3 /opt/tor-vault/daemon_payment_watcher.py
Restart=always
RestartSec=5s
StandardOutput=journal
StandardError=journal

# Security sandbox
ProtectSystem=full
PrivateTmp=true

[Install]
WantedBy=multi-user.target`}
            </pre>
          </div>

          {/* Commands to enable on boot */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-2">
            <span className="text-zinc-300 font-bold block">2. Shell Commands to Enable and Start on Boot:</span>
            <div className="p-3 bg-zinc-900 rounded-lg space-y-1 text-amber-300">
              <div><code>sudo systemctl daemon-reload</code></div>
              <div><code>sudo systemctl enable tor caddy tor-vault</code></div>
              <div><code>sudo systemctl start tor caddy tor-vault</code></div>
              <div><code>sudo systemctl status tor-vault --no-pager</code></div>
            </div>
            <p className="text-[11px] text-emerald-400">
              &check; If power fails or the machine restarts, all 3 daemons automatically boot and resume listening.
            </p>
          </div>
        </div>
      )}

      {/* TAB 3: RESUMABLE CHUNK BUFFERING FOR DROPPED TOR CONNECTIONS */}
      {activeTab === 'chunk_buffering' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-bold text-zinc-100 flex items-center gap-2">
              <FolderSync className="w-4 h-4 text-emerald-400" />
              Handling Dropped Tor Connections (Chunked Staging Buffers)
            </h3>
            <p className="text-zinc-400">
              Tor circuits naturally rotate every 10 minutes. If an upload is 5 GB or 15 GB, a circuit drop shouldn't force the customer to re-upload from 0%!
            </p>
          </div>

          <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
            <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-amber-400 font-bold">
                <Layers className="w-4 h-4" />
                <span>1. 25 MB Chunks</span>
              </div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Client slices large files into 25 MB encrypted chunks. Each chunk is streamed with its chunk index and customer hash.
              </p>
            </div>

            <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-cyan-400 font-bold">
                <RefreshCw className="w-4 h-4" />
                <span>2. Resume on Circuit Drop</span>
              </div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                If the Tor circuit collapses, the client reconnects via a new circuit and checks <code className="text-cyan-300">/api/upload/status?hash=...</code> to resume from the last saved chunk.
              </p>
            </div>

            <div className="bg-zinc-950 border border-zinc-800 p-4 rounded-xl space-y-2">
              <div className="flex items-center gap-2 text-emerald-400 font-bold">
                <ShieldCheck className="w-4 h-4" />
                <span>3. RAM Purged on Merge</span>
              </div>
              <p className="text-zinc-400 text-[11px] leading-relaxed">
                Once all chunks land, Python merges and stream-encrypts the final file, then unlinks all temporary chunk files to free memory.
              </p>
            </div>
          </div>

          {/* Python Chunk Endpoint Snippet */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-2">
            <span className="text-zinc-300 font-bold">Python Resumable Upload Handler:</span>
            <pre className="text-[11px] text-zinc-300 bg-zinc-900 p-3 rounded-lg overflow-x-auto leading-relaxed">
{`# /opt/tor-vault/upload_receiver.py
import os, shutil

STAGING_BASE = "/vault/staging"

@app.route('/api/upload/chunk', methods=['POST'])
def receive_chunk():
    customer_hash = request.form['customer_hash']
    chunk_index = int(request.form['chunk_index'])
    total_chunks = int(request.form['total_chunks'])
    chunk_file = request.files['file']

    customer_dir = os.path.join(STAGING_BASE, customer_hash, "chunks")
    os.makedirs(customer_dir, exist_ok=True)

    # Save individual chunk
    chunk_path = os.path.join(customer_dir, f"chunk_{chunk_index:05d}")
    chunk_file.save(chunk_path)

    # If last chunk received -> reassemble and verify
    received_count = len(os.listdir(customer_dir))
    if received_count == total_chunks:
        final_file = assemble_chunks(customer_hash, total_chunks)
        # Reclaim chunk storage immediately
        shutil.rmtree(customer_dir, ignore_errors=True)
        return jsonify({"status": "complete", "size": os.path.getsize(final_file)})

    return jsonify({"status": "chunk_saved", "next_index": chunk_index + 1})`}
            </pre>
          </div>
        </div>
      )}

      {/* TAB 4: CUSTOMER HASH GENERATION & USAGE */}
      {activeTab === 'customer_hash' && (
        <div className="space-y-4 font-mono text-xs">
          <div className="space-y-1">
            <h3 className="text-sm sm:text-base font-bold text-zinc-100 flex items-center gap-2">
              <Hash className="w-4 h-4 text-emerald-400" />
              Cryptographic Customer Hash (SHA-256)
            </h3>
            <p className="text-zinc-400">
              Every customer session receives a unique, collision-resistant <strong>SHA-256 Hash</strong> that binds their upload, Bitcoin address, and RAM buffer together.
            </p>
          </div>

          {/* Visual Customer Hash Card */}
          <div className="bg-zinc-950 border border-emerald-500/30 rounded-xl p-4 sm:p-5 space-y-3">
            <div className="flex items-center justify-between">
              <span className="text-zinc-400 font-bold flex items-center gap-1.5">
                <Hash className="w-4 h-4 text-emerald-400" /> Example Live Generated Customer Hash:
              </span>
              <span className="text-[10px] bg-emerald-500/20 text-emerald-300 px-2 py-0.5 rounded border border-emerald-500/40">
                256-Bit Cryptographic ID
              </span>
            </div>

            <div className="p-3 bg-zinc-900 rounded-lg text-emerald-300 font-bold break-all select-all text-xs border border-zinc-800">
              {sampleCustomerHash}
            </div>

            <div className="grid grid-cols-1 sm:grid-cols-2 gap-3 pt-2 text-zinc-300">
              <div className="p-3 bg-zinc-900/60 rounded-lg space-y-1 border border-zinc-800">
                <strong className="text-amber-300 block">1. Session & RAM Isolation</strong>
                <p className="text-zinc-400 text-[11px]">
                  Files buffer into <code className="text-zinc-300">/vault/staging/{sampleCustomerHash.slice(0, 8)}.../</code> so users never touch or corrupt each other's memory.
                </p>
              </div>

              <div className="p-3 bg-zinc-900/60 rounded-lg space-y-1 border border-zinc-800">
                <strong className="text-emerald-300 block">2. Automatic RAM Purge on Pay</strong>
                <p className="text-zinc-400 text-[11px]">
                  When Bitcoin payment lands, the server executes <code className="text-zinc-300">close_session(customer_hash)</code> and purges staging buffers instantly.
                </p>
              </div>
            </div>
          </div>

          {/* Python Hash Generation Formula */}
          <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-2">
            <span className="text-zinc-300 font-bold">Python Customer Hash Generation:</span>
            <pre className="text-[11px] text-zinc-300 bg-zinc-900 p-3 rounded-lg overflow-x-auto leading-relaxed">
{`import hashlib, secrets, time

def generate_customer_hash(client_session_id: str, chosen_plan: str) -> str:
    """Generates an unguessable SHA-256 session token for customer isolation."""
    entropy = secrets.token_hex(32)
    timestamp = str(time.time_ns())
    seed_string = f"{client_session_id}:{chosen_plan}:{timestamp}:{entropy}"
    return hashlib.sha256(seed_string.encode('utf-8')).hexdigest()

# Output example:
# 'e3b0c44298fc1c149afbf4c8996fb92427ae41e4649b934ca495991b7852b855'`}
            </pre>
          </div>
        </div>
      )}

    </div>
  );
};
