import React, { useState } from 'react';
import { Currency, ServerConfig } from '../types';
import { calculatePrice, formatCurrency } from '../utils/pricingCalculator';
import { FileText, Copy, Check, Download, Share2 } from 'lucide-react';

interface RateCardExporterProps {
  selectedCurrency: Currency;
  serverConfig: ServerConfig;
}

export const RateCardExporter: React.FC<RateCardExporterProps> = ({
  selectedCurrency,
  serverConfig,
}) => {
  const [format, setFormat] = useState<'markdown' | 'ascii' | 'json'>('markdown');
  const [pricingStyle, setPricingStyle] = useState<'retail_floor' | 'unit_rates'>('retail_floor');
  const [copied, setCopied] = useState(false);

  const res1mPub = calculatePrice(1, 1, 'public', serverConfig);
  const res1mPriv = calculatePrice(1, 1, 'private', serverConfig);
  const res2mPub = calculatePrice(1, 2, 'public', serverConfig);
  const res2mPriv = calculatePrice(1, 2, 'private', serverConfig);

  const getPrice = (res: typeof res1mPub) => {
    return pricingStyle === 'retail_floor' ? res.retailPriceWithFloorUSD : res.recommendedPriceUSD;
  };

  const generateContent = () => {
    const p1mPub = getPrice(res1mPub);
    const p1mPriv = getPrice(res1mPriv);
    const p2mPub = getPrice(res2mPub);
    const p2mPriv = getPrice(res2mPriv);

    if (format === 'markdown') {
      return `### 🛡️ OnionShieldOasis Rate Card (${pricingStyle === 'retail_floor' ? 'Single-Drop Retail Floor' : 'Scalable Unit Rates'})

| Tier / Specification | Retention Term | Price (${selectedCurrency}) | XMR Approx | Protocol / Security |
|:---|:---:|:---:|:---:|:---|
| **1 GB Public Link** | 1 Month (30d) | **${formatCurrency(p1mPub, selectedCurrency)}** | ${formatCurrency(p1mPub, 'XMR')} | Standard .onion slug, auto-wipe |
| **1 GB Private (Stealth)** | 1 Month (30d) | **${formatCurrency(p1mPriv, selectedCurrency)}** | ${formatCurrency(p1mPriv, 'XMR')} | v3 Client Authorization (x25519) |
| **1 GB Public Link** | 2 Months (60d) | **${formatCurrency(p2mPub, selectedCurrency)}** | ${formatCurrency(p2mPub, 'XMR')} | 60d HSDir descriptor refresh |
| **1 GB Private (Stealth)** | 2 Months (60d) | **${formatCurrency(p2mPriv, selectedCurrency)}** | ${formatCurrency(p2mPriv, 'XMR')} | Dedicated isolated RAM reservation |

*Payments accepted via Monero (XMR) & Bitcoin (BTC). Zero logging policy.*`;
    }

    if (format === 'ascii') {
      return `+-------------------------------------------------------------------------------+
|                      ONIONSHIELDOASIS TOR STORAGE RATE CARD                   |
| Model: ${(pricingStyle === 'retail_floor' ? 'Single-Drop Retail Floor' : 'Scalable Unit Rate').padEnd(63)}|
+----------------------------+-----------+--------------+-----------------------+
| SERVICE TIER               | RETENTION | PRICE (${selectedCurrency.padEnd(3)})   | MONERO (XMR)          |
+----------------------------+-----------+--------------+-----------------------+
| 1 GB Public Link           | 1 Month   | ${formatCurrency(p1mPub, selectedCurrency).padEnd(12)} | ${formatCurrency(p1mPub, 'XMR').padEnd(21)} |
| 1 GB Private (Client-Auth) | 1 Month   | ${formatCurrency(p1mPriv, selectedCurrency).padEnd(12)} | ${formatCurrency(p1mPriv, 'XMR').padEnd(21)} |
| 1 GB Public Link           | 2 Months  | ${formatCurrency(p2mPub, selectedCurrency).padEnd(12)} | ${formatCurrency(p2mPub, 'XMR').padEnd(21)} |
| 1 GB Private (Client-Auth) | 2 Months  | ${formatCurrency(p2mPriv, selectedCurrency).padEnd(12)} | ${formatCurrency(p2mPriv, 'XMR').padEnd(21)} |
+----------------------------+-----------+--------------+-----------------------+
* Automated cryptographic shredding on retention expiration (NIST SP 800-88).`;
    }

    return JSON.stringify(
      {
        provider: "OnionShieldOasis Tor Storage Node",
        pricing_model: pricingStyle,
        currency: selectedCurrency,
        tiers: [
          {
            id: "1gb_1m_public",
            storage_gb: 1,
            retention_months: 1,
            mode: "public",
            price: Number(p1mPub.toFixed(2)),
            price_xmr: Number((p1mPub * 0.0062).toFixed(4)),
            features: ["standard_v3_onion", "auto_shred_30d"]
          },
          {
            id: "1gb_1m_private",
            storage_gb: 1,
            retention_months: 1,
            mode: "private_client_auth",
            price: Number(p1mPriv.toFixed(2)),
            price_xmr: Number((p1mPriv * 0.0062).toFixed(4)),
            features: ["x25519_client_auth", "stealth_descriptor", "dedicated_socket"]
          },
          {
            id: "1gb_2m_public",
            storage_gb: 1,
            retention_months: 2,
            mode: "public",
            price: Number(p2mPub.toFixed(2)),
            price_xmr: Number((p2mPub * 0.0062).toFixed(4)),
            features: ["standard_v3_onion", "auto_shred_60d"]
          },
          {
            id: "1gb_2m_private",
            storage_gb: 1,
            retention_months: 2,
            mode: "private_client_auth",
            price: Number(p2mPriv.toFixed(2)),
            price_xmr: Number((p2mPriv * 0.0062).toFixed(4)),
            features: ["x25519_client_auth", "60d_reserved_ram_pool"]
          }
        ]
      },
      null,
      2
    );
  };

  const handleCopy = () => {
    navigator.clipboard.writeText(generateContent());
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  return (
    <div className="bg-zinc-900/40 border border-zinc-800 rounded-xl p-4 sm:p-6 space-y-4">
      
      <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-3 pb-3 border-b border-zinc-800">
        <div>
          <h3 className="text-base font-bold text-zinc-100 font-mono flex items-center gap-2">
            <FileText className="w-4 h-4 text-emerald-400" />
            Exportable Rate Card & Storefront Snippet
          </h3>
          <p className="text-xs text-zinc-400 mt-0.5">
            Copy a clean price table formatted for your Tor website, forum listing, or terms of service.
          </p>
        </div>

        <div className="flex flex-wrap items-center gap-2">
          {/* Pricing style selector */}
          <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-lg p-0.5 text-xs font-mono">
            <button
              type="button"
              id="style-floor-btn"
              onClick={() => setPricingStyle('retail_floor')}
              className={`px-2.5 py-1 rounded transition-all ${
                pricingStyle === 'retail_floor'
                  ? 'bg-amber-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              1-Off Floor
            </button>
            <button
              type="button"
              id="style-unit-btn"
              onClick={() => setPricingStyle('unit_rates')}
              className={`px-2.5 py-1 rounded transition-all ${
                pricingStyle === 'unit_rates'
                  ? 'bg-emerald-500 text-zinc-950 font-bold'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              Unit Rates
            </button>
          </div>

          {/* Format selector */}
          <div className="flex items-center bg-zinc-950 border border-zinc-800 rounded-lg p-0.5 text-xs font-mono">
            {(['markdown', 'ascii', 'json'] as const).map((fmt) => (
              <button
                key={fmt}
                type="button"
                id={`format-btn-${fmt}`}
                onClick={() => setFormat(fmt)}
                className={`px-2.5 py-1 rounded capitalize transition-all ${
                  format === fmt
                    ? 'bg-zinc-800 text-zinc-100 font-bold'
                    : 'text-zinc-400 hover:text-zinc-200'
                }`}
              >
                {fmt}
              </button>
            ))}
          </div>

          <button
            type="button"
            id="copy-rate-card-btn"
            onClick={handleCopy}
            className="px-3 py-1.5 rounded-lg bg-emerald-500 hover:bg-emerald-400 text-zinc-950 text-xs font-mono font-bold flex items-center gap-1.5 transition-colors shadow-sm"
          >
            {copied ? <Check className="w-3.5 h-3.5" /> : <Copy className="w-3.5 h-3.5" />}
            <span>{copied ? 'Copied' : 'Copy Snippet'}</span>
          </button>
        </div>
      </div>

      <pre className="p-3.5 bg-zinc-950 rounded-xl border border-zinc-800/80 text-xs font-mono text-zinc-300 overflow-x-auto selection:bg-emerald-900/50 max-h-56">
        <code>{generateContent()}</code>
      </pre>

    </div>
  );
};
