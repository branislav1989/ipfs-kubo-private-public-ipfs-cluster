import React, { useState } from 'react';
import { 
  Flame, 
  Trash2, 
  Clock, 
  ShieldAlert, 
  FileX2, 
  Terminal, 
  Check, 
  Copy, 
  Zap, 
  Lock, 
  Cpu, 
  Server, 
  Sparkles,
  AlertTriangle
} from 'lucide-react';

export const AutoShredGuide: React.FC = () => {
  const [copiedKey, setCopiedKey] = useState<string | null>(null);

  const copyToClipboard = (text: string, key: string) => {
    navigator.clipboard.writeText(text);
    setCopiedKey(key);
    setTimeout(() => setCopiedKey(null), 2000);
  };

  return (
    <div className="bg-zinc-900/80 border-2 border-red-500/40 rounded-2xl p-4 sm:p-6 lg:p-7 space-y-6 shadow-xl shadow-red-950/20 relative overflow-hidden">
      
      {/* Ambient background glow */}
      <div className="absolute top-0 right-0 -mr-16 -mt-16 w-80 h-80 bg-red-500/10 rounded-full blur-3xl pointer-events-none" />

      {/* Header */}
      <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4 pb-5 border-b border-zinc-800">
        <div className="space-y-1.5">
          <div className="flex items-center gap-2">
            <span className="px-2.5 py-0.5 rounded-full text-xs font-mono font-bold bg-red-500/20 text-red-300 border border-red-500/30 flex items-center gap-1.5">
              <Flame className="w-3.5 h-3.5" /> Automated Destruction & Shredding
            </span>
            <span className="text-xs text-zinc-400 font-mono">NIST SP 800-88 Compliant · Zero Forensics</span>
          </div>

          <h2 className="text-xl sm:text-2xl font-extrabold text-zinc-100 tracking-tight">
            How Expiration, <span className="text-red-400">Auto-Deletion & Cryptographic Shredding</span> Work
          </h2>

          <p className="text-xs sm:text-sm text-zinc-300 max-w-3xl leading-relaxed">
            <strong>Yes!</strong> When a single file drop session expires (after 30 or 60 days) or is downloaded in burn-on-read mode, the system <strong>automatically terminates the Tor daemon, unbinds the onion key, and physically shreds the file with cryptographic random overwrites</strong>.
          </p>
        </div>

        {/* Quick Badge */}
        <div className="bg-zinc-950 border border-red-900/40 rounded-xl p-3 text-xs font-mono flex-shrink-0 space-y-1">
          <span className="text-red-400 font-bold flex items-center gap-1">
            <ShieldAlert className="w-3.5 h-3.5" /> Forensic Recovery Impossible
          </span>
          <span className="text-[11px] text-zinc-400 block">
            Overwrites magnetic/flash sectors with 3-pass zeros & random noise.
          </span>
        </div>
      </div>

      {/* The 4-Stage Automated Shredding Pipeline */}
      <div className="grid grid-cols-1 md:grid-cols-4 gap-3.5">
        
        {/* Stage 1 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>TRIGGER 01</span>
            <Clock className="w-4 h-4 text-amber-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">Expiry Timer or Burn Trigger</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            Triggered automatically when the 30-day / 60-day timestamp hits in SQLite or immediately upon recipient download if <em>"Burn on Download"</em> was selected.
          </p>
        </div>

        {/* Stage 2 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>TRIGGER 02</span>
            <Cpu className="w-4 h-4 text-cyan-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">Kill OnionShare Daemon</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            The background daemon PID is sent <code className="text-red-300">SIGKILL</code>. The Tor v3 hidden service socket closes and descriptors expire from HSDir nodes.
          </p>
        </div>

        {/* Stage 3 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>TRIGGER 03</span>
            <Flame className="w-4 h-4 text-red-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">3-Pass Cryptographic Shred</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            Linux executes <code className="text-red-300 font-mono">shred -u -z -n 3</code> on the file and private key directory. Disk sectors are filled with random entropy + zeros.
          </p>
        </div>

        {/* Stage 4 */}
        <div className="bg-zinc-950/90 border border-zinc-800 rounded-xl p-4 space-y-2.5 relative">
          <div className="flex items-center justify-between text-zinc-500 text-[11px] font-mono">
            <span>TRIGGER 04</span>
            <FileX2 className="w-4 h-4 text-purple-400" />
          </div>
          <h3 className="text-xs font-bold font-mono text-zinc-100">SQLite Record Wipe</h3>
          <p className="text-[11px] text-zinc-400 leading-snug">
            The session row in the database is deleted or marked <code className="text-zinc-200">is_shredded = 1</code> and encrypted memory keys are cleared from RAM.
          </p>
        </div>

      </div>

      {/* The Difference: Standard Delete vs Cryptographic Shred */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-4 pt-1">
        
        {/* Bad Delete */}
        <div className="bg-zinc-950 border border-red-900/40 rounded-xl p-4 space-y-2.5">
          <div className="flex items-center gap-2 text-red-400 font-mono text-xs font-bold">
            <AlertTriangle className="w-4 h-4 text-red-400" />
            Why Normal <code className="text-red-300 bg-red-950/50 px-1 py-0.5 rounded">rm -f file</code> is DANGEROUS:
          </div>
          <p className="text-xs text-zinc-300 leading-relaxed">
            Standard Linux <code className="text-zinc-200">rm</code> only unlinks the file pointer in the filesystem table. The actual raw 1GB payload stays sitting on the physical NVMe/SSD drive and can be easily recovered with forensic tools like <em>TestDisk</em> or <em>Photorec</em>.
          </p>
        </div>

        {/* True Shred */}
        <div className="bg-zinc-950 border border-emerald-900/50 rounded-xl p-4 space-y-2.5">
          <div className="flex items-center gap-2 text-emerald-400 font-mono text-xs font-bold">
            <Sparkles className="w-4 h-4 text-emerald-400" />
            Why Linux <code className="text-emerald-300 bg-emerald-950/50 px-1 py-0.5 rounded">shred -u -z -n 3</code> is 100% SECURE:
          </div>
          <p className="text-xs text-zinc-300 leading-relaxed">
            <code className="text-emerald-300 font-mono">shred</code> writes 3 distinct passes of cryptographically secure pseudo-random bytes over the exact physical blocks of the file, overwrites with a final pass of zeros (<code className="text-emerald-300">-z</code>), and truncates/unlinks the inode (<code className="text-emerald-300">-u</code>). Even electron microscope lab recovery is impossible.
          </p>
        </div>

      </div>

      {/* Production Automation Scripts Ready-to-Copy */}
      <div className="space-y-4 pt-1">
        
        <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-4 space-y-3">
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-2">
              <Terminal className="w-4 h-4 text-red-400" />
              <h4 className="text-xs font-bold font-mono text-zinc-200 uppercase tracking-wider">
                Automated Python / Cron Expiry Daemon Script (<code className="text-zinc-400">clean_expired_drops.py</code>)
              </h4>
            </div>
            <button
              type="button"
              onClick={() => copyToClipboard(`#!/usr/bin/env python3
import sqlite3
import os
import subprocess
import time
from datetime import datetime

DB_PATH = "/dev/shm/drops.db"  # RAM disk SQLite database

def shred_and_purge_expired():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    
    # Query all expired drops that are not yet shredded
    now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    cursor.execute("""
        SELECT id, onionshare_pid, file_path, onion_slug 
        FROM drops 
        WHERE (expires_at <= ? OR payment_status = 'burned') 
        AND is_shredded = 0
    """, (now,))
    
    expired_drops = cursor.fetchall()
    
    for drop_id, pid, file_path, onion_slug in expired_drops:
        print(f"[SHRED-DAEMON] Expiring drop {drop_id}...")
        
        # 1. Kill the active OnionShare background daemon process
        if pid:
            try:
                subprocess.run(["kill", "-9", str(pid)], check=False)
            except Exception as e:
                print(f"Error killing PID {pid}: {e}")
                
        # 2. Perform 3-Pass Cryptographic Shredding on the file payload
        if file_path and os.path.exists(file_path):
            print(f"[SHRED-DAEMON] Cryptographically overwriting {file_path}...")
            # -n 3 = 3 random passes, -z = zero pass, -u = remove file
            subprocess.run(["shred", "-u", "-z", "-n", "3", file_path], check=True)
            
        # 3. Shred OnionShare private v3 service keys
        key_dir = f"/var/lib/onionshare/shares/{drop_id}"
        if os.path.exists(key_dir):
            for root, dirs, files in os.walk(key_dir):
                for f in files:
                    full_path = os.path.join(root, f)
                    subprocess.run(["shred", "-u", "-z", "-n", "3", full_path], check=False)
            subprocess.run(["rm", "-rf", key_dir], check=False)
            
        # 4. Mark record as completely destroyed in database
        cursor.execute("UPDATE drops SET is_shredded = 1, file_path = '[SHREDDED]' WHERE id = ?", (drop_id,))
        conn.commit()
        print(f"[SHRED-DAEMON] Drop {drop_id} destroyed permanently.")
        
    conn.close()

if __name__ == '__main__':
    shred_and_purge_expired()`, 'py_shred_script')}
              className="p-1 px-2.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300 hover:text-zinc-100 flex items-center gap-1.5 transition-colors"
            >
              {copiedKey === 'py_shred_script' ? <Check className="w-3.5 h-3.5 text-emerald-400" /> : <Copy className="w-3.5 h-3.5" />}
              {copiedKey === 'py_shred_script' ? 'Copied Script' : 'Copy Auto-Shred Script'}
            </button>
          </div>

          <pre className="p-3 bg-zinc-900 rounded-lg text-[11px] font-mono text-emerald-400/90 overflow-x-auto max-h-72">
{`#!/usr/bin/env python3
import sqlite3, os, subprocess
from datetime import datetime

DB_PATH = "/dev/shm/drops.db"  # RAM disk SQLite database

def shred_and_purge_expired():
    conn = sqlite3.connect(DB_PATH)
    cursor = conn.cursor()
    now = datetime.utcnow().strftime('%Y-%m-%d %H:%M:%S')
    
    cursor.execute("""
        SELECT id, onionshare_pid, file_path 
        FROM drops 
        WHERE expires_at <= ? AND is_shredded = 0
    """, (now,))
    
    for drop_id, pid, file_path in cursor.fetchall():
        # 1. Kill OnionShare Tor daemon process
        if pid: subprocess.run(["kill", "-9", str(pid)], check=False)
            
        # 2. Overwrite file with 3 passes of random data + 1 pass zeros
        if file_path and os.path.exists(file_path):
            subprocess.run(["shred", "-u", "-z", "-n", "3", file_path], check=True)
            
        # 3. Mark row as shredded
        cursor.execute("UPDATE drops SET is_shredded = 1 WHERE id = ?", (drop_id,))
        conn.commit()

if __name__ == '__main__':
    shred_and_purge_expired()`}
          </pre>
        </div>

        {/* Linux Cron Entry */}
        <div className="bg-zinc-950 border border-zinc-800 rounded-xl p-3.5 flex flex-col sm:flex-row sm:items-center justify-between gap-3 text-xs font-mono">
          <div>
            <span className="text-zinc-400 font-bold block">Add to Linux Cron (<code className="text-zinc-200">crontab -e</code>) to run every 10 minutes:</span>
            <code className="text-cyan-400 text-[11px] block mt-0.5">*/10 * * * * python3 /opt/onionshare-node/clean_expired_drops.py &gt;&gt; /var/log/shred.log 2&gt;&amp;1</code>
          </div>
          <button
            type="button"
            onClick={() => copyToClipboard('*/10 * * * * python3 /opt/onionshare-node/clean_expired_drops.py >> /var/log/shred.log 2>&1', 'cron_entry')}
            className="p-1 px-2.5 rounded bg-zinc-800 text-[11px] font-mono text-zinc-300 hover:text-zinc-100 flex items-center gap-1.5 self-start sm:self-auto flex-shrink-0"
          >
            {copiedKey === 'cron_entry' ? <Check className="w-3 h-3 text-emerald-400" /> : <Copy className="w-3 h-3" />}
            {copiedKey === 'cron_entry' ? 'Copied' : 'Copy Cron'}
          </button>
        </div>

      </div>

    </div>
  );
};
