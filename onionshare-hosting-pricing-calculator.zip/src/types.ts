export type Currency = 'USD' | 'EUR' | 'XMR' | 'BTC';

export type Language = 'en' | 'ru' | 'de' | 'zh' | 'fr' | 'es' | 'pt';

export type PricingModelMode = 'retail_one_time' | 'wholesale_linear' | 'hybrid_deposit';

export interface CurrencyRate {
  symbol: string;
  code: Currency;
  rateToUSD: number; // 1 USD = X Currency
  decimals: number;
  prefix?: string;
  suffix?: string;
}

export type AccessTier = 'public' | 'private';

export interface ServerConfig {
  vpsMonthlyCostUSD: number; // e.g. $25/mo
  totalStorageGB: number; // e.g. 500 GB
  totalBandwidthTB: number; // e.g. 5 TB
  ramGB: number; // e.g. 8 GB
  profitMarginPercent: number; // e.g. 100% (2x cost)
  paymentFeePercent: number; // e.g. 5%
  privateOverheadMultiplier: number; // e.g. 2.5x for private daemon & RAM isolation
  bandwidthMultiplier: number; // e.g. 3x egress per GB
  minimumOrderFeeUSD: number; // Base transaction floor for one-off crypto orders (e.g. $3.50 - $5.00)
}

export interface PricingResult {
  baseStorageCostUSD: number;
  bandwidthCostUSD: number;
  daemonComputeCostUSD: number;
  cryptoFrictionCostUSD: number;
  totalCostUSD: number;
  profitUSD: number;
  recommendedPriceUSD: number;
  unitPricePerGbMonthUSD: number;
  retailPriceWithFloorUSD: number;
}

export interface DirectAnswerScenario {
  id: string;
  label: string;
  sizeGb: number;
  durationMonths: number;
  tier: AccessTier;
  recommendedUSD: number;
  recommendedRangeUSD: [number, number];
  recommendedXMR: number;
  recommendedBTC: number;
  keyFeature: string;
  bandwidthProfile: string;
}

