import { ServerConfig, AccessTier, PricingResult, Currency } from '../types';
import { CURRENCY_RATES } from '../data/benchmarks';

export function calculatePrice(
  sizeGB: number,
  durationMonths: number,
  tier: AccessTier,
  config: ServerConfig
): PricingResult {
  // 1. Raw Storage Cost per GB-Month:
  // Base raw disk cost from VPS
  const baseDiskCostPerGbMonth = config.vpsMonthlyCostUSD / Math.max(config.totalStorageGB, 1);
  const baseStorageCostUSD = baseDiskCostPerGbMonth * sizeGB * durationMonths;

  // 2. Tor Bandwidth & Relay Cost:
  // Egress bandwidth on Tor has packet overhead (cell padding, 6 hops, intro/rendezvous handshake).
  // Public links typically experience 3x-8x download volume from crawlers/multiple recipients.
  // Private links typically experience 1.2x-2x download volume.
  const tierBandwidthFactor = tier === 'public' ? config.bandwidthMultiplier : Math.max(1.2, config.bandwidthMultiplier * 0.45);
  const totalEgressGB = sizeGB * tierBandwidthFactor * (1 + (durationMonths - 1) * 0.4);
  const bandwidthCostPerGB = (config.vpsMonthlyCostUSD * 0.35) / Math.max(config.totalBandwidthTB * 1000, 100);
  const bandwidthCostUSD = totalEgressGB * Math.max(bandwidthCostPerGB, 0.003) * 3; // buffer for Tor circuit overhead

  // 3. Tor Hidden Service Daemon & RAM Compute Overhead:
  // OnionShare creates an isolated ephemeral Python/stem process and Tor hidden service socket.
  // Private services require client auth key management, individual v3 stealth descriptors, and dedicated RAM.
  const ramPerShareMB = tier === 'private' ? 95 : 40;
  const ramCostPerMonth = (ramPerShareMB / (config.ramGB * 1024)) * (config.vpsMonthlyCostUSD * 0.45);
  const computeMultiplier = tier === 'private' ? config.privateOverheadMultiplier : 1.0;
  const daemonComputeCostUSD = ramCostPerMonth * durationMonths * computeMultiplier;

  // 4. Cryptographic Lifecycle & Secure Wipe Overhead:
  // Disk wear and CPU shredding (shred -u -z -n 3 or LUKS key destruction), systemd monitoring
  const secureWipeMaintenanceUSD = 0.02 * sizeGB * (tier === 'private' ? 1.5 : 1.0);

  // Subtotal base operational cost:
  const subtotalCostUSD = baseStorageCostUSD + bandwidthCostUSD + daemonComputeCostUSD + secureWipeMaintenanceUSD;

  // 5. Crypto Payment Swapping & Network Fee buffer (XMR / BTC transaction friction):
  const cryptoFrictionCostUSD = subtotalCostUSD * (config.paymentFeePercent / 100);

  const totalCostUSD = subtotalCostUSD + cryptoFrictionCostUSD;

  // 6. Profit Margin:
  // Multi-month duration has a minor bulk retention discount (e.g. 10% for 2 months)
  const durationDiscount = durationMonths > 1 ? Math.min(0.20, (durationMonths - 1) * 0.10) : 0;
  const effectiveMargin = (config.profitMarginPercent / 100) * (1 - durationDiscount);
  
  const profitUSD = totalCostUSD * effectiveMargin;
  const recommendedPriceUSD = totalCostUSD + profitUSD;

  // Single-Drop Session Pricing Formula (Per single file drop checkout):
  // User fixed single-drop rates:
  // 1 GB / 1 Month Public = 3.50 EUR (~$3.80 USD)
  // 1 GB / 1 Month Private = 5.00 EUR (~$5.43 USD)
  // 1 GB / 2 Month Public = 5.00 EUR (~$5.43 USD)
  // 1 GB / 2 Month Private = 7.00 EUR (~$7.61 USD)
  const eurRateToUSD = 1 / (CURRENCY_RATES.EUR?.rateToUSD || 0.92); // ~1.087
  let fixedBaseDropEUR = 0;
  if (sizeGB === 1 && durationMonths === 1) {
    fixedBaseDropEUR = tier === 'public' ? 3.50 : 5.00;
  } else if (sizeGB === 1 && durationMonths === 2) {
    fixedBaseDropEUR = tier === 'public' ? 5.00 : 7.00;
  } else {
    // Scaled formula for custom GB sessions:
    const baseDropEUR = tier === 'public' ? 3.50 : 5.00;
    const extraMonths = durationMonths - 1;
    const durationMultiplier = 1 + extraMonths * (tier === 'public' ? 0.43 : 0.40);
    const extraGbCostEUR = (sizeGB - 1) * (tier === 'public' ? 0.60 : 1.50) * durationMonths;
    fixedBaseDropEUR = (baseDropEUR * durationMultiplier) + Math.max(0, extraGbCostEUR);
  }

  const retailPriceWithFloorUSD = fixedBaseDropEUR * eurRateToUSD;
  const unitPricePerGbMonthUSD = recommendedPriceUSD / (sizeGB * durationMonths);

  return {
    baseStorageCostUSD,
    bandwidthCostUSD,
    daemonComputeCostUSD: daemonComputeCostUSD + secureWipeMaintenanceUSD,
    cryptoFrictionCostUSD,
    totalCostUSD,
    profitUSD,
    recommendedPriceUSD,
    unitPricePerGbMonthUSD,
    retailPriceWithFloorUSD,
  };
}

export function formatCurrency(amountUSD: number, currency: Currency): string {
  const meta = CURRENCY_RATES[currency] || CURRENCY_RATES.USD;
  const converted = amountUSD * meta.rateToUSD;

  if (currency === 'BTC') {
    if (converted < 0.0001) {
      const sats = Math.round(converted * 100_000_000);
      return `${sats.toLocaleString()} sats`;
    }
    return `₿${converted.toFixed(6)}`;
  }

  if (currency === 'XMR') {
    return `${converted.toFixed(4)} XMR`;
  }

  if (currency === 'EUR') {
    return `€${converted.toFixed(2)}`;
  }

  return `$${converted.toFixed(2)}`;
}

export function formatUnitRate(amountUSD: number, currency: Currency): string {
  return `${formatCurrency(amountUSD, currency)} / GB·mo`;
}
