/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState } from 'react';
import { Currency, ServerConfig, AccessTier, Language } from './types';
import { DEFAULT_SERVER_CONFIGS } from './data/benchmarks';
import { CustomerStorefrontHero } from './components/CustomerStorefrontHero';
import { Header } from './components/Header';
import { QuickAnswerCards } from './components/QuickAnswerCards';
import { PricingRealityCheck } from './components/PricingRealityCheck';
import { SingleDropWorkflow } from './components/SingleDropWorkflow';
import { BackendInfraGuide } from './components/BackendInfraGuide';
import { AutoShredGuide } from './components/AutoShredGuide';
import { PaymentUploadWorkflowGuide } from './components/PaymentUploadWorkflowGuide';
import { CaddyAndBootGuide } from './components/CaddyAndBootGuide';
import { OsDeploymentGuide } from './components/OsDeploymentGuide';
import { Calculator } from './components/Calculator';
import { UnitEconomicsBreakdown } from './components/UnitEconomicsBreakdown';
import { PublicVsPrivateGuide } from './components/PublicVsPrivateGuide';
import { TorArchitectureSpecs } from './components/TorArchitectureSpecs';
import { RateCardExporter } from './components/RateCardExporter';
import { Shield, Sparkles, AlertCircle, Info, ExternalLink, Terminal, LayoutDashboard, BookOpen, Layers, Download, CheckCircle2 } from 'lucide-react';

export default function App() {
  const [selectedCurrency, setSelectedCurrency] = useState<Currency>('EUR');
  const [currentLang, setCurrentLang] = useState<Language>('en');
  const [activePresetKey, setActivePresetKey] = useState<string>('offshore_bulletproof');
  const [serverConfig, setServerConfig] = useState<ServerConfig>(
    DEFAULT_SERVER_CONFIGS.offshore_bulletproof.config
  );
  const [pricingMode, setPricingMode] = useState<'unit_cost' | 'retail_floor'>('retail_floor');
  const [viewMode, setViewMode] = useState<'storefront' | 'operator_docs'>('storefront');

  // Interactive calculator state
  const [storageGB, setStorageGB] = useState<number>(1);
  const [durationMonths, setDurationMonths] = useState<number>(1);
  const [accessTier, setAccessTier] = useState<AccessTier>('private');

  const handlePresetChange = (presetKey: string) => {
    setActivePresetKey(presetKey);
    if (DEFAULT_SERVER_CONFIGS[presetKey]) {
      setServerConfig(DEFAULT_SERVER_CONFIGS[presetKey].config);
    }
  };

  const handleUpdateServerConfig = (newConfig: Partial<ServerConfig>) => {
    setServerConfig((prev) => ({ ...prev, ...newConfig }));
  };

  const handleSelectScenarioForDetail = (sizeGB: number, months: number, tier: AccessTier) => {
    setStorageGB(sizeGB);
    setDurationMonths(months);
    setAccessTier(tier);
    // Scroll smoothly to calculator section
    const calcEl = document.getElementById('custom-calculator-section');
    if (calcEl) {
      calcEl.scrollIntoView({ behavior: 'smooth' });
    }
  };

  return (
    <div className="min-h-screen bg-zinc-950 text-zinc-100 flex flex-col selection:bg-emerald-500/30 selection:text-emerald-300">
      
      {/* Top Navigation / App Header */}
      <Header
        selectedCurrency={selectedCurrency}
        onCurrencyChange={setSelectedCurrency}
        activePresetKey={activePresetKey}
        onPresetChange={handlePresetChange}
        currentLang={currentLang}
        onLanguageChange={setCurrentLang}
      />

      {/* Main Container */}
      <main className="flex-1 max-w-7xl w-full mx-auto px-4 sm:px-6 lg:px-8 py-6 sm:py-8 space-y-8 sm:space-y-10">
        
        {/* VIEW MODE SWITCHER (Top Navigation between Customer Storefront and Sysadmin Docs) */}
        <div className="flex flex-col sm:flex-row items-center justify-between gap-3 bg-zinc-900/90 border border-zinc-800 p-2 sm:p-2.5 rounded-2xl">
          <div className="flex items-center gap-2">
            <span className="w-2 h-2 rounded-full bg-emerald-400 animate-pulse"></span>
            <span className="text-xs font-mono text-zinc-400 font-semibold">Active View Mode:</span>
          </div>

          <div className="flex items-center gap-1.5 bg-zinc-950 p-1 rounded-xl border border-zinc-800/80 w-full sm:w-auto">
            <button
              type="button"
              id="view-storefront-btn"
              onClick={() => setViewMode('storefront')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
                viewMode === 'storefront'
                  ? 'bg-amber-400 text-zinc-950 shadow-md shadow-amber-400/20'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <LayoutDashboard className="w-3.5 h-3.5" />
              <span>Customer Storefront (4 Big Plans)</span>
            </button>
            <button
              type="button"
              id="view-docs-btn"
              onClick={() => setViewMode('operator_docs')}
              className={`flex-1 sm:flex-initial px-4 py-2 rounded-lg text-xs font-mono font-bold transition-all flex items-center justify-center gap-2 ${
                viewMode === 'operator_docs'
                  ? 'bg-emerald-500 text-zinc-950 shadow-md shadow-emerald-500/20'
                  : 'text-zinc-400 hover:text-zinc-200'
              }`}
            >
              <BookOpen className="w-3.5 h-3.5" />
              <span>Sysadmin & Architecture Docs</span>
            </button>
          </div>
        </div>

        {/* 1. CUSTOMER STOREFRONT: 4 PRICING PLANS IN BIG FONTS + BITCOIN CHECKOUT */}
        <section id="customer-storefront-section">
          <CustomerStorefrontHero 
            selectedCurrency={selectedCurrency} 
            currentLang={currentLang}
            onLanguageChange={setCurrentLang}
          />
        </section>

        {/* 1-CLICK DIRECT PROJECT DOWNLOAD (No SSH, No Git, No GitHub) */}
        <div className="p-4 sm:p-5 bg-gradient-to-r from-emerald-950/40 via-zinc-900/80 to-zinc-900 border-2 border-emerald-500/50 rounded-2xl flex flex-col lg:flex-row items-center justify-between gap-4 font-mono text-xs shadow-lg shadow-emerald-950/20">
          <div className="space-y-1 text-center lg:text-left">
            <div className="flex items-center justify-center lg:justify-start gap-2">
              <span className="px-2 py-0.5 rounded bg-emerald-500/20 text-emerald-300 font-bold border border-emerald-500/40 flex items-center gap-1">
                <CheckCircle2 className="w-3.5 h-3.5 text-emerald-400" /> Ready to Deploy
              </span>
              <span className="text-zinc-400 font-bold">1-Click Direct Download (No SSH &amp; No GitHub Required)</span>
            </div>
            <p className="text-zinc-300 text-xs">
              Download the complete, self-contained project archive directly to your computer. Unpack and run on any machine or server with zero command-line headaches.
            </p>
          </div>

          <div className="flex flex-wrap items-center gap-2.5 flex-shrink-0">
            <a
              href="/onionshield-deploy.zip"
              download="onionshield-deploy.zip"
              className="px-4 py-2.5 bg-emerald-500 hover:bg-emerald-400 text-zinc-950 rounded-xl font-bold transition-all flex items-center gap-2 shadow-md hover:scale-[1.02] active:scale-[0.98]"
            >
              <Download className="w-4 h-4" />
              <span>Download ZIP (.zip)</span>
            </a>
            <a
              href="/onionshield-deploy.tar.gz"
              download="onionshield-deploy.tar.gz"
              className="px-3.5 py-2.5 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 border border-zinc-700 rounded-xl font-bold transition-all flex items-center gap-2"
            >
              <Download className="w-4 h-4 text-zinc-400" />
              <span>Linux Archive (.tar.gz)</span>
            </a>
          </div>
        </div>

        {/* IF IN STOREFRONT MODE: Provide an invitation card to inspect backend technical specs */}
        {viewMode === 'storefront' && (
          <div className="p-4 sm:p-5 bg-zinc-900/50 border border-zinc-800 rounded-xl flex flex-col sm:flex-row items-center justify-between gap-4 font-mono text-xs">
            <div className="space-y-1 text-center sm:text-left">
              <span className="text-zinc-300 font-bold flex items-center justify-center sm:justify-start gap-2">
                <Terminal className="w-4 h-4 text-emerald-400" />
                Server Operator & Sysadmin Architecture Tools
              </span>
              <p className="text-zinc-500">
                Want to view Bitcoin payment automation, SQLite schema, RAM stream encryption, or ZFS backup guides?
              </p>
            </div>
            <button
              type="button"
              onClick={() => setViewMode('operator_docs')}
              className="px-4 py-2 bg-zinc-800 hover:bg-zinc-700 text-zinc-200 rounded-lg font-bold transition-all flex items-center gap-2 flex-shrink-0"
            >
              <span>View Sysadmin Manual</span>
              <BookOpen className="w-3.5 h-3.5 text-emerald-400" />
            </button>
          </div>
        )}

        {/* 2. DETAILED SYSADMIN & ARCHITECTURE GUIDES (Only visible when requested or in docs view) */}
        {viewMode === 'operator_docs' && (
          <div className="space-y-8 sm:space-y-10 pt-4 border-t border-zinc-800">
            
            <div className="flex items-center justify-between pb-2">
              <div>
                <h2 className="text-xl font-bold font-mono text-zinc-100 flex items-center gap-2">
                  <BookOpen className="w-5 h-5 text-emerald-400" />
                  System Architecture & Technical Manuals
                </h2>
                <p className="text-xs font-mono text-zinc-400">
                  Internal unit costs, Wasabi gap limit mitigation, SQLite sync, and shredding daemons.
                </p>
              </div>
              <button
                type="button"
                onClick={() => setViewMode('storefront')}
                className="text-xs font-mono text-amber-400 hover:underline flex items-center gap-1"
              >
                &larr; Back to Simple Customer Storefront
              </button>
            </div>

            {/* Direct Answers Section (1GB 1-Mo & 2-Mo Public/Private) */}
            <section id="direct-answers-section">
              <QuickAnswerCards
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
                pricingMode={pricingMode}
                setPricingMode={setPricingMode}
                onSelectScenarioForDetail={handleSelectScenarioForDetail}
              />
            </section>

            {/* Reality Check: ChatGPT (€5/€7) vs Unit Economics Breakdown */}
            <section id="pricing-reality-check-section">
              <PricingRealityCheck
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
              />
            </section>

            {/* Option A Deep Dive: Single File Drop Session Lifecycle & Profit Calculator */}
            <section id="single-drop-workflow-section">
              <SingleDropWorkflow
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
              />
            </section>

            {/* Backend Architecture: SQLite & BTC/XMR Node Analysis */}
            <section id="backend-infra-guide-section">
              <BackendInfraGuide />
            </section>

            {/* Upload-First & Payment Synchronization Engine (Keep Paid vs Refuse/Shred Unpaid) */}
            <section id="payment-upload-workflow-section">
              <PaymentUploadWorkflowGuide />
            </section>

            {/* Caddy Reverse Proxy, Systemd Auto-Boot & Customer SHA-256 Hashes */}
            <section id="caddy-boot-guide-section">
              <CaddyAndBootGuide />
            </section>

            {/* Auto-Deletion & Cryptographic Shredding Architecture */}
            <section id="auto-shred-guide-section">
              <AutoShredGuide />
            </section>

            {/* OS Deployment: Tails OS vs Immutable OS vs BTCPay Alternatives */}
            <section id="os-deployment-guide-section">
              <OsDeploymentGuide />
            </section>

            {/* Custom Calculator & Live Estimator Section */}
            <section id="custom-calculator-section" className="scroll-mt-20">
              <Calculator
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
                onUpdateServerConfig={handleUpdateServerConfig}
                storageGB={storageGB}
                setStorageGB={setStorageGB}
                durationMonths={durationMonths}
                setDurationMonths={setDurationMonths}
                accessTier={accessTier}
                setAccessTier={setAccessTier}
              />
            </section>

            {/* Unit Economics Breakdown Visualizer */}
            <section id="unit-economics-section">
              <UnitEconomicsBreakdown
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
                storageGB={storageGB}
                durationMonths={durationMonths}
                accessTier={accessTier}
              />
            </section>

            {/* Public vs Private Technical Architecture Guide */}
            <section id="architecture-guide-section">
              <PublicVsPrivateGuide />
            </section>

            {/* Tor OS & Headless OnionShare CLI Node Deployment */}
            <section id="tor-specs-section">
              <TorArchitectureSpecs />
            </section>

            {/* Exportable Storefront Rate Card */}
            <section id="export-ratecard-section">
              <RateCardExporter
                selectedCurrency={selectedCurrency}
                serverConfig={serverConfig}
              />
            </section>
          </div>
        )}

      </main>

      {/* Footer */}
      <footer className="border-t border-zinc-800/80 bg-zinc-950 py-6 mt-12 text-xs text-zinc-500 font-mono">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex flex-col sm:flex-row items-center justify-between gap-4">
          <div className="flex items-center gap-2">
            <Shield className="w-4 h-4 text-emerald-400" />
            <span>OnionShare Tor Storage Economic Modeler · v3 Stealth Ready</span>
          </div>
          <p className="text-zinc-500 text-center sm:text-right">
            Always configure encrypted swap and LUKS partitions when hosting anonymous hidden services.
          </p>
        </div>
      </footer>

    </div>
  );
}
