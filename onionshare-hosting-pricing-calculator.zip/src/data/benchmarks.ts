import { CurrencyRate, ServerConfig, DirectAnswerScenario } from '../types';

export const CURRENCY_RATES: Record<string, CurrencyRate> = {
  USD: { symbol: '$', code: 'USD', rateToUSD: 1.0, decimals: 2, prefix: '$' },
  EUR: { symbol: '€', code: 'EUR', rateToUSD: 0.92, decimals: 2, prefix: '€' },
  XMR: { symbol: 'ɱ', code: 'XMR', rateToUSD: 0.0062, decimals: 4, prefix: 'XMR ', suffix: ' XMR' }, // ~$160/XMR
  BTC: { symbol: '₿', code: 'BTC', rateToUSD: 0.000015, decimals: 6, prefix: '₿', suffix: ' BTC' }, // ~$65k/BTC
};

export const DEFAULT_SERVER_CONFIGS: Record<string, { name: string; description: string; config: ServerConfig }> = {
  offshore_bulletproof: {
    name: 'Offshore Privacy VPS (Recommended)',
    description: 'DMCA-ignored / Offshore VPS (Iceland / Switzerland / Luxembourg) with encrypted NVMe storage and anonymous crypto billing.',
    config: {
      vpsMonthlyCostUSD: 28,
      totalStorageGB: 500,
      totalBandwidthTB: 4,
      ramGB: 8,
      profitMarginPercent: 120,
      paymentFeePercent: 6,
      privateOverheadMultiplier: 2.8,
      bandwidthMultiplier: 3.5,
      minimumOrderFeeUSD: 4.50,
    },
  },
  budget_vps: {
    name: 'Budget / Low-End Tor Node',
    description: 'Low-cost European VPS with standard SSD, suitable for hobbyist or low-overhead personal Tor OnionShare relay.',
    config: {
      vpsMonthlyCostUSD: 12,
      totalStorageGB: 250,
      totalBandwidthTB: 2,
      ramGB: 4,
      profitMarginPercent: 80,
      paymentFeePercent: 5,
      privateOverheadMultiplier: 2.2,
      bandwidthMultiplier: 2.5,
      minimumOrderFeeUSD: 3.00,
    },
  },
  dedicated_luks: {
    name: 'High-Sec Dedicated LUKS Server',
    description: 'Dedicated bare-metal server with full-disk LUKS encryption, RAM-disk scratch space, and isolated ephemeral Tor daemons.',
    config: {
      vpsMonthlyCostUSD: 65,
      totalStorageGB: 1000,
      totalBandwidthTB: 10,
      ramGB: 32,
      profitMarginPercent: 150,
      paymentFeePercent: 7,
      privateOverheadMultiplier: 3.2,
      bandwidthMultiplier: 4.5,
      minimumOrderFeeUSD: 6.00,
    },
  },
};

export const CORE_ANSWER_SCENARIOS: DirectAnswerScenario[] = [
  {
    id: '1gb-1m-public',
    label: '1 GB / 1 Month — Public Link',
    sizeGb: 1,
    durationMonths: 1,
    tier: 'public',
    recommendedUSD: 3.80, // 3.50 EUR
    recommendedRangeUSD: [3.50, 4.00],
    recommendedXMR: 0.0217,
    recommendedBTC: 0.0000538,
    keyFeature: 'Open .onion slug + optional password, auto-wipe on day 30',
    bandwidthProfile: 'Ephemeral Tor v3 circuit + standard public descriptor',
  },
  {
    id: '1gb-1m-private',
    label: '1 GB / 1 Month — Private (Client-Auth)',
    sizeGb: 1,
    durationMonths: 1,
    tier: 'private',
    recommendedUSD: 5.43, // 5.00 EUR
    recommendedRangeUSD: [5.00, 5.50],
    recommendedXMR: 0.0310,
    recommendedBTC: 0.0000769,
    keyFeature: 'v3 Client Authorization (x25519 stealth key), isolated daemon RAM pool',
    bandwidthProfile: 'Strict 1:1 single-recipient delivery, zero public scraping',
  },
  {
    id: '1gb-2m-public',
    label: '1 GB / 2 Months — Public Link',
    sizeGb: 1,
    durationMonths: 2,
    tier: 'public',
    recommendedUSD: 5.43, // 5.00 EUR
    recommendedRangeUSD: [5.00, 5.50],
    recommendedXMR: 0.0310,
    recommendedBTC: 0.0000769,
    keyFeature: '60-day auto-shred retention, persistent HSDir descriptor re-publishing',
    bandwidthProfile: 'Extended 60-day availability for slow asynchronous receipt',
  },
  {
    id: '1gb-2m-private',
    label: '1 GB / 2 Months — Private (Client-Auth)',
    sizeGb: 1,
    durationMonths: 2,
    tier: 'private',
    recommendedUSD: 7.61, // 7.00 EUR
    recommendedRangeUSD: [7.00, 8.00],
    recommendedXMR: 0.0434,
    recommendedBTC: 0.0001077,
    keyFeature: '60-day isolated socket reservation + dedicated keypair auth lifecycle',
    bandwidthProfile: 'Maximum whistleblower security with 60-day stealth retention',
  },
];

export const MARKET_BENCHMARKS = [
  {
    provider: 'ChatGPT Suggested Rate (Retail Per-Drop Model)',
    model: '1 GB / 1 mo (€5) & 2 mo (€7)',
    rateUSD: '€5.00 – €7.00 ($5.40 – $7.60)',
    category: 'Retail Floor',
    badgeColor: 'text-amber-400 bg-amber-500/10 border-amber-500/30',
    notes: 'Assumes high minimum transaction floor to cover single crypto checkout fees + operator risk markup.',
  },
  {
    provider: 'Pure Unit Economics (Our Marginal Model)',
    model: '1 GB / 1 mo (€0.55 Public / €1.65 Private)',
    rateUSD: '€0.55 – €2.90 ($0.60 – $3.20)',
    category: 'Unit Cost-Plus',
    badgeColor: 'text-emerald-400 bg-emerald-500/10 border-emerald-500/30',
    notes: 'Actual marginal server cost + 120% margin. Highly competitive for multi-GB plans or prepaid wallet balances.',
  },
  {
    provider: 'Darknet / Tor File Drops (e.g. AnonFiles .onion, Drop.onion)',
    model: '1 GB / 1-30 days',
    rateUSD: '$2.00 - $5.00 flat ticket',
    category: 'Tor Niche',
    badgeColor: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/30',
    notes: 'Usually charge flat minimum entry ticket ($3-$5) regardless if user uploads 100MB or 2GB due to crypto processing minimums.',
  },
  {
    provider: 'Anonymous Offshore Hosting (Njalla, 1984, Cockbox)',
    model: 'Raw Offshore VPS Storage',
    rateUSD: '$0.05 - $0.15 / GB',
    category: 'Raw VPS',
    badgeColor: 'text-purple-400 bg-purple-500/10 border-purple-500/30',
    notes: 'Raw unmanaged storage before OnionShare Python daemon RAM, continuous v3 descriptor rotation, and automated wiping overhead.',
  },
  {
    provider: 'Clearweb Zero-Knowledge Cloud (Proton / Mega / Tresorit)',
    model: 'Clearweb Cloud Storage',
    rateUSD: '$0.04 - $0.10 / GB',
    category: 'Clearweb CDN',
    badgeColor: 'text-zinc-400 bg-zinc-800 border-zinc-700',
    notes: 'Uses centralized CDNs and credit cards. Completely different security model (no Tor 6-hop routing or hidden service daemons).',
  },
];
