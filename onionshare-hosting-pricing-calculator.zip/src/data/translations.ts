import { Language } from '../types';

export interface TranslationDict {
  appName: string;
  tagline: string;
  torVaultBadge: string;
  headerSubtitle: string;
  langName: string;
  
  // Storefront
  heroBadge: string;
  heroHeadline: string;
  heroSubheadline: string;
  ratesPer1Gb: string;
  mostPopular: string;
  maxPrivacy: string;
  activePlan: string;
  selectPlan: string;
  daysDuration: string;
  per1Gb: string;
  satsPerGb: string;

  // Step 2 & Controls
  step2Header: string;
  step2Title: string;
  ramSafetyBadge: string;
  ramSafetyDesc: string;
  settingsTitle: string;
  retentionTitle: string;
  retention30d: string;
  retention30dDesc: string;
  retention60d: string;
  retention60dDesc: string;
  privacyTitle: string;
  privacyPublic: string;
  privacyPublicDesc: string;
  privacyPrivate: string;
  privacyPrivateDesc: string;
  activeSelectionSummary: string;

  // File Upload & Presets
  fileSizeTitle: string;
  dropZoneTitle: string;
  dropZoneDesc: string;
  uploadBtnText: string;
  customSize: string;

  // 7-Zip & Bitcoin Filename recommendation
  sevenZipNoticeTitle: string;
  sevenZipNoticeBadge: string;
  sevenZipNoticeText: string;
  sevenZipPassphraseTip: string;
  sevenZipFilenameTip: string;
  sevenZipNotMandatory: string;

  // Obfs4 Bridge Notice
  obfs4Title: string;
  obfs4Badge: string;
  obfs4Desc: string;
  obfs4HowTo: string;

  // Upload progress & Invoice
  uploadingText: string;
  uploadingSubtext: string;
  invoiceCompleteTitle: string;
  paymentCountdown: string;
  scanWithWallet: string;
  singleUseAddress: string;
  daemonListening: string;
  simulatePayBtn: string;

  // Post-payment success
  paymentConfirmedTitle: string;
  ramPurgedTitle: string;
  ramPurgedDesc: string;
  downloadLinkTitle: string;
  stealthKeyTitle: string;
  autoShredDate: string;
  copyBtn: string;
  copiedBtn: string;
  startAnotherDrop: string;
}

export const TRANSLATIONS: Record<Language, TranslationDict> = {
  en: {
    appName: 'OnionShieldOasis',
    tagline: 'Tor Hidden Storage Vault',
    torVaultBadge: 'Tor v3 Vault',
    headerSubtitle: 'Secure Tor File Drop & Storage Vault · Per-GB Bitcoin Billing',
    langName: 'English',

    heroBadge: 'PAY PER GB · CHOOSE RETENTION & PRIVACY · 100% BITCOIN',
    heroHeadline: 'Select Your Plan · Rates Per 1 GB',
    heroSubheadline: 'Upload any file size (500 MB, 2 GB, 10 GB+). Choose between 30 Days or 60 Days retention, and Public or Stealth Private encryption. Once paid, the server accepts the file and closes the staging session immediately to save RAM.',
    ratesPer1Gb: 'Rates Per 1 GB',
    mostPopular: 'MOST POPULAR',
    maxPrivacy: 'MAX PRIVACY',
    activePlan: 'Active Plan',
    selectPlan: 'Select Plan',
    daysDuration: 'Days',
    per1Gb: '/ 1 GB',
    satsPerGb: 'sats / GB',

    step2Header: 'Step 2: Choose Options, Upload File → Receive Bitcoin Invoice',
    step2Title: 'Active Selection',
    ramSafetyBadge: 'RAM Safety',
    ramSafetyDesc: 'Auto-Purge Session on Pay',
    settingsTitle: 'File Retention & Privacy Settings (Customize Your Drop):',
    retentionTitle: '1. Retention Duration:',
    retention30d: '30 Days',
    retention30dDesc: '1 Month Storage',
    retention60d: '60 Days',
    retention60dDesc: '2 Months Extended',
    privacyTitle: '2. Privacy & Access Tier:',
    privacyPublic: 'Public Onion',
    privacyPublicDesc: 'Open URL + Password',
    privacyPrivate: 'Stealth Private',
    privacyPrivateDesc: 'x25519 Keypair Auth',
    activeSelectionSummary: 'Selected',

    fileSizeTitle: '3. Select or Enter File Size to Upload (No 1 GB Limit):',
    dropZoneTitle: 'Drop Any File Here or Click to Select',
    dropZoneDesc: 'Configured for',
    uploadBtnText: 'Upload & Generate Invoice',
    customSize: 'Custom',

    sevenZipNoticeTitle: 'Client-Side Encryption Best Practice (7-Zip / AES-256):',
    sevenZipNoticeBadge: 'Zero-Knowledge Privacy',
    sevenZipNoticeText: 'For maximum opsec before uploading, compress your archive using 7-Zip with AES-256 encryption and a strong secret passphrase.',
    sevenZipPassphraseTip: 'Lock archive header so filenames are encrypted inside the .7z container.',
    sevenZipFilenameTip: 'Optional: rename the upload file to look like a Bitcoin address or random hash (e.g. bc1q7x9...7z) to eliminate descriptive metadata.',
    sevenZipNotMandatory: 'Note: 7-Zip encryption and BTC-style naming are highly recommended, but NOT mandatory.',

    obfs4Title: 'Tor obfs4 Bridge Support (Bypass ISP / Nation-State Blocking):',
    obfs4Badge: 'Censorship Circumvention',
    obfs4Desc: 'If your ISP or local firewall blocks Tor connections (China, Russia, Iran, Kazakhstan), enable built-in obfs4 bridges in your Tor Browser.',
    obfs4HowTo: 'Tor Browser Menu → Settings → Connection → Bridges → "Select a built-in bridge" → Choose "obfs4". OnionShieldOasis supports all obfs4 circuit handshakes seamlessly.',

    uploadingText: 'Streaming Chunks into Staging...',
    uploadingSubtext: 'Hashing chunks on the fly · Resumable Tor circuits · RAM buffered safely',
    invoiceCompleteTitle: 'Upload complete',
    paymentCountdown: '14:59 Payment Window Before Auto-Shred',
    scanWithWallet: 'Scan with Wasabi / Sparrow',
    singleUseAddress: 'Your Single-Use Wasabi SegWit Address (bc1q):',
    daemonListening: 'Daemon listening via Tor mempool.space .onion mirror...',
    simulatePayBtn: '[Simulate Payment Received → Auto-Close Session]',

    paymentConfirmedTitle: 'Payment Confirmed · File Drop Accepted!',
    ramPurgedTitle: 'Individual Staging Session Closed & RAM Memory Purged:',
    ramPurgedDesc: 'The file has been accepted into the encrypted vault. Staging buffers, upload sockets, and memory handles have been immediately closed and garbage-collected to preserve server performance.',
    downloadLinkTitle: 'Your Tor v3 Download Link:',
    stealthKeyTitle: 'Generated Client-Auth Key (Pass to Recipient Only):',
    autoShredDate: 'Auto-shred date:',
    copyBtn: 'Copy Link',
    copiedBtn: 'Copied Link',
    startAnotherDrop: 'Start another drop session',
  },

  ru: {
    appName: 'OnionShieldOasis',
    tagline: 'Скрытое Tor-хранилище файлов',
    torVaultBadge: 'Tor v3 Убежище',
    headerSubtitle: 'Защищённая передача файлов через Tor · Оплата в Bitcoin за 1 ГБ',
    langName: 'Русский',

    heroBadge: 'ОПЛАТА ЗА ГБ · ВЫБОР СРОКА И ПРИВАТНОСТИ · 100% BITCOIN',
    heroHeadline: 'Выберите тариф · Тарифы за 1 ГБ',
    heroSubheadline: 'Загружайте файлы любого размера (500 МБ, 2 ГБ, 10 ГБ+). Выберите срок 30 или 60 дней, а также открытый или скрытый (Stealth Private) доступ. После оплаты сессия мгновенно закрывается для экономии ОЗУ.',
    ratesPer1Gb: 'Тариф за 1 ГБ',
    mostPopular: 'ПОПУЛЯРНЫЙ',
    maxPrivacy: 'МАКС. ПРИВАТНОСТЬ',
    activePlan: 'Активный план',
    selectPlan: 'Выбрать план',
    daysDuration: 'Дней',
    per1Gb: '/ 1 ГБ',
    satsPerGb: 'сатоши / ГБ',

    step2Header: 'Шаг 2: Настройте параметры, загрузите файл → Получите инвойс Bitcoin',
    step2Title: 'Выбранный тариф',
    ramSafetyBadge: 'Защита ОЗУ',
    ramSafetyDesc: 'Очистка ОЗУ сразу после оплаты',
    settingsTitle: 'Срок хранения и параметры приватности (Настройте хранение):',
    retentionTitle: '1. Срок хранения файла:',
    retention30d: '30 Дней',
    retention30dDesc: '1 месяц хранения',
    retention60d: '60 Дней',
    retention60dDesc: '2 месяца хранения',
    privacyTitle: '2. Уровень приватности и доступ:',
    privacyPublic: 'Публичный .Onion',
    privacyPublicDesc: 'Открытая ссылка + пароль',
    privacyPrivate: 'Скрытый Stealth',
    privacyPrivateDesc: 'Авторизация по ключам x25519',
    activeSelectionSummary: 'Выбрано',

    fileSizeTitle: '3. Выберите или укажите размер файла (без лимита в 1 ГБ):',
    dropZoneTitle: 'Перетащите файл сюда или нажмите для выбора',
    dropZoneDesc: 'Настроено на',
    uploadBtnText: 'Загрузить и сформировать инвойс',
    customSize: 'Свой размер',

    sevenZipNoticeTitle: 'Рекомендация по шифрованию на клиенте (7-Zip / AES-256):',
    sevenZipNoticeBadge: 'Zero-Knowledge Приватность',
    sevenZipNoticeText: 'Для абсолютной безопасности перед загрузкой сожмите архив с помощью 7-Zip, используя шифрование AES-256 и надёжный пароль.',
    sevenZipPassphraseTip: 'Включите опцию «Шифровать имена файлов», чтобы скрыть структуру каталогов внутри контейнера .7z.',
    sevenZipFilenameTip: 'Опционально: переименуйте архив в формат биткоин-адреса или случайного хеша (например, bc1q7x9...7z) для устранения любых метаданных.',
    sevenZipNotMandatory: 'Примечание: шифрование в 7-Zip и маскировка имени под BTC-адрес рекомендуются, но НЕ являются обязательными.',

    obfs4Title: 'Поддержка мостов Tor obfs4 (Обход блокировок провайдеров и РКН):',
    obfs4Badge: 'Обход цензуры',
    obfs4Desc: 'Если ваш провайдер блокирует стандартное подключение к Tor, включите встроенные мосты obfs4 в настройках Tor Browser.',
    obfs4HowTo: 'Меню Tor Browser → Настройки → Подключение → Мосты → «Использовать встроенный мост» → Выберите «obfs4». OnionShieldOasis полностью совместим со всеми соединениями через obfs4.',

    uploadingText: 'Передача частей файла в буфер хранилища...',
    uploadingSubtext: 'Хеширование на лету · Устойчивость к обрывам цепей Tor · Экономный буфер ОЗУ',
    invoiceCompleteTitle: 'Загрузка завершена',
    paymentCountdown: '14:59 До авто-уничтожения файла при отсутствии оплаты',
    scanWithWallet: 'Сканируйте через Wasabi / Sparrow',
    singleUseAddress: 'Ваш одноразовый SegWit-адрес Wasabi (bc1q):',
    daemonListening: 'Демон отслеживает поступление через .onion зеркало mempool.space...',
    simulatePayBtn: '[Симулировать получение оплаты → Закрыть сессию в ОЗУ]',

    paymentConfirmedTitle: 'Оплата подтверждена · Файл принят в хранилище!',
    ramPurgedTitle: 'Сессия загрузки закрыта & память ОЗУ полностью освобождена:',
    ramPurgedDesc: 'Файл успешно зашифрован и помещён в постоянное хранилище. Сокеты загрузки и буферы памяти немедленно очищены сборщиком мусора, сервер работает плавно.',
    downloadLinkTitle: 'Ваша ссылка для скачивания в Tor v3:',
    stealthKeyTitle: 'Сгенерированный ключ авторизации (передайте только получателю):',
    autoShredDate: 'Дата авто-уничтожения (shred):',
    copyBtn: 'Копировать ссылку',
    copiedBtn: 'Ссылка скопирована',
    startAnotherDrop: 'Начать новую сессию загрузки',
  },

  de: {
    appName: 'OnionShieldOasis',
    tagline: 'Tor Hidden Storage Vault',
    torVaultBadge: 'Tor v3 Tresor',
    headerSubtitle: 'Sicherer Tor-Dateidrop & Speicher-Tresor · Bitcoin-Abrechnung pro GB',
    langName: 'Deutsch',

    heroBadge: 'ZAHLUNG PRO GB · DAUER & PRIVATSPHÄRE WÄHLBAR · 100% BITCOIN',
    heroHeadline: 'Tarif wählen · Preise pro 1 GB',
    heroSubheadline: 'Laden Sie beliebige Dateigrößen hoch (500 MB, 2 GB, 10 GB+). Wählen Sie zwischen 30 oder 60 Tagen Aufbewahrung sowie öffentlicher oder Stealth-Private-Verschlüsselung. Nach Zahlung wird die Sitzung sofort geschlossen, um RAM zu sparen.',
    ratesPer1Gb: 'Preise pro 1 GB',
    mostPopular: 'BELIEBTESTE',
    maxPrivacy: 'MAX. PRIVATSPHÄRE',
    activePlan: 'Aktiver Tarif',
    selectPlan: 'Tarif wählen',
    daysDuration: 'Tage',
    per1Gb: '/ 1 GB',
    satsPerGb: 'Sats / GB',

    step2Header: 'Schritt 2: Optionen wählen, Datei hochladen → Bitcoin-Rechnung erhalten',
    step2Title: 'Aktive Auswahl',
    ramSafetyBadge: 'RAM-Schutz',
    ramSafetyDesc: 'Sitzung nach Zahlung bereinigt',
    settingsTitle: 'Aufbewahrungs- & Privatsphäre-Einstellungen (Anpassen):',
    retentionTitle: '1. Aufbewahrungsdauer:',
    retention30d: '30 Tage',
    retention30dDesc: '1 Monat Speicher',
    retention60d: '60 Tage',
    retention60dDesc: '2 Monate erweitert',
    privacyTitle: '2. Zugriffs- & Privatsphäre-Stufe:',
    privacyPublic: 'Öffentlicher Onion',
    privacyPublicDesc: 'Freier Link + Passwort',
    privacyPrivate: 'Stealth Privat',
    privacyPrivateDesc: 'x25519-Schlüssel-Authentifizierung',
    activeSelectionSummary: 'Ausgewählt',

    fileSizeTitle: '3. Dateigröße auswählen oder eingeben (kein 1-GB-Limit):',
    dropZoneTitle: 'Datei hierher ziehen oder zum Auswählen klicken',
    dropZoneDesc: 'Konfiguriert für',
    uploadBtnText: 'Hochladen & Rechnung generieren',
    customSize: 'Benutzerdefiniert',

    sevenZipNoticeTitle: 'Empfehlung für clientseitige Verschlüsselung (7-Zip / AES-256):',
    sevenZipNoticeBadge: 'Zero-Knowledge Privatsphäre',
    sevenZipNoticeText: 'Für maximale Sicherheit vor dem Upload: komprimieren Sie Ihre Datei mit 7-Zip, AES-256-Verschlüsselung und einem starken Passwort.',
    sevenZipPassphraseTip: 'Aktivieren Sie «Dateinamen verschlüsseln», um die Inhaltsstruktur im .7z-Archiv unkenntlich zu machen.',
    sevenZipFilenameTip: 'Optional: Benennen Sie die Datei ähnlich einer Bitcoin-Adresse oder einem Hash (z. B. bc1q7x9...7z), um Metadaten zu tilgen.',
    sevenZipNotMandatory: 'Hinweis: 7-Zip-Verschlüsselung und Dateibenennung im BTC-Stil werden dringend empfohlen, sind aber NICHT obligatorisch.',

    obfs4Title: 'Tor obfs4-Bridge-Unterstützung (Zensur & ISP-Sperren umgehen):',
    obfs4Badge: 'Zensurumgehung',
    obfs4Desc: 'Falls Ihr Internetanbieter Tor blockiert, aktivieren Sie integrierte obfs4-Bridges in den Tor Browser-Einstellungen.',
    obfs4HowTo: 'Tor Browser Menü → Einstellungen → Verbindung → Brücken → «Eingebaute Brücke auswählen» → «obfs4» wählen. OnionShieldOasis unterstützt obfs4 nahtlos.',

    uploadingText: 'Übertrage Chunks in Staging-Speicher...',
    uploadingSubtext: 'Live-Hashing · Fehlertolerante Tor-Schaltkreise · RAM-Schonend',
    invoiceCompleteTitle: 'Upload abgeschlossen',
    paymentCountdown: '14:59 Zahlungsfenster vor automatischer Vernichtung',
    scanWithWallet: 'Mit Wasabi / Sparrow scannen',
    singleUseAddress: 'Ihre Einweg-Wasabi-SegWit-Adresse (bc1q):',
    daemonListening: 'Daemon lauscht über Tor mempool.space .onion-Mirror...',
    simulatePayBtn: '[Zahlungseingang simulieren → RAM-Sitzung schließen]',

    paymentConfirmedTitle: 'Zahlung bestätigt · Datei erfolgreich aufgenommen!',
    ramPurgedTitle: 'Upload-Sitzung geschlossen & RAM-Speicher freigegeben:',
    ramPurgedDesc: 'Die Datei wurde in den verschlüsselten Tresor übertragen. Die temporären Sockets und Staging-Puffer wurden sofort gelöscht.',
    downloadLinkTitle: 'Ihr Tor v3 Download-Link:',
    stealthKeyTitle: 'Generierter Client-Auth-Schlüssel (nur an Empfänger übergeben):',
    autoShredDate: 'Automatisches Löschdatum (Shred):',
    copyBtn: 'Link kopieren',
    copiedBtn: 'Link kopiert',
    startAnotherDrop: 'Neue Sitzung starten',
  },

  zh: {
    appName: 'OnionShieldOasis',
    tagline: 'Tor 隐匿文件存储金库',
    torVaultBadge: 'Tor v3 金库',
    headerSubtitle: '基于 Tor 的安全文件传输金库 · 按每 GB 纯比特币结算',
    langName: '中文 (简体)',

    heroBadge: '按每 GB 计费 · 自选保留周期与隐私级别 · 100% 比特币',
    heroHeadline: '选择您的方案 · 每 1 GB 费率',
    heroSubheadline: '可上传任意大小的文件（500 MB、2 GB、10 GB+）。自由选择 30 天或 60 天存储期限，以及公开或隐匿私人（Stealth Private）加密。付款完成后，服务器会立即释放暂存会话以节省内存。',
    ratesPer1Gb: '每 1 GB 费率',
    mostPopular: '最受欢迎',
    maxPrivacy: '最高隐私',
    activePlan: '当前方案',
    selectPlan: '选择此方案',
    daysDuration: '天',
    per1Gb: '/ 1 GB',
    satsPerGb: '聪 / GB',

    step2Header: '步骤 2：选择选项并上传文件 → 获取比特币账单',
    step2Title: '当前所选',
    ramSafetyBadge: '内存保护',
    ramSafetyDesc: '付款后即刻释放内存',
    settingsTitle: '文件保留周期与隐私级别设置（自定义您的存储）：',
    retentionTitle: '1. 文件保留时间：',
    retention30d: '30 天',
    retention30dDesc: '1 个月存储',
    retention60d: '60 天',
    retention60dDesc: '2 个月延期存储',
    privacyTitle: '2. 隐私与访问级别：',
    privacyPublic: '公开 Onion',
    privacyPublicDesc: '公开网址 + 密码',
    privacyPrivate: '隐匿私人 (Stealth)',
    privacyPrivateDesc: 'x25519 密钥对鉴权',
    activeSelectionSummary: '已选配置',

    fileSizeTitle: '3. 选择或输入文件大小（无 1 GB 上传限制）：',
    dropZoneTitle: '将任意文件拖放到此处或点击选择',
    dropZoneDesc: '配置为',
    uploadBtnText: '上传并生成比特币账单',
    customSize: '自定义大小',

    sevenZipNoticeTitle: '客户端本地加密最佳实践建议（7-Zip / AES-256）：',
    sevenZipNoticeBadge: '零知识隐私保护',
    sevenZipNoticeText: '为了确保绝对的操作安全，建议在上传前使用 7-Zip 将文件压缩并启用 AES-256 加密和强密码锁。',
    sevenZipPassphraseTip: '勾选“加密文件名”，使压缩包内的目录与文件名完全不可见。',
    sevenZipFilenameTip: '可选建议：将文件名重命名为类似比特币地址或随机哈希的格式（例如 bc1q7x9...7z），彻底消除特征元数据。',
    sevenZipNotMandatory: '注意：使用 7-Zip 加密以及 BTC 风格命名为强烈推荐项，但并非强制要求。',

    obfs4Title: '支持 Tor obfs4 网桥（有效规避防火长城 GFW / ISP 封锁）：',
    obfs4Badge: '抗审查穿透',
    obfs4Desc: '如果您所在的网络或运营商封锁了标准 Tor 连接（如中国、俄罗斯、伊朗等），可在 Tor 浏览器中启用内置 obfs4 网桥。',
    obfs4HowTo: 'Tor 浏览器菜单 → 设置 → 连接 → 网桥 → 勾选“选择内置网桥” → 选择“obfs4”。OnionShieldOasis 完全兼容 obfs4 链路。',

    uploadingText: '正在分块传输至暂存缓冲区...',
    uploadingSubtext: '实时哈希校验 · Tor 链路断点续传 · 安全轻量内存缓冲',
    invoiceCompleteTitle: '上传完成',
    paymentCountdown: '14:59 未付款自动粉碎倒计时',
    scanWithWallet: '使用 Wasabi / Sparrow 钱包扫码',
    singleUseAddress: '您的专属一次性 Wasabi SegWit 地址 (bc1q)：',
    daemonListening: '后台守护进程正通过 Tor mempool.space .onion 镜像监听确认...',
    simulatePayBtn: '[模拟收到付款 → 自动关闭内存会话]',

    paymentConfirmedTitle: '付款已确认 · 文件已安全入库！',
    ramPurgedTitle: '上传会话已关闭，系统内存已彻底释放：',
    ramPurgedDesc: '文件已被写入加密保险库。暂存文件套接字与内存缓冲区已立即被垃圾回收释放，确保服务器流畅稳定。',
    downloadLinkTitle: '您的 Tor v3 下载链接：',
    stealthKeyTitle: '生成的客户端授权密钥（仅交予接收方）：',
    autoShredDate: '自动物理粉碎日期：',
    copyBtn: '复制链接',
    copiedBtn: '已复制链接',
    startAnotherDrop: '开启新的上传会话',
  },

  fr: {
    appName: 'OnionShieldOasis',
    tagline: 'Coffre-Fort de Stockage Caché Tor',
    torVaultBadge: 'Coffre Tor v3',
    headerSubtitle: 'Dépôt et Coffre-Fort Tor Sécurisé · Facturation Bitcoin par Go',
    langName: 'Français',

    heroBadge: 'PAIEMENT PAR GO · CHOIX DE RÉTENTION & CONFIDENTIALITÉ · 100% BITCOIN',
    heroHeadline: 'Choisissez votre forfait · Tarifs par 1 Go',
    heroSubheadline: 'Téléversez n’importe quelle taille de fichier (500 Mo, 2 Go, 10 Go+). Choisissez entre 30 ou 60 jours de rétention et un chiffrement public ou furtif (Stealth Private). Une fois payé, la session se ferme immédiatement pour libérer la RAM.',
    ratesPer1Gb: 'Tarifs par 1 Go',
    mostPopular: 'LE PLUS POPULAIRE',
    maxPrivacy: 'CONFIDENTIALITÉ MAX',
    activePlan: 'Forfait Actif',
    selectPlan: 'Sélectionner ce forfait',
    daysDuration: 'Jours',
    per1Gb: '/ 1 Go',
    satsPerGb: 'sats / Go',

    step2Header: 'Étape 2 : Options & Téléversement → Réception de la facture Bitcoin',
    step2Title: 'Sélection Active',
    ramSafetyBadge: 'Sécurité RAM',
    ramSafetyDesc: 'Purge automatique de la session après paiement',
    settingsTitle: 'Paramètres de rétention et de confidentialité (Personnaliser) :',
    retentionTitle: '1. Durée de conservation :',
    retention30d: '30 Jours',
    retention30dDesc: 'Stockage 1 mois',
    retention60d: '60 Jours',
    retention60dDesc: 'Stockage étendu 2 mois',
    privacyTitle: '2. Niveau de confidentialité & accès :',
    privacyPublic: 'Onion Public',
    privacyPublicDesc: 'Lien ouvert + Mot de passe',
    privacyPrivate: 'Furtif Privé (Stealth)',
    privacyPrivateDesc: 'Authentification par clé x25519',
    activeSelectionSummary: 'Sélectionné',

    fileSizeTitle: '3. Choisissez ou saisissez la taille du fichier (aucune limite de 1 Go) :',
    dropZoneTitle: 'Glissez un fichier ici ou cliquez pour sélectionner',
    dropZoneDesc: 'Configuré pour',
    uploadBtnText: 'Téléverser et générer la facture',
    customSize: 'Personnalisé',

    sevenZipNoticeTitle: 'Bonnes pratiques de chiffrement côté client (7-Zip / AES-256) :',
    sevenZipNoticeBadge: 'Confidentialité Zero-Knowledge',
    sevenZipNoticeText: 'Pour une sécurité optimale avant téléversement, compressez votre archive avec 7-Zip en activant le chiffrement AES-256 et un mot de passe fort.',
    sevenZipPassphraseTip: 'Cochez « Chiffrer les noms de fichiers » pour masquer la structure interne de l’archive .7z.',
    sevenZipFilenameTip: 'Optionnel : renommez le fichier sous forme d’adresse Bitcoin ou de hash aléatoire (ex. bc1q7x9...7z) pour éliminer les métadonnées.',
    sevenZipNotMandatory: 'Remarque : le chiffrement 7-Zip et le renommage style BTC sont vivement recommandés mais NON obligatoires.',

    obfs4Title: 'Support des ponts Tor obfs4 (Contournement du blocage FAI / censure) :',
    obfs4Badge: 'Contournement de Censure',
    obfs4Desc: 'Si votre FAI bloque les connexions Tor habituelles (Chine, Russie, Iran), activez les ponts obfs4 intégrés dans Tor Browser.',
    obfs4HowTo: 'Menu Tor Browser → Paramètres → Connexion → Ponts → « Sélectionner un pont intégré » → Choisir « obfs4 ». OnionShieldOasis supporte tous les circuits obfs4.',

    uploadingText: 'Transmission des blocs vers le tampon...',
    uploadingSubtext: 'Hachage à la volée · Reprise sur coupure Tor · Tampon RAM allégé',
    invoiceCompleteTitle: 'Téléversement terminé',
    paymentCountdown: '14:59 Délai de paiement avant destruction automatique',
    scanWithWallet: 'Scanner avec Wasabi / Sparrow',
    singleUseAddress: 'Votre adresse Wasabi SegWit à usage unique (bc1q) :',
    daemonListening: 'Le démon écoute via le miroir .onion de mempool.space...',
    simulatePayBtn: '[Simuler paiement reçu → Fermer la session en RAM]',

    paymentConfirmedTitle: 'Paiement confirmé · Fichier accepté dans le coffre !',
    ramPurgedTitle: 'Session fermée & mémoire RAM immédiatement libérée :',
    ramPurgedDesc: 'Le fichier a été scellé dans le stockage chiffré. Les sockets et tampons de téléversement ont été immédiatement détruits.',
    downloadLinkTitle: 'Votre lien de téléchargement Tor v3 :',
    stealthKeyTitle: 'Clé client-auth générée (à transmettre au destinataire) :',
    autoShredDate: 'Date d’auto-destruction (shred) :',
    copyBtn: 'Copier le lien',
    copiedBtn: 'Lien copié',
    startAnotherDrop: 'Démarrer une nouvelle session',
  },

  es: {
    appName: 'OnionShieldOasis',
    tagline: 'Bóveda de Almacenamiento Oculta Tor',
    torVaultBadge: 'Bóveda Tor v3',
    headerSubtitle: 'Depósito y Almacenamiento Seguro Tor · Facturación en Bitcoin por GB',
    langName: 'Español',

    heroBadge: 'PAGO POR GB · ELIGE RETENCIÓN Y PRIVACIDAD · 100% BITCOIN',
    heroHeadline: 'Selecciona tu Plan · Tarifas por 1 GB',
    heroSubheadline: 'Sube cualquier tamaño de archivo (500 MB, 2 GB, 10 GB+). Elige entre 30 Días o 60 Días de retención, y cifrado Público o Sigiloso Privado (Stealth). Una vez pagado, el servidor acepta el archivo y cierra la sesión inmediatamente para ahorrar RAM.',
    ratesPer1Gb: 'Tarifas por 1 GB',
    mostPopular: 'MÁS POPULAR',
    maxPrivacy: 'MÁXIMA PRIVACIDAD',
    activePlan: 'Plan Activo',
    selectPlan: 'Seleccionar Plan',
    daysDuration: 'Días',
    per1Gb: '/ 1 GB',
    satsPerGb: 'sats / GB',

    step2Header: 'Paso 2: Elige Opciones, Sube Archivo → Recibe Factura Bitcoin',
    step2Title: 'Selección Activa',
    ramSafetyBadge: 'Seguridad de RAM',
    ramSafetyDesc: 'Auto-Purga de Sesión al Pagar',
    settingsTitle: 'Configuración de Retención y Privacidad (Personaliza tu Entrega):',
    retentionTitle: '1. Duración de Retención:',
    retention30d: '30 Días',
    retention30dDesc: 'Almacenamiento de 1 Mes',
    retention60d: '60 Días',
    retention60dDesc: '2 Meses Extendido',
    privacyTitle: '2. Nivel de Privacidad y Acceso:',
    privacyPublic: 'Onion Público',
    privacyPublicDesc: 'Enlace Abierto + Contraseña Opcional',
    privacyPrivate: 'Sigiloso Privado (Stealth)',
    privacyPrivateDesc: 'Autenticación con Claves x25519',
    activeSelectionSummary: 'Seleccionado',

    fileSizeTitle: '3. Selecciona o Ingresa el Tamaño del Archivo (Sin límite de 1 GB):',
    dropZoneTitle: 'Arrastra Cualquier Archivo Aquí o Haz Clic para Seleccionar',
    dropZoneDesc: 'Configurado para',
    uploadBtnText: 'Subir Archivo y Generar Factura',
    customSize: 'Personalizado',

    sevenZipNoticeTitle: 'Prácticas Recomendadas de Cifrado del Lado del Cliente (7-Zip / AES-256):',
    sevenZipNoticeBadge: 'Privacidad Zero-Knowledge',
    sevenZipNoticeText: 'Para una máxima seguridad antes de subir, comprime tu archivo con 7-Zip usando cifrado AES-256 y una contraseña segura.',
    sevenZipPassphraseTip: 'Marca "Cifrar nombres de archivo" (-mhe=on) para ocultar nombres internos y estructura del archivo .7z.',
    sevenZipFilenameTip: 'Opcional: renombra el archivo como una dirección Bitcoin (ej. bc1q7x9...7z) para evitar filtrar tipos de archivo a observadores.',
    sevenZipNotMandatory: 'Nota: El cifrado con 7-Zip y el nombrado estilo BTC son altamente recomendados, pero NO son obligatorios. Se aceptan archivos normales.',

    obfs4Title: 'Soporte de Puentes Tor obfs4 (Evasión de Censura y Bloqueos de ISP):',
    obfs4Badge: 'Evasión de Censura',
    obfs4Desc: 'Si tu proveedor de internet bloquea conexiones Tor (Rusia, China, Irán), activa los puentes obfs4 integrados en Tor Browser.',
    obfs4HowTo: 'Menú Tor Browser → Ajustes → Conexión → Puentes → "Seleccionar un puente integrado" → Elegir "obfs4". OnionShieldOasis admite todos los circuitos obfs4.',

    uploadingText: 'Transmitiendo datos al búfer de preparación...',
    uploadingSubtext: 'Hasheo sobre la marcha · Memoria RAM protegida a ~15 MB · Chunks Tor reanudables',
    invoiceCompleteTitle: 'Subida Completa',
    paymentCountdown: '14:59 Ventana de Pago Antes de Auto-Destrucción',
    scanWithWallet: 'Escanear con Wasabi / Sparrow',
    singleUseAddress: 'Tu Dirección Wasabi SegWit de Un Solo Uso (bc1q):',
    daemonListening: 'El demonio escucha mediante el espejo .onion de mempool.space...',
    simulatePayBtn: '[Simular Pago Recibido → Auto-Cerrar Sesión en RAM]',

    paymentConfirmedTitle: '¡Pago Confirmado · Archivo Aceptado en la Bóveda!',
    ramPurgedTitle: 'Sesión de Preparación Cerrada y Memoria RAM Purgada:',
    ramPurgedDesc: 'El archivo ha sido transferido a la bóveda cifrada. Los sockets de carga y búferes en memoria fueron recolectados y destruidos inmediatamente.',
    downloadLinkTitle: 'Tu Enlace de Descarga Tor v3:',
    stealthKeyTitle: 'Clave de Autenticación de Cliente (Entrega Solo al Destinatario):',
    autoShredDate: 'Fecha de auto-destrucción:',
    copyBtn: 'Copiar Enlace',
    copiedBtn: 'Enlace Copiado',
    startAnotherDrop: 'Iniciar otra sesión de subida',
  },

  pt: {
    appName: 'OnionShieldOasis',
    tagline: 'Cofre de Armazenamento Oculto Tor',
    torVaultBadge: 'Cofre Tor v3',
    headerSubtitle: 'Depósito e Armazenamento Seguro Tor · Cobrança em Bitcoin por GB',
    langName: 'Português',

    heroBadge: 'PAGUE POR GB · ESCOLHA RETENÇÃO E PRIVACIDADE · 100% BITCOIN',
    heroHeadline: 'Selecione o seu Plano · Tarifas por 1 GB',
    heroSubheadline: 'Envie qualquer tamanho de ficheiro (500 MB, 2 GB, 10 GB+). Escolha entre 30 Dias ou 60 Dias de retenção, e encriptação Pública ou Furtiva Privada (Stealth). Após o pagamento, o servidor aceita o ficheiro e encerra a sessão imediatamente para poupar RAM.',
    ratesPer1Gb: 'Tarifas por 1 GB',
    mostPopular: 'MAIS POPULAR',
    maxPrivacy: 'MÁXIMA PRIVACIDADE',
    activePlan: 'Plano Ativo',
    selectPlan: 'Selecionar Plano',
    daysDuration: 'Dias',
    per1Gb: '/ 1 GB',
    satsPerGb: 'sats / GB',

    step2Header: 'Passo 2: Escolha as Opções, Envie o Ficheiro → Receba a Fatura Bitcoin',
    step2Title: 'Seleção Ativa',
    ramSafetyBadge: 'Segurança de RAM',
    ramSafetyDesc: 'Encerramento e purga automática da sessão após pagamento',
    settingsTitle: 'Definições de Retenção e Privacidade (Personalize o Envio):',
    retentionTitle: '1. Duração da Retenção:',
    retention30d: '30 Dias',
    retention30dDesc: 'Armazenamento de 1 Mês',
    retention60d: '60 Dias',
    retention60dDesc: '2 Meses Alargado',
    privacyTitle: '2. Nível de Privacidade e Acesso:',
    privacyPublic: 'Onion Público',
    privacyPublicDesc: 'Link Aberto + Palavra-passe Opcional',
    privacyPrivate: 'Furtivo Privado (Stealth)',
    privacyPrivateDesc: 'Autenticação por chave x25519',
    activeSelectionSummary: 'Selecionado',

    fileSizeTitle: '3. Selecione ou introduza o tamanho do ficheiro (sem limite de 1 GB):',
    dropZoneTitle: 'Arraste qualquer ficheiro para aqui ou clique para selecionar',
    dropZoneDesc: 'Configurado para',
    uploadBtnText: 'Enviar Ficheiro e Gerar Fatura',
    customSize: 'Personalizado',

    sevenZipNoticeTitle: 'Boas Práticas de Encriptação no Lado do Cliente (7-Zip / AES-256):',
    sevenZipNoticeBadge: 'Privacidade Zero-Knowledge',
    sevenZipNoticeText: 'Para máxima segurança antes do envio, comprima o arquivo com 7-Zip utilizando encriptação AES-256 e uma palavra-passe robusta.',
    sevenZipPassphraseTip: 'Ative "Encriptar nomes de ficheiros" (-mhe=on) para ocultar a estrutura interna do arquivo .7z.',
    sevenZipFilenameTip: 'Opcional: renomeie o ficheiro como um endereço Bitcoin (ex.: bc1q7x9...7z) para eliminar fugas de metadados.',
    sevenZipNotMandatory: 'Nota: A encriptação com 7-Zip e o nome em formato BTC são altamente recomendados, mas NÃO são obrigatórios. Ficheiros normais são aceites diretamente.',

    obfs4Title: 'Suporte a Pontes Tor obfs4 (Contorno de Censura e Bloqueios de ISP):',
    obfs4Badge: 'Contorno de Censura',
    obfs4Desc: 'Se o seu fornecedor de internet bloqueia ligações Tor habituais (Rússia, China, Irão), ative as pontes obfs4 integradas no Tor Browser.',
    obfs4HowTo: 'Menu Tor Browser → Definições → Ligação → Pontes → "Selecionar uma ponte integrada" → Escolher "obfs4". O OnionShieldOasis suporta todos os circuitos obfs4.',

    uploadingText: 'A transferir blocos para a memória temporária...',
    uploadingSubtext: 'Hashing em tempo real · RAM protegida a ~15 MB · Chunks Tor retomáveis',
    invoiceCompleteTitle: 'Envio Concluído',
    paymentCountdown: '14:59 Janela de Pagamento antes de Auto-Destruição',
    scanWithWallet: 'Digitalizar com Wasabi / Sparrow',
    singleUseAddress: 'O seu endereço Wasabi SegWit descartável (bc1q):',
    daemonListening: 'O daemon está à escuta através do espelho .onion da mempool.space...',
    simulatePayBtn: '[Simular Pagamento Recebido → Encerrar Sessão em RAM]',

    paymentConfirmedTitle: 'Pagamento Confirmado · Ficheiro Aceite no Cofre!',
    ramPurgedTitle: 'Sessão encerrada e memória RAM libertada de imediato:',
    ramPurgedDesc: 'O ficheiro foi armazenado no cofre encriptado. As ligações de envio e buffers foram eliminados de imediato.',
    downloadLinkTitle: 'O seu link de transferência Tor v3:',
    stealthKeyTitle: 'Chave de autenticação gerada (partilhar apenas com o destinatário):',
    autoShredDate: 'Data de auto-destruição:',
    copyBtn: 'Copiar Link',
    copiedBtn: 'Link Copiado',
    startAnotherDrop: 'Iniciar outra sessão de envio',
  },
};
